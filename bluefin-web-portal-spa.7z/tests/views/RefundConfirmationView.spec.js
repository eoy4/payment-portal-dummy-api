import React from 'react'

describe('(View) RefundConfirmation', () => {
  it('should exist', () => {

  })
})
