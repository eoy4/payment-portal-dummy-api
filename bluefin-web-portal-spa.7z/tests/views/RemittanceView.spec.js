import React from 'react'

describe('(View) Remittance', () => {
  it('should exist', () => {

  })
})
