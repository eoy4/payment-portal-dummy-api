import React from 'react'

describe('(View) Reports', () => {
  it('should exist', () => {

  })
})
