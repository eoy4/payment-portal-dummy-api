import React from 'react'

describe('(View) BatchFileDetails', () => {
  it('should exist', () => {

  })
})
