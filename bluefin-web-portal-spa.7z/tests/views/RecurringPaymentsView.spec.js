import React from 'react'

describe('(View) RecurringPayments', () => {
  it('should exist', () => {

  })
})
