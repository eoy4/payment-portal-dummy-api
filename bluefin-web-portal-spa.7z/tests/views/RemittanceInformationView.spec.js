import React from 'react'

describe('(View) RemittanceInformation', () => {
  it('should exist', () => {

  })
})
