import React from 'react';

describe('(View) ProcessorRules', () => {
  it('should exist', () => {

  })
})
