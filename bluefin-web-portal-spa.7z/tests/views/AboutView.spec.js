import React from 'react'

describe('(View) About', () => {
  it('should exist', () => {

  })
})
