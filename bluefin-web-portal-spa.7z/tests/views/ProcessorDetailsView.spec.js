import React from 'react'

describe('(View) ProcessorDetails', () => {
  it('should exist', () => {

  })
})
