import React from 'react'

describe('(View) LegalEntities', () => {
  it('should exist', () => {

  })
})
