import React from 'react'

describe('(View) TransactionDetails', () => {
  it('should exist', () => {

  })
})
