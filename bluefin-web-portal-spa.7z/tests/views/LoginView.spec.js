import React from 'react'

describe('(View) Login', () => {
  it('should exist', () => {

  })
})
