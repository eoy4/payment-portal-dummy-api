import React from 'react'

describe('(View) PasswordRecovery', () => {
  it('should exist', () => {

  })
})
