import React from 'react'

describe('(View) StatusCodes', () => {
  it('should exist', () => {

  })
})
