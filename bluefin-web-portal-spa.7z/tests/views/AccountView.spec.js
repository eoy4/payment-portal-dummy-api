import React from 'react'

describe('(View) Account', () => {
  it('should exist', () => {

  })
})
