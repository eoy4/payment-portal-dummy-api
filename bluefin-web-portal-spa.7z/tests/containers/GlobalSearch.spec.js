describe('(Component) GlobalSearch', () => {
  it('exists', () => {

  })
})
