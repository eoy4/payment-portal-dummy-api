describe('(Component) RemittanceDetails', () => {
  it('exists', () => {

  })
})
