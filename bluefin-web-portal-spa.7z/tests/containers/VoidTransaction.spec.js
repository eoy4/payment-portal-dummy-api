describe('(Component) VoidTransaction', () => {
  it('exists', () => {

  })
})
