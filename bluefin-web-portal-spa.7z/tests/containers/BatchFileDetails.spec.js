describe('(Component) BatchFileDetails', () => {
  it('exists', () => {

  })
})
