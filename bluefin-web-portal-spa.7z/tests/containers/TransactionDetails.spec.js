describe('(Component) TransactionDetails', () => {
  it('exists', () => {

  })
})
