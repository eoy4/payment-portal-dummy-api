import React from 'react'
import MultipleTransactionConfirmationList from 'components/MultipleTransactionConfirmationList/MultipleTransactionConfirmationList'

describe('(Component) MultipleTransactionConfirmationList', () => {
  it('should exist', () => {

  })
})
