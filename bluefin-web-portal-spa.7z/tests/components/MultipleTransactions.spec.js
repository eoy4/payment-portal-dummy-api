import React from 'react'
import MultipleTransactions from 'components/MultipleTransactions/MultipleTransactions'

describe('(Component) MultipleTransactions', () => {
  it('should exist', () => {

  })
})
