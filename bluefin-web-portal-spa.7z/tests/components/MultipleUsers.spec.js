import React from 'react'
import MultipleUsers from 'components/MultipleUsers/MultipleUsers'

describe('(Component) MultipleUsers', () => {
  it('should exist', () => {

  })
})
