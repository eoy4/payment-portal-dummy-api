import React from 'react'
import DatePicker from 'components/DatePicker/DatePicker'

describe('(Component) DatePicker', () => {
  it('should exist', () => {

  })
})
