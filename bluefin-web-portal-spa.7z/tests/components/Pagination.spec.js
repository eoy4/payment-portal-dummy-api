import React from 'react';
import Pagination from 'components/Pagination/Pagination';
import { shallow } from 'enzyme';
import { sinon } from 'sinon';

const receivedTransactions =
  {"content":[{"applicationTransactionId":"111R2457","transactionType":"SALE","transactionStatusCode":"APPROVED","customer":"Natalia  Quiros","legalEntity":"MCMR2K","accountNumber":"74235","amount":42.1200,"cardType":"CREDIT","cardNumberLast4Char":"XXXX-XXXX-XXXX-7430","processorName":"JETPAY","createdDate":"2016-06-10T11:06:35.000Z"},{"applicationTransactionId":"111R2410","transactionType":"VOID","transactionStatusCode":"ERROR","customer":"John Harby","legalEntity":"MCMR2K","accountNumber":"98514","amount":300.2500,"cardType":"DEBIT","cardNumberLast4Char":"XXXX-XXXX-XXXX-9744","processorName":"PAYSCOUT","createdDate":"2016-06-10T11:38:37.000Z"},{"applicationTransactionId":"111R2147","transactionType":"SALE","transactionStatusCode":"DENIED","customer":"Joshua Briceño","legalEntity":"AAWARDATA","accountNumber":"74512","amount":452.3600,"cardType":"CREDIT","cardNumberLast4Char":"XXXX-XXXX-XXXX-8513","processorName":"JETPAY","createdDate":"2016-06-10T11:38:37.000Z"},{"applicationTransactionId":"111R2128","transactionType":"REFUND","transactionStatusCode":"DENIED","customer":"Oscar Monge","legalEntity":"MCMR2K","accountNumber":"67468","amount":854.0000,"cardType":"CREDIT","cardNumberLast4Char":"XXXX-XXXX-XXXX-5421","processorName":"PAYSCOUT","createdDate":"2016-06-10T11:27:56.000Z"}],"last":true,"totalPages":1,"totalElements":4,"first":true,"sort":[{"direction":"ASC","property":"amount","ignoreCase":false,"nullHandling":"NATIVE","ascending":true},{"direction":"DESC","property":"createdDate","ignoreCase":false,"nullHandling":"NATIVE","ascending":false}],"numberOfElements":4,"size":5,"number":0};

describe('(Component) Pagination', () => {

  it('should exist', () => {
    expect(Pagination).to.be.defined;
  })

  it('should render properly', () => {

    //const onButtonClick = sinon.spy();
    const props = {
      transactions : receivedTransactions,
      currentPage: 0,
    }

    const wrapper = shallow(<Pagination {...props} />);

    expect(wrapper.find('li').length).to.equal(3);
    // expect(wrapper.find('li:first-child > .disabled').length).to.equal(1);
    // expect(wrapper.find('li:last-child > .disabled').length).to.equal(1);
  })
})
