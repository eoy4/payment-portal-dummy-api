import React from 'react'
import ConvertibleTimeInput from 'components/ConvertibleTimeInput/ConvertibleTimeInput'

describe('(Component) ConvertibleTimeInput', () => {
  it('should exist', () => {

  })
})
