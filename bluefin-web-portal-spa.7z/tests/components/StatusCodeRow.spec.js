import React from 'react'
import StatusCodeRow from 'components/StatusCodeRow/StatusCodeRow'

describe('(Component) StatusCodeRow', () => {
  it('should exist', () => {

  })
})
