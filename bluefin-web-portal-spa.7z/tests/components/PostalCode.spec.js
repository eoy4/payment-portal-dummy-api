import React from 'react'
import PostalCode from 'components/PostalCode/PostalCode'

describe('(Component) PostalCode', () => {
  it('should exist', () => {

  })
})
