import React from 'react'
import CheckboxWithID from 'components/CheckboxWithID/CheckboxWithID'

describe('(Component) CheckboxWithID', () => {
  it('should exist', () => {

  })
})
