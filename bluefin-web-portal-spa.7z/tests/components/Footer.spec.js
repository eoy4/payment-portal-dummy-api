import React from 'react'
import Footer from 'components/Footer/Footer'

describe('(Component) Footer', () => {
  it('should exist', () => {

  })
})
