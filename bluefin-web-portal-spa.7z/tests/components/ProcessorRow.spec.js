import React from 'react'
import ProcessorRow from 'components/ProcessorRow/ProcessorRow'

describe('(Component) ProcessorRow', () => {
  it('should exist', () => {

  })
})
