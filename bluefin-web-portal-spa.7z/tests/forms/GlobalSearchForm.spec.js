describe('(Form) GlobalSearch', () => {
  it('exists', () => {

  })
})
