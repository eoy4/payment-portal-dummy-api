import React from 'react'
import <%= pascalEntityName %> from 'components/<%= pascalEntityName %>/<%= pascalEntityName %>'

describe('(Component) <%= pascalEntityName %>', () => {
  it('should exist', () => {

  })
})
