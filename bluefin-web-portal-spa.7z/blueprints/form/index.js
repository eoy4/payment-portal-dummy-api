module.exports = {
  description () {
    return 'generates a connected redux-form form component';
  }
};
