describe('(Component) <%= pascalEntityName %>', () => {
  it('exists', () => {

  })
})
