import React from 'react'

describe('(View) <%= pascalEntityName %>', () => {
  it('should exist', () => {

  })
})
