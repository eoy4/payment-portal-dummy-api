import <%= pascalEntityName %>Layout from './<%= pascalEntityName %>Layout'
export default <%= pascalEntityName %>Layout
