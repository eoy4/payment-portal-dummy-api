import React from 'react'

describe('(Layout) <%= pascalEntityName %>', () => {
  it('should exist', () => {

  })
})
