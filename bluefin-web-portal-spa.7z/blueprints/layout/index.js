module.exports = {
  description () {
    return 'generates a functional layout component';
  }
};
