import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

// Constants
export const constants = {
  CREATE_PROCESSOR: 'CREATE_PROCESSOR',
  CREATED_PROCESSOR: 'CREATED_PROCESSOR',
  CREATE_PROCESSOR_FAILED: 'CREATE_PROCESSOR_FAILED',
  GET_PROCESSOR: 'GET_PROCESSOR',
  GOT_PROCESSOR: 'GOT_PROCESSOR',
  GOT_PROCESSOR_FAILED: 'GOT_PROCESSOR_FAILED',
  GET_PROCESSOR_STATUS: 'GET_PROCESSOR_STATUS',
  GOT_PROCESSOR_STATUS: 'GOT_PROCESSOR_STATUS',
  GOT_PROCESSOR_STATUS_FAILED: 'GOT_PROCESSOR_STATUS_FAILED',
  GET_PROCESSORS: 'GET_PROCESSORS',
  GOT_PROCESSORS: 'GOT_PROCESSORS',
  GOT_PROCESSORS_FAILED: 'GOT_PROCESSORS_FAILED',
  DELETE_PROCESSOR: 'DELETE_PROCESSOR',
  DELETED_PROCESSOR: 'DELETED_PROCESSOR',
  DELETED_PROCESSOR_FAILED: 'DELETED_PROCESSOR_FAILED',
  UPDATE_PROCESSOR: 'UPDATE_PROCESSOR',
  UPDATED_PROCESSOR: 'UPDATED_PROCESSOR',
  UPDATE_PROCESSOR_FAILED: 'UPDATE_PROCESSOR_FAILED',
  ASSIGN_MERCHANTS: 'ASSIGN_MERCHANTS',
  ASSIGNED_MERCHANTS: 'ASSIGNED_MERCHANTS',
  ASSIGN_MERCHANTS_FAILED: 'ASSIGN_MERCHANTS_FAILED',
  CLEAN_PROCESSOR: 'CLEAN_PROCESSOR'
};

// Action Creators

export function cleanProcessor (): Action {
  return {
    type: constants.CLEAN_PROCESSOR,
    payload: {
      paymentProcessorId: '',
      processorName: '',
      isActive: 0
    }
  };
}

export function _createProcessor (processor) {
  return {
    [CALL_API]: {
      types: [constants.CREATED_PROCESSOR, constants.CREATE_PROCESSOR_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD,
      authenticated: true,
      body: JSON.stringify(processor),
      method: 'POST'
    }
  };
}

export function createProcessor (processor) {
  return (dispatch) => {
    return dispatch(_createProcessor(processor));
  };
}

export function _getProcessor (processorId) {
  return {
    [CALL_API]: {
      types: [constants.GOT_PROCESSOR, constants.GOT_PROCESSOR_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD + processorId,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getProcessorStatus (processorId) {
  return (dispatch) => {
    return dispatch(_getProcessorStatus(processorId));
  };
}

export function _getProcessorStatus (processorId) {
  return {
    [CALL_API]: {
      types: [constants.GOT_PROCESSOR_STATUS, constants.GOT_PROCESSOR_STATUS_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD + processorId + '/status',
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getProcessor (processorId) {
  return (dispatch) => {
    return dispatch(_getProcessor(processorId));
  };
}

export function _getProcessors () {
  return {
    [CALL_API]: {
      types: [constants.GOT_PROCESSORS, constants.GOT_PROCESSORS_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getProcessors () {
  return (dispatch) => {
    return dispatch(_getProcessors());
  };
}

export function _deleteProcessor (processorId) {
  return {
    [CALL_API]: {
      types: [constants.DELETED_PROCESSOR, constants.DELETED_PROCESSOR_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD + processorId,
      authenticated: true,
      method: 'DELETE'
    }
  };
}

export function deleteProcessor (processorId) {
  return (dispatch) => {
    return dispatch(_deleteProcessor(processorId));
  };
}

export function _updateProcessor (paymentProcessorId, processor) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_PROCESSOR, constants.UPDATE_PROCESSOR_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD + paymentProcessorId,
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(processor)
    }
  };
}

export function updateProcessor (paymentProcessorId, processor) {
  return (dispatch) => {
    return dispatch(_updateProcessor(paymentProcessorId, processor));
  };
}

export function _assignMerchantsToProcessor (paymentProcessorId, merchants) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_PROCESSOR, constants.UPDATE_PROCESSOR_FAILED],
      endpoint: MICROSERVICE.PROCESSORS.CRUD + paymentProcessorId + '/payment-processor-merchants',
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(merchants)
    }
  };
}

export function assignMerchantsToProcessor (paymentProcessorId, merchants) {
  return (dispatch) => {
    return dispatch(_assignMerchantsToProcessor(paymentProcessorId, merchants));
  };
}

// Reducer
export const initialState = {
  currentProcessor: {
    paymentProcessorId: '',
    processorName: '',
    isActive: 0,
    readyToBeActivated: false,
    paymentProcessorMerchants: []
  },
  currentProcessorStatus: {},
  paymentProcessors: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.UPDATED_PROCESSOR:
      return Object.assign({}, state, {
        currentProcessor: action.payload
      });
    case constants.ASSIGNED_MERCHANTS:
      return Object.assign({}, state, {
        currentProcessor: action.payload
      });
    case constants.CREATED_PROCESSOR:
      return Object.assign({}, state, {
        currentProcessor: action.payload
      });
    case constants.GOT_PROCESSOR:
      return Object.assign({}, state, {
        currentProcessor: action.payload
      });
    case constants.GOT_PROCESSOR_STATUS:
      return Object.assign({}, state, {
        currentProcessorStatus: action.payload
      });
    case constants.GOT_PROCESSORS:
      return Object.assign({}, state, {
        paymentProcessors: action.payload
      });
    case constants.DELETED_PROCESSOR:
      return Object.assign({});
    case constants.CLEAN_PROCESSOR:
      return Object.assign({}, state, {
        currentProcessor: action.payload
      });
    default:
      return state;
  }
}
