import { CALL_API } from '../../middleware/api';
import { MICROSERVICE, MIDDLEWARE } from '../../../config/api';

// Constants
export const constants = {
  VOIDED_TRANSACTION: 'VOIDED_TRANSACTION',
  VOID_TRANSACTION_FAILED: 'VOID_TRANSACTION_FAILED',
  REFUNDED_TRANSACTION: 'REFUNDED_TRANSACTION',
  REFUND_TRANSACTION_FAILED: 'REFUND_TRANSACTION_FAILED',
  GET_TRANSACTION: 'GET_TRANSACTION',
  GET_TRANSACTION_FAILED: 'GET_TRANSACTION_FAILED',
  GET_TRANSACTIONS: 'GET_TRANSACTIONS',
  GET_TRANSACTIONS_FAILED: 'GET_TRANSACTIONS_FAILED',
  RECEIVED_TRANSACTION: 'RECEIVED_TRANSACTION',
  RECEIVED_TRANSACTIONS: 'RECEIVED_TRANSACTIONS',
  CREATE_TRANSACTION: 'CREATE_TRANSACTION',
  TRANSACTION_CREATED: 'TRANSACTION_CREATED',
  CREATE_TRANSACTION_FAILED: 'CREATE_TRANSACTION_FAILED',
  STORE_FILTER: 'STORE_FILTER',
  CLEAN_TRANSACTION: 'CLEAN_TRANSACTION',
  CLEAN_FILTERED_TRANSACTIONS: 'CLEAN_FILTERED_TRANSACTIONS',
  CACHE_TRANSACTION: 'CACHE_TRANSACTION',
  CACHE_TRANSACTION_CONFIRMATION: 'CACHE_TRANSACTION_CONFIRMATION',
  GOT_REPORT: 'GOT_REPORT',
  GOT_REPORT_FAILED: 'GOT_REPORT_FAILED',
  GOT_RECON_REPORT: 'GOT_RECON_REPORT',
  GOT_RECON_REPORT_FAILED: 'GOT_RECON_REPORT_FAILED',
  CLEAN_REPORT: 'CLEAN_REPORT',
  CLEAN_RECON_REPORT: 'CLEAN_RECON_REPORT',
  CLEAN_FILTER: 'CLEAN_FILTER',
  GOT_PAYMENT_PROCESSOR_REMITTANCE: 'GOT_PAYMENT_PROCESSOR_REMITTANCE',
  GOT_PAYMENT_PROCESSOR_REMITTANCE_ERROR: 'GOT_PAYMENT_PROCESSOR_REMITTANCE_ERROR',
  GOT_PAYMENT_PROCESSOR_REMITTANCES: 'GOT_PAYMENT_PROCESSOR_REMITTANCES',
  GOT_PAYMENT_PROCESSOR_REMITTANCES_ERROR: 'GOT_PAYMENT_PROCESSOR_REMITTANCES_ERROR',
  CLEAN_PAYMENT_PROCESSOR_REMITTANCES: 'CLEAN_PAYMENT_PROCESSOR_REMITTANCES',
  CLEAN_CURRENT_REMITTANCE: 'CLEAN_CURRENT_REMITTANCE'
};

export function cleanTransaction (): Action {
  return {
    type: constants.CLEAN_FILTERED_TRANSACTIONS
  };
}

export function cleanReport (): Action {
  return {
    type: constants.CLEAN_REPORT
  };
}

export function cleanReconciliationReport (): Action {
  return {
    type: constants.CLEAN_RECON_REPORT
  };
}

export function cleanFilter (): Action {
  return {
    type: constants.CLEAN_FILTER
  };
}

export function cleanFilteredTransactions (): Action {
  return {
    type: constants.CLEAN_TRANSACTION,
    payload: {
      'applicationTransactionId': null,
      'transactionType': null,
      'internalStatusCode': null,
      'customer': null,
      'legalEntity': null,
      'accountNumber': null,
      'amount': null,
      'cardType': null,
      'cardNumberLast4Char': null,
      'processorName': null,
      'transactionDateTime': null
    }
  };
}

export function cacheTransactionConfirmation (value): Action {
  return {
    type: constants.CACHE_TRANSACTION_CONFIRMATION,
    payload: value
  };
}

export function cacheTransaction (value): Action {
  return {
    type: constants.CACHE_TRANSACTION,
    payload: value
  };
}

export function storeFilter (value): Action {
  return {
    type: constants.STORE_FILTER,
    payload: value
  };
}

export function createdTransaction (value): Action {
  return {
    type: constants.TRANSACTION_CREATED,
    payload: value
  };
}

export function getTransaction (id, type = 'SALE') {
  return {
    [CALL_API]: {
      types: [constants.RECEIVED_TRANSACTION, constants.GET_TRANSACTION_FAILED],
      endpoint: MICROSERVICE.TRANSACTIONS.GET + id + '?type=' + type,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getTransactions ({filter, page}) {
  return {
    [CALL_API]: {
      types: [constants.RECEIVED_TRANSACTIONS, constants.GET_TRANSACTIONS_FAILED],
      endpoint: MICROSERVICE.TRANSACTIONS.SEARCH + filter,
      authenticated: true,
      method: 'GET'
    }
  };
}

function receivedReport (value) {
  return {
    type: constants.GOT_REPORT,
    payload: value
  };
}

function receivedReconciliationReport (value) {
  return {
    type: constants.GOT_RECON_REPORT,
    payload: value
  };
}

export function downloadReport (filter) {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };
  let config = {
    method: 'GET',
    mode: 'cors',
    headers: {
      'X-Auth-Token': token
    }
  };

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.TRANSACTIONS.REPORT + filter, config)
      .then(response =>
        response.text().then((report) => ({report, response}))
      )
      .then(({report, response}) => {
        if (response.ok) {
          dispatch(receivedReport({report}));
        } else {
          try {
            const error = JSON.parse(report);
            return Promise.reject(error);
          } catch (e) {
            return Promise.reject(e);
          }
        }
      })
      .catch((e) => {
        return Promise.reject(e);
      });
  };
}

export function downloadReconciliationReport (filter) {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };
  let config = {
    method: 'GET',
    mode: 'cors',
    headers: {
      'X-Auth-Token': token
    }
  };

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.TRANSACTIONS.RECON_REPORT + filter, config)
      .then(response =>
        response.text().then((report) => ({report, response}))
      )
      .then(({report, response}) => {
        if (response.ok) {
          dispatch(receivedReconciliationReport({report}));
        } else {
          try {
            const error = JSON.parse(report);
            return Promise.reject(error);
          } catch (e) {
            return Promise.reject(e);
          }
        }
      })
      .catch((e) => {
        return Promise.reject(e);
      });
  };
}

export function voidTransaction (id, user, voidTransactionId) {
  return {
    [CALL_API]: {
      types: [constants.VOIDED_TRANSACTION, constants.VOID_TRANSACTION_FAILED],
      endpoint: '',
      authenticated: false,
      method: 'POST',
      body: JSON.stringify({
        VoidRequest: {
          transactionId: voidTransactionId,
          originalSaleTransactionId: id,
          pUser: user,
          application: 'GatewayPortal'
        }
      }),
      base: MIDDLEWARE.TRANSACTIONS.VOID,
      headers: {
        'Content-Type': 'text/plain;charset=UTF-8'
      },
      timeout: 145000
    }
  };
}

export function refundTransaction (id, amount, user, refundTransactionId) {
  return {
    [CALL_API]: {
      types: [constants.REFUNDED_TRANSACTION, constants.REFUND_TRANSACTION_FAILED],
      endpoint: '',
      authenticated: false,
      method: 'POST',
      body: JSON.stringify({
        RefundRequest: {
          transactionId: refundTransactionId,
          originalSaleTransactionId: id,
          amount,
          pUser: user,
          application: 'GatewayPortal'
        }
      }),
      base: MIDDLEWARE.TRANSACTIONS.REFUND,
      headers: {
        'Content-Type': 'text/plain;charset=UTF-8'
      },
      timeout: 145000
    }
  };
}

export function createTransaction (data) {
  return {
    [CALL_API]: {
      types: [constants.TRANSACTION_CREATED, constants.CREATE_TRANSACTION_FAILED],
      endpoint: '',
      authenticated: false,
      method: 'POST',
      body: JSON.stringify(data),
      base: MIDDLEWARE.TRANSACTIONS.SALE,
      headers: {
        'Content-Type': 'text/plain;charset=UTF-8'
      },
      timeout: 145000
    }
  };
}

export function getPaymentProcessorRemittance ({remittanceId, transactionType, processorTransactionType}) {
  const typeQuery = transactionType ? `?transactionType=${transactionType}` : '';
  const separator = typeQuery ? '&' : '?';
  const processorTypeQuery = processorTransactionType
    ? `${separator}processorTransactionType=${processorTransactionType}`
    : '';
  return {
    [CALL_API]: {
      types: [constants.GOT_PAYMENT_PROCESSOR_REMITTANCE, constants.GOT_PAYMENT_PROCESSOR_REMITTANCE_ERROR],
      endpoint: MICROSERVICE.REMITTANCES.GET + remittanceId + typeQuery + processorTypeQuery,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getPaymentProcessorRemittances ({filter, page}) {
  return {
    [CALL_API]: {
      types: [constants.GOT_PAYMENT_PROCESSOR_REMITTANCES, constants.GOT_PAYMENT_PROCESSOR_REMITTANCES_ERROR],
      endpoint: MICROSERVICE.REMITTANCES.SEARCH + filter,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function cleanPaymentProcessorRemittances (): Action {
  return {
    type: constants.CLEAN_PAYMENT_PROCESSOR_REMITTANCES,
    payload: []
  };
}

export function cleanCurrentRemittance () : Action {
  return {
    type: constants.CLEAN_CURRENT_REMITTANCE,
    payload: null
  };
}

// Reducer
export const initialState = {
  currentTransaction: {
    applicationTransactionId: '',
    accountNumber: '',
    address1: '',
    address2: '',
    amount: 0,
    application: '',
    approvalCode: '',
    cardNumberFirst6Char: '',
    cardNumberLast4Char: '',
    cardType: '',
    city: '',
    country: '',
    expiryDate: '',
    firstName: '',
    internalResponseCode: '',
    lastName: '',
    legalEntity: '',
    merchantId: '',
    origin: '',
    postalCode: '',
    processUser: '',
    processorName: '',
    processorResponseCode: '',
    processorResponseDescription: '',
    processorTransactionId: '',
    saleTransactionId: 0,
    state: '',
    statusDescription: '',
    testMode: 0,
    token: '',
    tokenized: 0,
    transactionDateTime: '',
    internalStatusCode: '',
    transactionType: ''
  },
  currentTransactions: {
    size: 0,
    responses: [],
    pendingTransactions: []
  },
  filteredTransactions: {},
  currentFilter: '',
  currentPage: 0,
  report: '',
  reconciliationReport: '',
  currentRemittance: null,
  paymentProcessorRemittances: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.RECEIVED_TRANSACTIONS:
      return Object.assign({}, state, {
        filteredTransactions: action.payload
      });
    case constants.RECEIVED_TRANSACTION:
      return Object.assign({}, state, {
        currentTransaction: action.payload
      });
    case constants.STORE_FILTER:
      return Object.assign({}, state, {
        currentFilter: action.payload.filter,
        currentPage: action.payload.page,
        currentTimeZone: action.payload.timeZone
      });
    case constants.CACHE_TRANSACTION:
      return Object.assign({}, state, {
        currentTransaction: action.payload
      });
    case constants.CACHE_TRANSACTION_CONFIRMATION:
      let responses = action.payload.responses.map((tran) => {
        if (tran.payload && (tran.payload.RefundResponse || tran.payload.VoidResponse)) {
          return tran.payload.RefundResponse || tran.payload.VoidResponse || {};
        } else {
          return tran;
        }
      });

      return Object.assign({}, state, {
        currentTransactions: {
          size: responses.length,
          responses,
          pendingTransactions: action.payload.pendingTransactions
        }
      });
    case constants.CLEAN_TRANSACTION:
      return Object.assign({}, state, {
        currentTransaction: action.payload
      });
    case constants.CLEAN_REPORT:
      return Object.assign({}, state, {
        report: ''
      });
    case constants.CLEAN_RECON_REPORT:
      return Object.assign({}, state, {
        reconciliationReport: ''
      });
    case constants.CLEAN_FILTERED_TRANSACTIONS:
      return Object.assign({}, state, {
        filteredTransactions: {},
        currentTransactions: []
      });
    case constants.GOT_REPORT:
      return Object.assign({}, state, {
        report: action.payload.report
      });
    case constants.GOT_RECON_REPORT:
      return Object.assign({}, state, {
        reconciliationReport: action.payload.report
      });
    case constants.CLEAN_FILTER:
      return Object.assign({}, state, {
        currentFilter: ''
      });
    case constants.GOT_PAYMENT_PROCESSOR_REMITTANCE:
      return Object.assign({}, state, {
        currentRemittance: action.payload
      });
    case constants.GOT_PAYMENT_PROCESSOR_REMITTANCES:
      return Object.assign({}, state, {
        paymentProcessorRemittances: action.payload
      });
    case constants.CLEAN_PAYMENT_PROCESSOR_REMITTANCES:
      return Object.assign({}, state, {
        paymentProcessorRemittances: action.payload
      });
    case constants.CLEAN_CURRENT_REMITTANCE:
      return Object.assign({}, state, {
        currentRemittance: action.payload
      });
    default:
      return state;
  }
}
