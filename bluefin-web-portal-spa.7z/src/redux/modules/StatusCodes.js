import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

// Constants
export const constants = {
  INSERT_STATUS_CODE: 'INSERT_STATUS_CODE',
  INSERTED_STATUS_CODE: 'INSERTED_STATUS_CODE',
  INSERT_STATUS_CODE_FAILED: 'INSERT_STATUS_CODE_FAILED',
  UPDATE_STATUS_CODE: 'UPDATE_STATUS_CODE',
  UPDATED_STATUS_CODE: 'UPDATED_STATUS_CODE',
  UPDATE_STATUS_CODE_FAILED: 'UPDATE_STATUS_CODE_FAILED',
  GET_STATUS_CODES: 'GET_STATUS_CODES',
  GOT_STATUS_CODES: 'GOT_STATUS_CODES',
  GOT_STATUS_CODES_FAILED: 'GOT_STATUS_CODES_FAILED',
  DELETE_STATUS_CODE: 'DELETE_STATUS_CODE',
  DELETED_STATUS_CODE: 'DELETED_STATUS_CODE',
  DELETED_STATUS_CODE_FAILED: 'DELETED_STATUS_CODE_FAILED',
  MODIFY_STATUS_CODE: 'MODIFY_STATUS_CODE',
  CLEAR_STATUS_CODES: 'CLEAR_STATUS_CODES'
};

function getStatusCodesRows (statusCodes) {
  let statusCodesRows = {};

  statusCodes.forEach((statusCode) => {
    const newRow = {};
    newRow.internalStatusCode = statusCode.internalStatusCode;
    newRow.internalStatusCodeDescription = statusCode.internalStatusCodeDescription;
    newRow.transactionTypeName = statusCode.transactionTypeName;
    newRow.processorStatusCodes = {};

    statusCode.paymentProcessorInternalStatusCodes &&
    statusCode.paymentProcessorInternalStatusCodes.forEach((processorCode) => {
      if (!newRow.processorStatusCodes[processorCode.paymentProcessorStatusCode.processorId]) {
        newRow.processorStatusCodes[processorCode.paymentProcessorStatusCode.processorId] = {};
      }
      const procId = processorCode.paymentProcessorStatusCode.processorId;
      const intCodeId = processorCode.paymentProcessorInternalStatusCodeId;
      newRow.processorStatusCodes[procId][intCodeId] = processorCode;
    });
    statusCodesRows[statusCode.internalStatusCodeId] = newRow;
  });

  return statusCodesRows;
}

function getEmptyStatusCode (transactionTypeName = '') {
  return {
    internalStatusCode: false,
    internalStatusCodeDescription: '',
    transactionTypeName,
    processorStatusCodes: {}
  };
}

function getEmptyProcessorCode () {
  return {
    paymentProcessorStatusCodeId: null,
    paymentProcessorStatusCode: '',
    paymentProcessorStatusCodeDescription: ''

  };
}

export function insertStatusCode (statusCode) {
  return {
    [CALL_API]: {
      types: [constants.INSERTED_STATUS_CODE, constants.INSERT_STATUS_CODE_FAILED],
      endpoint: MICROSERVICE.STATUS_CODES.CRUD,
      authenticated: true,
      body: JSON.stringify(statusCode),
      method: 'POST'
    }
  };
}

export function updateStatusCode (statusCode) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_STATUS_CODE, constants.UPDATE_STATUS_CODE_FAILED],
      endpoint: MICROSERVICE.STATUS_CODES.CRUD,
      authenticated: true,
      body: JSON.stringify(statusCode),
      method: 'PUT'
    }
  };
}

function _getStatusCodes (transactionType, extended) {
  const endpoint = MICROSERVICE.STATUS_CODES.CRUD +
    '?transactionType=' + transactionType +
    (extended ? '&extended=true' : '');
  return {
    [CALL_API]: {
      types: [constants.GOT_STATUS_CODES, constants.GOT_STATUS_CODES_FAILED],
      endpoint,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getStatusCodes (transactionType = 'SALE', extended = false) {
  return (dispatch) => {
    return dispatch(_getStatusCodes(transactionType, extended));
  };
}

export function deleteStatusCode (statusCode) {
  const { internalCodeId } = statusCode;
  return {
    [CALL_API]: {
      types: [constants.DELETED_STATUS_CODE, constants.DELETED_STATUS_CODE_FAILED],
      endpoint: MICROSERVICE.STATUS_CODES.CRUD + internalCodeId,
      authenticated: true,
      method: 'DELETE'
    }
  };
}

function _modifyStatusCode (statusCodeId, processorCodeId,
  paymentProcessorId, fieldName, value, transactionTypeName) {
  return {
    type: constants.MODIFY_STATUS_CODE,
    payload: {
      statusCodeId,
      processorCodeId,
      paymentProcessorId,
      fieldName,
      value,
      transactionTypeName
    }
  };
}

export function modifyStatusCode (statusCodeId, processorCodeId,
  paymentProcessorId, fieldName, value, transactionTypeName) {
  return (dispatch) => {
    return dispatch(_modifyStatusCode(statusCodeId, processorCodeId,
      paymentProcessorId, fieldName, value, transactionTypeName));
  };
}

function _clearStatusCodes () {
  return {
    type: constants.CLEAR_STATUS_CODES
  };
}

export function clearStatusCodes () {
  return (dispatch) => {
    return dispatch(_clearStatusCodes());
  };
}

// Reducer
export const initialState = {
  statusCodesRows: {},
  statusCodes: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.INSERTED_STATUS_CODE:
      return Object.assign({}, state, {
        currentStatusCode: action.payload
      });
    case constants.UPDATED_STATUS_CODE:
      return Object.assign({}, state, {
        currentStatusCode: action.payload
      });
    case constants.GOT_STATUS_CODES:
      return Object.assign({}, state, {
        statusCodes: action.payload,
        statusCodesRows: getStatusCodesRows(action.payload)
      });
    case constants.CLEAR_STATUS_CODES:
      const clearedRows = getStatusCodesRows(state.statusCodes);
      return Object.assign({}, state, {statusCodesRows: clearedRows});
    case constants.DELETED_STATUS_CODE:
      return Object.assign({});
    case constants.MODIFY_STATUS_CODE:
      let statusCodesRows = Object.assign({}, state.statusCodesRows);

      const { statusCodeId, processorCodeId,
        paymentProcessorId, fieldName, value, transactionTypeName } = action.payload;

      let statusCode = statusCodesRows[statusCodeId] || getEmptyStatusCode(transactionTypeName);

      if (!paymentProcessorId) {
        statusCode[fieldName] = value;
      } else {
        let processorCodes = statusCode.processorStatusCodes[paymentProcessorId] || {};
        let processorCode = (processorCodes[processorCodeId] &&
          processorCodes[processorCodeId].paymentProcessorStatusCode) ||
          getEmptyProcessorCode();
        processorCode[fieldName] = value;
        processorCode.processorId = paymentProcessorId;

        processorCodes[processorCodeId] = processorCodes[processorCodeId] || {};
        processorCodes[processorCodeId].paymentProcessorStatusCode = processorCode;
        statusCode.processorStatusCodes[paymentProcessorId] = processorCodes;
      }

      statusCodesRows[statusCodeId] = statusCode;

      return Object.assign({}, state, {statusCodesRows});
    default:
      return state;
  }
}
