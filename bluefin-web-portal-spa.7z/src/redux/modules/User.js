import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';
import { objectArrayToString } from '../../utils/utils';

// Constants
export const constants = {
  CREATE_USER: 'bluefin.users.CREATE_USER',
  CREATED_USER: 'bluefin.users.CREATED_USER',
  CREATE_USER_FAILED: 'bluefin.users.CREATE_USER_FAILED',
  GET_USER: 'bluefin.users.GET_USER',
  GOT_USER: 'bluefin.users.GOT_USER',
  GOT_USER_FAILED: 'bluefin.users.GOT_USER_FAILED',
  GET_USERS: 'bluefin.users.GET_USERS',
  GOT_USERS: 'bluefin.users.GOT_USERS',
  GOT_USERS_FAILED: 'bluefin.users.GOT_USERS_FAILED',
  DELETE_USER: 'bluefin.users.DELETE_USER',
  DELETED_USER: 'bluefin.users.DELETED_USER',
  DELETE_USER_FAILED: 'bluefin.users.DELETE_USER_FAILED',
  UPDATE_USER: 'bluefin.users.UPDATE_USER',
  UPDATED_USER: 'bluefin.users.UPDATED_USER',
  UPDATE_USER_FAILED: 'bluefin.users.UPDATE_USER_FAILED',
  UPDATE_USER_ROLES: 'bluefin.users.UPDATE_USER_ROLES',
  UPDATED_USER_ROLES: 'bluefin.users.UPDATED_USER_ROLES',
  UPDATE_USER_ROLES_FAILED: 'bluefin.users.UPDATE_USER_ROLES_FAILED',
  UPDATE_USER_LEGAL_ENTITIES: 'bluefin.users.UPDATE_USER_LEGAL_ENTITIES',
  UPDATED_USER_LEGAL_ENTITIES: 'bluefin.users.UPDATED_USER_LEGAL_ENTITIES',
  UPDATE_USER_LEGAL_ENTITIES_FAILED: 'bluefin.users.UPDATE_USER_LEGAL_ENTITIES_FAILED',
  CLEAN_USER: 'bluefin.users.CLEAN_USER',
  CLEAN_USERS: 'bluefin.users.CLEAN_USERS',
  STORE_FILTER: 'bluefin.users.STORE_FILTER',
  SELECT_USER: 'bluefin.users.SELECT_USER',
  CLEAR_SELECTED_USERS: 'bluefin.users.CLEAR_SELECTED_USERS',
  UPDATED_USER_ACTIVATION: 'bluefin.users.UPDATED_USER_ACTIVATION',
  UPDATE_USER_ACTIVATION_FAILED: 'bluefin.users.UPDATE_USER_ACTIVATION_FAILED'
};

// Action Creators

export function cleanUser (): Action {
  return {
    type: constants.CLEAN_USER,
    payload: {
      email: '',
      firstName: '',
      lastName: '',
      legalEntityApps: [],
      roles: [],
      username: ''
    }
  };
}

export function storeFilter (value): Action {
  return {
    type: constants.STORE_FILTER,
    payload: value
  };
}

export function createUser (user) {
  return {
    [CALL_API]: {
      types: [constants.CREATED_USER, constants.CREATE_USER_FAILED],
      endpoint: MICROSERVICE.USERS.CRUD,
      authenticated: true,
      body: JSON.stringify(user),
      method: 'POST'
    }
  };
}

export function getUser (username) {
  return {
    [CALL_API]: {
      types: [constants.GOT_USER, constants.GOT_USER_FAILED],
      endpoint: MICROSERVICE.USERS.CRUD + username,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function cleanUsers () {
  return {
    type: constants.CLEAN_USERS
  };
}

export function getUsers ({filter = '', page = 0, size = 15} = {}) {
  return {
    [CALL_API]: {
      types: [constants.GOT_USERS, constants.GOT_USERS_FAILED],
      endpoint: MICROSERVICE.USERS.SEARCH + filter + `&page=${page}&size=${size}&sort=username:asc`,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function deleteUser (username) {
  return {
    [CALL_API]: {
      types: [constants.DELETE_USER, constants.DELETE_USER_FAILED],
      endpoint: MICROSERVICE.USERS.CRUD + username,
      authenticated: true,
      method: 'DELETE'
    }
  };
}

export function updateUser (username, user) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_USER, constants.UPDATE_USER_FAILED],
      endpoint: MICROSERVICE.USERS.CRUD + username,
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(user)
    }
  };
}

export function updateUserRoles (username, roles) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_USER_ROLES, constants.UPDATE_USER_ROLES_FAILED],
      endpoint: MICROSERVICE.USERS.CRUD + username + '/roles',
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(roles)
    }
  };
}

export function updateUserEntities (username, entities) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_USER_LEGAL_ENTITIES, constants.UPDATE_USER_LEGAL_ENTITIES_FAILED],
      endpoint: MICROSERVICE.USERS.CRUD + username + '/legal-entities',
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(entities)
    }
  };
}

export function updateUserActivation (activate = true, usernames = []) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_USER_ACTIVATION, constants.UPDATE_USER_ACTIVATION_FAILED],
      endpoint: MICROSERVICE.USERS.STATUS,
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify({activate, usernames})
    }
  };
}

export function selectUser (payload) {
  return {
    type: constants.SELECT_USER,
    payload: payload
  };
}

export function clearSelectedUsers () {
  return {
    type: constants.CLEAR_SELECTED_USERS
  };
}

function updateSelectedUsers (payload, selectedUsers) {
  const newSelectedUsers = [].concat(selectedUsers);
  const { checked, item: { username } } = payload;
  if (checked) {
    newSelectedUsers.includes(username) || newSelectedUsers.push(username);
  } else {
    selectedUsers.includes(username) &&
      newSelectedUsers.splice(newSelectedUsers.indexOf(username), 1);
  }
  return newSelectedUsers;
}

// Reducer
export const initialState = {
  currentUser: {
    email: '',
    firstName: '',
    lastName: '',
    legalEntityApps: [],
    roles: [],
    username: ''
  },
  selectedUsers: [],
  filteredUsers: {},
  currentUserFilter: ''
};
export default function (state = initialState, action) {
  switch (action.type) {
    case constants.UPDATED_USER:
      return Object.assign({}, state, {
        currentUser: parseUser(action.payload)
      });
    case constants.UPDATED_USER_LEGAL_ENTITIES:
      return Object.assign({}, state, {
        currentUser: parseUser(action.payload)
      });
    case constants.UPDATED_USER_ROLES:
      return Object.assign({}, state, {
        currentUser: parseUser(action.payload)
      });
    case constants.CREATED_USER:
      return Object.assign({}, state, {
        currentUser: parseUser(action.payload)
      });
    case constants.GOT_USER:
      return Object.assign({}, state, {
        currentUser: parseUser(action.payload)
      });
    case constants.GOT_USERS:
      return Object.assign({}, state, {
        filteredUsers: action.payload
      });
    case constants.DELETED_USER:
      return Object.assign({});
    case constants.CLEAN_USER:
      return Object.assign({}, state, {
        currentUser: action.payload
      });
    case constants.CLEAN_USERS:
      return Object.assign({}, state, {
        filteredUsers: {}
      });
    case constants.STORE_FILTER:
      return Object.assign({}, state, {
        currentUserFilter: action.payload
      });
    case constants.CLEAR_SELECTED_USERS:
      return Object.assign({}, state, {
        selectedUsers: []
      });
    case constants.SELECT_USER:
      return Object.assign({}, state, {
        selectedUsers: updateSelectedUsers(action.payload, state.selectedUsers)
      });
    default:
      return state;
  }

  function parseUser (user) {
    const legalEntityApps = objectArrayToString(user.legalEntityApps);
    const roles = objectArrayToString(user.roles);

    return Object.assign({}, user, {
      legalEntityApps,
      roles
    });
  }
}
