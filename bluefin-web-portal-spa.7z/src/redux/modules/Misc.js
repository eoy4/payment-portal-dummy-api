import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';
import moment from 'moment';

// Constants
export const constants = {
  GOT_ENTITIES: 'GOT_ENTITIES',
  GET_ENTITIES_FAILED: 'GET_ENTITIES_FAILED',
  GOT_ROLES: 'GOT_ROLES',
  GET_ROLES_FAILED: 'GET_ROLES_FAILED',
  GOT_LOCATION: 'GOT_LOCATION',
  GET_LOCATION_FAILED: 'GET_LOCATION_FAILED',
  BLOCK_UI: 'BLOCK_UI',
  UNBLOCK_UI: 'UNBLOCK_UI',
  CLEAN_LOCATION: 'CLEAN_LOCATION',
  GOT_APPLICATIONS: 'GOT_APPLICATIONS',
  GET_APPLICATIONS_FAILED: 'GET_APPLICATIONS_FAILED',
  GOT_PAYMENT_FREQUENCIES: 'GOT_PAYMENT_FREQUENCIES',
  GET_PAYMENT_FREQUENCIES_FAILED: 'GET_PAYMENT_FREQUENCIES_FAILED',
  GOT_RECONCILIATION_STATUS: 'GOT_RECONCILIATION_STATUS',
  GET_RECONCILIATION_STATUS_FAILED: 'GET_RECONCILIATION_STATUS_FAILED',
  GET_TIMEZONE: 'GET_TIMEZONE',
  SET_TIMEZONE: 'SET_TIMEZONE',
  SET_AND_SAVE_TIMEZONE: 'SET_AND_SAVE_TIMEZONE'
};

// Action Creators

export function blockUI (loading = true, prompt = '', callbackOk = null, callbackCancel = null) {
  return {
    type: constants.BLOCK_UI,
    loading,
    prompt,
    callbackOk,
    callbackCancel
  };
}

export function unblockUI () {
  return {
    type: constants.UNBLOCK_UI
  };
}

export function getApplications () {
  return {
    [CALL_API]: {
      types: [constants.GOT_APPLICATIONS, constants.GET_APPLICATIONS_FAILED],
      endpoint: MICROSERVICE.APPLICATION.GET,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getPaymentFrequencies () {
  return {
    [CALL_API]: {
      types: [constants.GOT_PAYMENT_FREQUENCIES, constants.GET_PAYMENT_FREQUENCIES_FAILED],
      endpoint: MICROSERVICE.PAYMENT_FREQUENCIES.GET,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getReconciliationStatus () {
  return {
    [CALL_API]: {
      types: [constants.GOT_RECONCILIATION_STATUS, constants.GET_RECONCILIATION_STATUS_FAILED],
      endpoint: MICROSERVICE.RECONCILIATION_STATUS.GET,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function cleanLocation () {
  return {
    type: constants.CLEAN_LOCATION
  };
}

export function getEntities () {
  return {
    [CALL_API]: {
      types: [constants.GOT_ENTITIES, constants.GET_ENTITIES_FAILED],
      endpoint: MICROSERVICE.LEGAL_ENTITIES.GET,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getRoles () {
  return {
    [CALL_API]: {
      types: [constants.GOT_ROLES, constants.GET_ROLES_FAILED],
      endpoint: MICROSERVICE.ROLES.GET,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getLocation (country, zip) {
  return {
    [CALL_API]: {
      types: [constants.GOT_LOCATION, constants.GET_LOCATION_FAILED],
      base: 'https://api.zippopotam.us/',
      endpoint: `${country}/${zip}`,
      authenticated: false,
      method: 'GET',
      removeHeaders: true
    }
  };
}

export function getTimeZone () {
  return {
    type: constants.GET_TIMEZONE
  };
}

export function setTimeZone (tz): Action {
  return {
    type: constants.SET_TIMEZONE,
    payload: tz
  };
}

export function setAndSaveTimeZone (tz): Action {
  return {
    type: constants.SET_AND_SAVE_TIMEZONE,
    payload: tz
  };
}

// Reducer
export const initialState = {
  roles: [],
  legalEntities: [],
  reconciliationStatus: [],
  reconciliationStatusMap: null,
  applications: [],
  paymentFrequencies: [],
  location: {},
  loading: false,
  prompt: '',
  callbackOk: null,
  callbackCancel: null,
  timeZone: ''
};

function defaultTimeZone () {
  const tz = localStorage.getItem('timeZone');
  if (tz == null) {
    const tzName = moment.tz.guess();
    const currentTz = tzName;
    localStorage.setItem('timeZone', currentTz);
    return currentTz;
  } else {
    return tz;
  }
}

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.GET_TIMEZONE:
      const tz = defaultTimeZone();
      return Object.assign({}, state, {
        timeZone: tz
      });
    case constants.SET_AND_SAVE_TIMEZONE:
      localStorage.setItem('timeZone', action.payload);
      return Object.assign({}, state, {
        timeZone: action.payload
      });
    case constants.SET_TIMEZONE:
      return Object.assign({}, state, {
        timeZone: action.payload
      });
    case constants.GOT_ROLES:
      return Object.assign({}, state, {
        roles: action.payload
      });
    case constants.GOT_ENTITIES:
      return Object.assign({}, state, {
        legalEntities: action.payload
      });
    case constants.GOT_RECONCILIATION_STATUS:
      const reconciliationStatusMap = new Map();
      const reconciliationStatus = action.payload;
      reconciliationStatus.forEach((status) => {
        reconciliationStatusMap.set(status.reconciliationStatusId, status);
      });
      return Object.assign({}, state, {
        reconciliationStatus: action.payload,
        reconciliationStatusMap
      });
    case constants.GOT_LOCATION:
      const { country, places } = action.payload;
      return Object.assign({}, state, {
        location: {
          state: places[0]['state abbreviation'],
          city: places[0]['place name'],
          country
        }
      });
    case constants.UNBLOCK_UI:
      return Object.assign({}, state, {
        loading: false,
        prompt: '',
        callbackOk: null,
        callbackCancel: null
      });
    case constants.CLEAN_LOCATION:
      return Object.assign({}, state, {
        location: {}
      });
    case constants.BLOCK_UI:
      const { loading, prompt, callbackOk, callbackCancel } = action;
      return Object.assign({}, state, {
        loading,
        prompt,
        callbackOk,
        callbackCancel
      });
    case constants.GOT_APPLICATIONS:
      return Object.assign({}, state, {
        applications: action.payload
      });
    case constants.GOT_PAYMENT_FREQUENCIES:
      return Object.assign({}, state, {
        paymentFrequencies: action.payload
      });
    default:
      return state;
  }
}
