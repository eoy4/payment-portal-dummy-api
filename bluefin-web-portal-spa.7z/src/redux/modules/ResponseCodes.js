import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

// Constants
export const constants = {
  INSERT_RESPONSE_CODE: 'INSERT_RESPONSE_CODE',
  INSERTED_RESPONSE_CODE: 'INSERTED_RESPONSE_CODE',
  INSERT_RESPONSE_CODE_FAILED: 'INSERT_RESPONSE_CODE_FAILED',
  UPDATE_RESPONSE_CODE: 'UPDATE_RESPONSE_CODE',
  UPDATED_RESPONSE_CODE: 'UPDATED_RESPONSE_CODE',
  UPDATE_RESPONSE_CODE_FAILED: 'UPDATE_RESPONSE_CODE_FAILED',
  GET_RESPONSE_CODES: 'GET_RESPONSE_CODES',
  GOT_RESPONSE_CODES: 'GOT_RESPONSE_CODES',
  GOT_RESPONSE_CODES_FAILED: 'GOT_RESPONSE_CODES_FAILED',
  DELETE_RESPONSE_CODE: 'DELETE_RESPONSE_CODE',
  DELETED_RESPONSE_CODE: 'DELETED_RESPONSE_CODE',
  DELETED_RESPONSE_CODE_FAILED: 'DELETED_RESPONSE_CODE_FAILED',
  MODIFY_RESPONSE_CODE: 'MODIFY_RESPONSE_CODE',
  CLEAR_RESPONSE_CODES: 'CLEAR_RESPONSE_CODES'
};

function getResponseCodesRows (responseCodes) {
  let responseCodesRows = {};

  responseCodes.forEach((responseCode) => {
    const newRow = {};
    newRow.internalResponseCode = responseCode.internalResponseCode;
    newRow.internalResponseCodeDescription = responseCode.internalResponseCodeDescription;
    newRow.transactionTypeName = responseCode.transactionTypeName;
    newRow.processorResponseCodes = {};

    responseCode.paymentProcessorInternalResponseCodes &&
    responseCode.paymentProcessorInternalResponseCodes.forEach((processorCode) => {
      if (!newRow.processorResponseCodes[processorCode.paymentProcessorResponseCode.processorId]) {
        newRow.processorResponseCodes[processorCode.paymentProcessorResponseCode.processorId] = {};
      }
      const procId = processorCode.paymentProcessorResponseCode.processorId;
      const intCodeId = processorCode.paymentProcessorInternalResponseCodeId;
      newRow.processorResponseCodes[procId][intCodeId] = processorCode;
    });
    responseCodesRows[responseCode.internalResponseCodeId] = newRow;
  });

  return responseCodesRows;
}

function getEmptyResponseCode (transactionTypeName = '') {
  return {
    internalResponseCode: false,
    internalResponseCodeDescription: '',
    transactionTypeName,
    processorResponseCodes: {}
  };
}

function getEmptyProcessorCode () {
  return {
    paymentProcessorResponseCodeId: null,
    paymentProcessorResponseCode: '',
    paymentProcessorResponseCodeDescription: ''

  };
}

export function insertResponseCode (responseCode) {
  return {
    [CALL_API]: {
      types: [constants.INSERTED_RESPONSE_CODE, constants.INSERT_RESPONSE_CODE_FAILED],
      endpoint: MICROSERVICE.RESPONSE_CODES.CRUD,
      authenticated: true,
      body: JSON.stringify(responseCode),
      method: 'POST'
    }
  };
}

export function updateResponseCode (responseCode) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_RESPONSE_CODE, constants.UPDATE_RESPONSE_CODE_FAILED],
      endpoint: MICROSERVICE.RESPONSE_CODES.CRUD,
      authenticated: true,
      body: JSON.stringify(responseCode),
      method: 'PUT'
    }
  };
}

function _getResponseCodes (transactionType, extended) {
  const endpoint = MICROSERVICE.RESPONSE_CODES.CRUD +
    '?transactionType=' + transactionType +
    (extended ? '&extended=true' : '');
  return {
    [CALL_API]: {
      types: [constants.GOT_RESPONSE_CODES, constants.GOT_RESPONSE_CODES_FAILED],
      endpoint,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getResponseCodes (transactionType = 'SALE', extended = false) {
  return (dispatch) => {
    return dispatch(_getResponseCodes(transactionType, extended));
  };
}

export function deleteResponseCode (responseCode) {
  const { internalCodeId } = responseCode;
  return {
    [CALL_API]: {
      types: [constants.DELETED_RESPONSE_CODE, constants.DELETED_RESPONSE_CODE_FAILED],
      endpoint: MICROSERVICE.RESPONSE_CODES.CRUD + internalCodeId,
      authenticated: true,
      method: 'DELETE'
    }
  };
}

function _modifyResponseCode (responseCodeId, processorCodeId,
  paymentProcessorId, fieldName, value, transactionTypeName) {
  return {
    type: constants.MODIFY_RESPONSE_CODE,
    payload: {
      responseCodeId,
      processorCodeId,
      paymentProcessorId,
      fieldName,
      value,
      transactionTypeName
    }
  };
}

export function modifyResponseCode (responseCodeId, processorCodeId,
  paymentProcessorId, fieldName, value, transactionTypeName) {
  return (dispatch) => {
    return dispatch(_modifyResponseCode(responseCodeId, processorCodeId,
      paymentProcessorId, fieldName, value, transactionTypeName));
  };
}

function _clearResponseCodes () {
  return {
    type: constants.CLEAR_RESPONSE_CODES
  };
}

export function clearResponseCodes () {
  return (dispatch) => {
    return dispatch(_clearResponseCodes());
  };
}

// Reducer
export const initialState = {
  responseCodesRows: {},
  responseCodes: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.INSERTED_RESPONSE_CODE:
      return Object.assign({}, state, {
        currentResponseCode: action.payload
      });
    case constants.UPDATED_RESPONSE_CODE:
      return Object.assign({}, state, {
        currentResponseCode: action.payload
      });
    case constants.GOT_RESPONSE_CODES:
      return Object.assign({}, state, {
        responseCodes: action.payload,
        responseCodesRows: getResponseCodesRows(action.payload)
      });
    case constants.CLEAR_RESPONSE_CODES:
      const clearedRows = getResponseCodesRows(state.responseCodes);
      return Object.assign({}, state, {responseCodesRows: clearedRows});
    case constants.DELETED_RESPONSE_CODE:
      return Object.assign({});
    case constants.MODIFY_RESPONSE_CODE:
      let responseCodesRows = Object.assign({}, state.responseCodesRows);

      const { responseCodeId, processorCodeId,
        paymentProcessorId, fieldName, value, transactionTypeName } = action.payload;

      let responseCode = responseCodesRows[responseCodeId] || getEmptyResponseCode(transactionTypeName);

      if (!paymentProcessorId) {
        responseCode[fieldName] = value;
      } else {
        let processorCodes = responseCode.processorResponseCodes[paymentProcessorId] || {};
        let processorCode = (processorCodes[processorCodeId] &&
          processorCodes[processorCodeId].paymentProcessorResponseCode) ||
          getEmptyProcessorCode();
        processorCode[fieldName] = value;
        processorCode.processorId = paymentProcessorId;

        processorCodes[processorCodeId] = processorCodes[processorCodeId] || {};
        processorCodes[processorCodeId].paymentProcessorResponseCode = processorCode;
        responseCode.processorResponseCodes[paymentProcessorId] = processorCodes;
      }

      responseCodesRows[responseCodeId] = responseCode;

      return Object.assign({}, state, {responseCodesRows});
    default:
      return state;
  }
}
