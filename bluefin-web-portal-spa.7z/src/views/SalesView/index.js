import SalesView from './SalesView';
export default SalesView;
