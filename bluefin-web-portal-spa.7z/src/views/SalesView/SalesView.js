/* @flow */
import React from 'react';
import SaleTransaction from '../../containers/SaleTransaction';

export class SalesView extends React.Component {

  render () {
    return (
      <div id='sale-transaction'>
        <SaleTransaction />
      </div>
    );
  }
}

export default SalesView;
