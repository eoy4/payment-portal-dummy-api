import ReportsView from './ReportsView';
export default ReportsView;
