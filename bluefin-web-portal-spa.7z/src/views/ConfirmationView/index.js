import ConfirmationView from './ConfirmationView';
export default ConfirmationView;
