import React from 'react';
import ProcessorToMerchants from '../../containers/ProcessorToMerchants';

type Props = {

};
export class ProcessorToMerchantsView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='processor-merchants'>
        <h1 className='page-header' id='processor-merchants-h1'>Assign Merchant IDs to Payment Processors</h1>
        <ProcessorToMerchants {...this.props} />
      </div>
    );
  }
}

export default ProcessorToMerchantsView;
