/* @flow */
import React from 'react';

export class HomeView extends React.Component {
  render () {
    const styles = {
      padding: '0 30px 30px'
    };

    return (
      <div style={styles}>
        <h1>Welcome to the Bluefin Portal.</h1>
      </div>
    );
  }
}

export default HomeView;
