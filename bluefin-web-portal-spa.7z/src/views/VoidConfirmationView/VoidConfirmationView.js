import React from 'react';
import ConfirmedTransactions from '../../containers/ConfirmedTransactions';

type Props = {

};
export class VoidConfirmation extends React.Component {
  props: Props;

  render () {
    return (
      <div id='void-confirmation'>
        <ConfirmedTransactions {... this.props} message={'Transactions Summary'} />
      </div>
    );
  }
}

export default VoidConfirmation;
