import VoidConfirmationView from './VoidConfirmationView';
export default VoidConfirmationView;
