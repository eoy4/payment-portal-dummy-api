import ProcessorRulesView from './ProcessorRulesView';
export default ProcessorRulesView;
