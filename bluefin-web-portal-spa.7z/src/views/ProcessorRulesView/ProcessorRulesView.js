import React from 'react';
import ProcessorRules from '../../containers/ProcessorRules';

type Props = {

};
export class ProcessorRulesView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div className='processor-rules-view' style={styles} id='processor-rules'>
        <h1 className='page-header' id='payment-processor-rules-h1'>Payment Processor Rules</h1>
        <ProcessorRules {...this.props} />
      </div>
    );
  }
}

export default ProcessorRulesView;
