import React from 'react';
import PasswordRecovery from '../../containers/PasswordRecovery';

type Props = {
  type: string,
  location: Object
};
export class PasswordRecoveryView extends React.Component {
  props: Props;

  componentDidMount () {
    if (this.props.location.pathname.indexOf('recover') === -1) {

    }
  }

  render () {
    const type = this.props.location.pathname.indexOf('recover') === -1 ? 'recover' : 'reset';
    return (
      <PasswordRecovery {... this.props} type={type} />
    );
  }
}

export default PasswordRecoveryView;
