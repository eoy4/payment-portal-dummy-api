import React from 'react';
import { default as RemittanceDetails } from '../../containers/RemittanceDetails';

type Props = {

};
export class RemittanceInformationView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='remittance-details'>
        <h1 className='page-header'>Transaction Reconciliation Details</h1>
        <RemittanceDetails {...this.props} />
      </div>
    );
  }
}

export default RemittanceInformationView;
