import React from 'react';
import LegalEntities from '../../containers/LegalEntities';

export class LegalEntitiesView extends React.Component {

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='legal-entities'>
        <h1 className='page-header' id='legal-entities-h1'>Legal Entities Management</h1>
        <LegalEntities {...this.props} />
      </div>
    );
  }
}

export default LegalEntitiesView;
