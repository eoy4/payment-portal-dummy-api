import {default as LegalEntitiesView} from './LegalEntitiesView';
export default LegalEntitiesView;
