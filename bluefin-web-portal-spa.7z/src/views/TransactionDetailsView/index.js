import TransactionDetailsView from './TransactionDetailsView';
export default TransactionDetailsView;
