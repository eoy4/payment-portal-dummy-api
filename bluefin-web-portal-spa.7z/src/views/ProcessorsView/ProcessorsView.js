import React from 'react';
import Processors from '../../containers/Processors';

export class ProcessorsView extends React.Component {

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='processors'>
        <h1 className='page-header'>Payment Processors Management</h1>
        <Processors {...this.props} />
      </div>
    );
  }
}

export default ProcessorsView;
