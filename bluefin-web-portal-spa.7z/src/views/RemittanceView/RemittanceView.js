import React from 'react';
import { connect } from 'react-redux';
import RemittanceSearch from '../../containers/RemittanceSearch';
import { Link } from 'react-router';

type Props = {
  accessRoles: Object
};
export class RemittanceView extends React.Component {
  props: Props;

  componentDidMount () {
    const { accessRoles } = this.props;
    if (!accessRoles['remittance']) {
      const { router } = this.context;
      router.replace({
        pathname: '/search/transactions'
      });
    }
  }

  clickStud (e) {
    e.preventDefault();
  }

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='remittance-search'>
        <h1 className='page-header'>Search & Reporting</h1>
        {
          this.props.accessRoles &&
          this.props.accessRoles['reports']
          ? <ul className='nav nav-tabs'>
            <li><Link to='/search/transactions'>Transactions</Link></li>
            <li className='active'><a href='#' onClick={this.clickStud}>Reconciliation</a></li>
          </ul>
          : null
        }
        <div className='tab-content'>
          <div className='tab-pane active'>
            <RemittanceSearch {... this.props} />
          </div>
        </div>
      </div>
    );
  }
}

RemittanceView.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

const mapStateToProps = (state) => {
  return {
    accessRoles: state.auth.accessRoles
  };
};

export default connect(
  mapStateToProps
)(RemittanceView);
