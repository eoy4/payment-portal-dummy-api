import VoidView from './VoidView';
export default VoidView;
