import React from 'react';
import UserUpdate from '../../containers/UserUpdate';

type Props = {

};
export class EditUser extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='edit-user'>
        <h1 className='page-header' id='edit-user-h1'>User Management</h1>
        <UserUpdate title={'Edit an existing user'} mode={'edit'} {...this.props} />
      </div>
    );
  }
}

export default EditUser;
