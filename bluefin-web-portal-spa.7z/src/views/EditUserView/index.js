import EditUserView from './EditUserView';
export default EditUserView;
