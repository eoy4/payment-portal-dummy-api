import React from 'react';
import StatusCodes from '../../containers/StatusCodes';

type Props = {

};
export class StatusCodesView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='status-codes'>
        <h1 className='page-header' id='status-codes-h1'>Status Codes Mapping</h1>
        <StatusCodes {...this.props} />
      </div>
    );
  }
}

export default StatusCodesView;
