import AboutView from './AboutView';
export default AboutView;
