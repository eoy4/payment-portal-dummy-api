import React from 'react';
import ResponseCodes from '../../containers/ResponseCodes';

type Props = {

};
export class ResponseCodesView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='response-codes'>
        <h1 className='page-header' id='response-codes-h1'>Response Codes Mapping</h1>
        <ResponseCodes {...this.props} />
      </div>
    );
  }
}

export default ResponseCodesView;
