import ResponseCodesView from './ResponseCodesView';
export default ResponseCodesView;
