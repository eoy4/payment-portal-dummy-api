import BatchFileDetailsView from './BatchFileDetailsView';
export default BatchFileDetailsView;
