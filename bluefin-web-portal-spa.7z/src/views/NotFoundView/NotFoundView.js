import React from 'react';
import { Link } from 'react-router';

type Props = {

};
export class NotFound extends React.Component {
  props: Props;

  render () {
    const styles = {
      margin: 'auto',
      width: '50%',
      textAlign: 'center',
      marginTop: '12%'
    };
    const button = {margin: '30px 10px 20px', padding: '12px 25px'};
    return (
      <div className="row" id='not-found'>
        <div className="col-md-12">
          <div style={styles} >
            <h1 className="text-warning"> Oops!</h1>
            <h1 className="text-danger">
              <strong>404</strong> Not Found</h1>
            <h3 className="text-muted">
                Sorry, an error has occured, Requested page not found!
            </h3>
            <div>
              <Link to="/" style={button} className="btn btn-primary btn-lg"> Take Me Home</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default NotFound;
