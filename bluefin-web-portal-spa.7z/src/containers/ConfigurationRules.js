import React from 'react';
import { connect } from 'react-redux';
// import ConfigurationRulesForm from '../forms/ConfigurationRulesForm';
// import { getRules } from '../redux/modules/Settings';
// import { getEntities } from '../redux/modules/Misc';
// import toastr from 'toastr';
import 'toastr/build/toastr.min.css';

type Props = {

}
export class ConfigurationRules extends React.Component {
  props: Props;

  render () {
    return (
      <div></div>
    );
  }
}

const mapStateToProps = (state) => {
  return {};
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConfigurationRules);
