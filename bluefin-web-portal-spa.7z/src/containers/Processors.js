import React from 'react';
import { connect } from 'react-redux';
import { getProcessors, createProcessor, updateProcessor } from '../redux/modules/Processor';
import { ProcessorRow } from '../components/ProcessorRow/ProcessorRow';
import { handleErrorToastr, handleSuccessToastr } from '../utils/utils';
import { blockUI, unblockUI, getTimeZone } from '../redux/modules/Misc';
import { default as moment } from 'moment';
import 'toastr/build/toastr.min.css';

type Props = {
  location: Object,
  paymentProcessors: Array,
  timeZone: string
}

export class Processors extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);

    this.state = {
      reloading: false
    };

    this.notifyChanges = this.notifyChanges.bind(this);
    this.confirmUpdate = this.confirmUpdate.bind(this);
    this.confirmDiscardChanges = this.confirmDiscardChanges.bind(this);
  }

  componentDidMount () {
    this.reloadData();
  }

  reloadData (successMessage = false) {
    const { store } = this.context;
    store.dispatch(blockUI());
    store.dispatch(getTimeZone());
    store.dispatch(getProcessors())
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      };
      this.resetData(successMessage);
    });
  }

  resetData (successMessage = false) {
    const { store } = this.context;
    store.dispatch(blockUI());

    this.setState({reloading: true, dirtyRows: []}, () => {
      store.dispatch(unblockUI());
      successMessage && handleSuccessToastr(successMessage);
      this.setState({reloading: false});
    });
  }

  notifyChanges (processorId) {
    this.addDirtyRow(processorId);
  }

  addDirtyRow (processorId) {
    let dirtyRows = Array.concat([], this.state.dirtyRows);
    if (!dirtyRows.includes(processorId)) {
      dirtyRows.push(processorId);
      this.setState({dirtyRows});
    }
  }

  confirmUpdate (processor) {
    const { store } = this.context;

    store.dispatch(blockUI(false, 'Do you want to save your changes? ' +
      'Please keep in mind this may potentially harm the system.',
      () => {
        this.handleUpdate(processor);
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  handleUpdate (processor) {
    const { store } = this.context;
    store.dispatch(blockUI());

    let action = {};
    let message = '';

    const dateTime = processor.remitTransactionCloseTime;
    processor.remitTransactionCloseTime =
      dateTime
      ? moment(dateTime, 'hh:mm:ss a')
        .utc()
        .format('HH:mm:ss')
      : null;
    // The field "remitTransactionOpenTime" was removed from the UI, but a default value of
    // 1 hour before "remitTransactionCloseTime" is being sent to the backend, because it has
    // not been removed from database. Remove the following 6 lines when it has been removed.
    processor.remitTransactionOpenTime =
      dateTime
      ? moment(dateTime, 'hh:mm:ss a')
        .subtract(1, 'hours')
        .format('HH:mm:ss')
      : null;

    if (processor.paymentProcessorId) {
      action = updateProcessor(processor.paymentProcessorId, processor);
      message = 'The Payment Processor was updated successfully';
    } else {
      action = createProcessor(processor);
      message = 'The Payment Processor was created successfully';
    }

    store.dispatch(action)
    .then((payload) => {
      if (payload.error) {
        this.resetData();
        handleErrorToastr(payload.error);
      } else {
        this.reloadData(message);
      }
    });
  }

  confirmDiscardChanges (event) {
    event.preventDefault && event.preventDefault();

    const {store} = this.context;

    store.dispatch(blockUI(false, 'Are you sure you want to discard your changes?',
      () => {
        this.resetData('Changes were discarded.');
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  render () {
    const { paymentProcessors } = this.props;
    const dirtyRows = this.state.dirtyRows || [];
    const page = (
      <div className='tab-content'>
        <div className='tab-pane active'>
          <div className='payment-processors'>
            <h2 className='sub-header'><i className='fa fa-table'></i> Edit Payment Processors</h2>
            <div className='table-responsive'>
              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th className='text-center'>Fully Integrated<sup>(1)</sup></th>
                    <th>Processor Name</th>
                    <th>Same Day Processing Time</th>
                    <th className='text-center'>Details</th>
                    <th className='text-center'>Activate</th>
                    <th className='text-center'>Save</th>
                  </tr>
                </thead>

                <tbody>
                  {paymentProcessors && paymentProcessors.map((processor, index) => {
                    return <ProcessorRow key={`processor-row-${index}`}
                      processor={processor}
                      confirmUpdate={this.confirmUpdate}
                      notifyChanges={this.notifyChanges}
                      dirty={dirtyRows.includes(processor.paymentProcessorId)}
                      timeZone={this.props.timeZone}
                    />;
                  })}
                </tbody>
              </table>
            </div>
            {
              dirtyRows.length
                ? <div className='unsaved-changes-notice'>
                  <p className='unsaved-changes-text'>
                    You have unsaved changes. Click  Save in each row that you modified.
                  </p>
                  <div className='text-center'>
                    <button className='btn btn-default discard-changes'
                      onClick={this.confirmDiscardChanges}
                    >
                      <i className='glyphicon glyphicon-remove-sign'></i>
                      &nbsp;
                      Discard Changes
                    </button>
                  </div>
                </div>
                : null
            }

            <div className='info-notes'>
              <sup>(1)</sup> According to the Payment Processor Readiness Checklist. Click on 'Details'
              (<i className='glyphicon glyphicon-list'></i>) to see the Checklist for each Processor.
            </div>

            <hr />

            <h2 className='sub-header'>
              <i className='glyphicon glyphicon-plus-sign'></i> Create a new Payment Processor
            </h2>

            <div className='table-responsive'>
              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th>Processor Name</th>
                    <th>Same Day Processing Time</th>
                    <th className='text-center'>Save</th>
                  </tr>
                </thead>

                <tbody>
                  <ProcessorRow
                    confirmUpdate={this.confirmUpdate}
                    notifyChanges={this.notifyChanges}
                    dirty={dirtyRows.includes(false)}
                  />
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );

    return <div>
      {!this.state.reloading ? page : null}
    </div>;
  }
}

const mapStateToProps = (state) => {
  return {
    paymentProcessors: state.processor.paymentProcessors,
    timeZone: state.misc.timeZone
  };
};

Processors.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(Processors);
