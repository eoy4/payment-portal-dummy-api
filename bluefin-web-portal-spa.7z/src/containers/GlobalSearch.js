import React from 'react';
import { connect } from 'react-redux';
import GlobalSearchForm from '../forms/GlobalSearchForm';
import MultipleTransactions from '../components/MultipleTransactions/MultipleTransactions';
import Pagination from '../components/Pagination/Pagination';
import {
  getTransactions,
  downloadReport,
  cleanReport,
  cleanFilter,
  storeFilter,
  voidTransaction,
  refundTransaction,
  cleanTransaction,
  cacheTransactionConfirmation,
  cleanFilteredTransactions } from '../redux/modules/Transaction';
import {
  getEntities,
  blockUI,
  unblockUI,
  getApplications,
  getPaymentFrequencies,
  getReconciliationStatus,
  getTimeZone } from '../redux/modules/Misc';
import { getTransactionTypes } from '../redux/modules/TransactionType';
import { getStatusCodes } from '../redux/modules/StatusCodes';
import { getProcessors } from '../redux/modules/Processor';
import {
  createFilter,
  filterUpdatePage,
  filterUpdateSize,
  pageSize,
  getDataFromFilter,
  handleErrorToastr,
  generateTransactionId,
  saveFile
} from '../utils/utils';
import { default as moment } from 'moment';
import 'toastr/build/toastr.min.css';

type Props = {
  location: Object,
  currentFilter: string,
  filteredTransactions: Array,
  currentPage: number,
  availableLegalEntities: Array,
  reconciliationStatus: Array,
  transactionTypes: Array,
  processorNames: Array,
  transactionStatusCodes: Array,
  applications: Array,
  paymentFrequencies: Array,
  isAuthenticated: string,
  username: string,
  report: string,
  currentTimeZone: string,
  timeZone: string
}
export class GlobalSearch extends React.Component {
  props: Props;
  context: Context;

  constructor () {
    super();

    this.handleNewPage = this.handleNewPage.bind(this);
    this.handlePageSizeChange = this.handlePageSizeChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.doRefund = this.doRefund.bind(this);
    this.voidTransaction = this.voidTransaction.bind(this);
    this.selectTransaction = this.selectTransaction.bind(this);
    this.selectAll = this.selectAll.bind(this);
    this.downloadReport = this.downloadReport.bind(this);
    this.getSpecificStatusCodes = this.getSpecificStatusCodes.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;

    store.dispatch(blockUI());
    Promise.all([
      store.dispatch(getTransactionTypes()),
      store.dispatch(getEntities()),
      store.dispatch(getProcessors()),
      store.dispatch(getStatusCodes('ALL')),
      store.dispatch(getApplications()),
      store.dispatch(getPaymentFrequencies()),
      store.dispatch(getReconciliationStatus()),
      store.dispatch(getTimeZone())
    ])
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
      }
      this.searchTransactions(this.props.location.query);
      store.dispatch(unblockUI());
    });
  }

  searchTransactions (query) {
    const { store } = this.context;
    let filterObject = {};

    this.setState({selectedTransactions: {}, allSelected: false});
    store.dispatch(cleanFilter());
    store.dispatch(cleanTransaction());
    store.dispatch(cleanFilteredTransactions());

    if (query.filter) {
      const filter = decodeURIComponent(query.filter);
      let match = filter.match(/page=[\d]+/g);
      const page = parseInt(match[0].split('=')[1]);
      match = filter.match(/size=[\d]+/g);
      const size = parseInt(match[0].split('=')[1]);

      pageSize('transactions', size);

      filterObject = getDataFromFilter(filter);
      if (filterObject.transactionId) {
        filterObject.applicationTransactionId = filterObject.transactionId;
      }
      filterObject.mintransactionDateTime = moment.utc(filterObject.mintransactionDateTime)
        .local().format('YYYY-MM-DD HH:mm:ss');
      filterObject.maxtransactionDateTime = moment.utc(filterObject.maxtransactionDateTime)
        .local().format('YYYY-MM-DD HH:mm:ss');
      this.dispatchSearchAction(filter, page, filterObject.timeZone);
    } else {
      let min = moment().startOf('day').format('YYYY-MM-DD HH:mm:ss');
      let max = moment().endOf('day').format('YYYY-MM-DD HH:mm:ss');

      filterObject.mintransactionDateTime = min;
      filterObject.maxtransactionDateTime = max;
      filterObject.timeZone = this.props.timeZone;
    }

    this.setState({filterObject});
  }

  componentWillUpdate (nextProps) {
    if (this.props.location.search !== nextProps.location.search) {
      this.searchTransactions(nextProps.location.query);
    }
  }

  getSpecificStatusCodes (transactionType) {
    const { store } = this.context;
    store.dispatch(getStatusCodes(transactionType))
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
        this.setState({loading: false});
      }
    });
  }

  handleSubmit (data, report) {
    const { router } = this.context;
    let { internalStatusCode } = data;
    const codeIdArr = internalStatusCode && internalStatusCode.split('$$');
    if (codeIdArr && codeIdArr.length > 1) {
      data.internalStatusCode = codeIdArr[1];
    }
    const filter = createFilter(data, 0, pageSize('transactions'));

    router.push({
      pathname: '/search/transactions',
      query: { filter }
    });

    if (report) {
      this.setState({processingReport: true});
      this.downloadReport(filter);
    }
  }

  handleNewPage (i) {
    const newFilter = filterUpdatePage(this.props.currentFilter, i);

    this.handleNewFilter(newFilter, i);
  }

  handlePageSizeChange (newSize) {
    let newFilter = filterUpdateSize(this.props.currentFilter, newSize, 'transactions');
    newFilter = filterUpdatePage(newFilter, 0);

    this.handleNewFilter(newFilter, 0);
  }

  handleNewFilter (newFilter, page = this.props.currentPage) {
    const { router } = this.context;

    router.replace({
      pathname: '/search/transactions',
      query: { filter: newFilter }
    });

    const filterObject = getDataFromFilter(newFilter);
    this.dispatchSearchAction(newFilter, page, filterObject.timeZone);
  }

  dispatchSearchAction (filter, page, timeZone) {
    const { store } = this.context;
    this.setState({
      loading: true,
      selectedTransactions: {},
      allSelected: false
    }, () => {
      store.dispatch(storeFilter({filter, page, timeZone}));
      store.dispatch(getTransactions({filter, page}))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
        this.setState({loading: false});
      });
    });
  }

  downloadReport (filter) {
    const { store } = this.context;
    store.dispatch(downloadReport(filter))
    .then(() => {
      saveFile('reports.csv', this.props.report);

      this.setState({processingReport: false});

      store.dispatch(cleanReport());
    })
    .catch((e) => {
      this.setState({processingReport: false});
      handleErrorToastr(e);
    });
  }

  doRefund () {
    const { store, router } = this.context;
    store.dispatch(blockUI(false, 'Are you sure you want to refund the selected transaction(s)?',
      () => {
        store.dispatch(blockUI());
        let transactions = this.state.selectedTransactions;
        let promises = [];
        let pendingTransactions = [];

        for (let key in transactions) {
          const transaction = transactions[key].item;
          const { amount, applicationTransactionId } = transaction;
          promises.push(
            store.dispatch(
              refundTransaction(applicationTransactionId, amount, this.props.username, generateTransactionId()))
          );
          pendingTransactions.push(transaction);
        }

        Promise.all(promises)
        .then((payload) => {
          store.dispatch(unblockUI());
          store.dispatch(cacheTransactionConfirmation({pendingTransactions, responses: payload}));
          router.push('/summary/refund');
        })
        .catch((err) => {
          handleErrorToastr(err);
          store.dispatch(unblockUI());
        });
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  voidTransaction () {
    const { store, router } = this.context;
    store.dispatch(blockUI(false, 'Are you sure you want to void the selected transaction(s)?',
      () => {
        store.dispatch(blockUI());
        let transactions = this.state.selectedTransactions;
        let promises = [];
        let pendingTransactions = [];

        for (let key in transactions) {
          const transaction = transactions[key].item;
          const { applicationTransactionId } = transaction;
          promises.push(
            store.dispatch(
              voidTransaction(applicationTransactionId, this.props.username, generateTransactionId()))
          );
          pendingTransactions.push(transaction);
        }

        Promise.all(promises)
        .then((payload) => {
          store.dispatch(unblockUI());
          store.dispatch(cacheTransactionConfirmation({pendingTransactions, responses: payload}));
          router.push('/summary/void');
        })
        .catch((err) => {
          handleErrorToastr(err);
          store.dispatch(unblockUI());
        });
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  selectTransaction (item) {
    let currentSelection = this.state.selectedTransactions || {};
    if (item.checked) {
      currentSelection[item.id] = item;
    } else {
      delete currentSelection[item.id];
    }
    this.setState({allSelected: false, selectedTransactions: currentSelection});
  }

  selectAll (checked, transactions) {
    this.setState({allSelected: checked, selectedTransactions: transactions});
  }

  render () {
    const transactions = (this.state) ? this.state.selectedTransactions : {};
    const showButtons = !!Object.keys(transactions).length;
    const enableReports = !!Object.keys(this.props.filteredTransactions).length;
    const reportsTooLarge = this.props.filteredTransactions.totalElements > 30000;
    const processingReport = (this.state && this.state.processingReport);

    return (
      <div className='global-search other'>
        <GlobalSearchForm type={'advanced'}
          initialValues={(this.state && this.state.filterObject) ? this.state.filterObject : {}}
          availableLegalEntities={this.props.availableLegalEntities}
          reconciliationStatus={this.props.reconciliationStatus}
          processorNames={this.props.processorNames}
          transactionTypes={this.props.transactionTypes}
          internalStatusCodes={this.props.transactionStatusCodes}
          applications={this.props.applications}
          paymentFrequencies={this.props.paymentFrequencies}
          downloadReport={this.downloadReport}
          reportsEnabled={enableReports}
          reportsTooLarge={reportsTooLarge}
          processing={processingReport}
          getSpecificStatusCodes={this.getSpecificStatusCodes}
          customSubmitHandler={this.handleSubmit}
          timeZone={this.props.timeZone} />
        {
            this.props.filteredTransactions.content &&
              <div>
                <hr />
                <div style={{'marginTop': '20px'}}>
                  <button style={{'marginRight': '15px'}}
                    disabled={!showButtons}
                    className='btn btn-warning'
                    onClick={this.doRefund}
                    id='refund-button'>Refund</button>
                  <button className='btn btn-warning'
                    disabled={!showButtons}
                    onClick={this.voidTransaction}
                    id='void-button'>Void</button>
                </div>
                {
                  this.props.filteredTransactions.content &&
                    <Pagination elements={this.props.filteredTransactions}
                      onPagination={this.handleNewPage}
                      onPageSizeChange={this.handlePageSizeChange}
                      currentPage={this.props.currentPage}
                      numbersOnly
                      maxPagesLinks={10}
                      elementName={'transactions'}
                      blocked={this.state && this.state.loading} />
                }
                {
                  this.state &&
                  !this.state.loading
                  ? <MultipleTransactions transactions={this.props.filteredTransactions}
                    selectedTransactions={transactions}
                    currentFilter={this.props.currentFilter}
                    type='check'
                    onSelectItem={this.selectTransaction}
                    onSelectAll={this.selectAll}
                    allSelected={this.state.allSelected}
                    timeZone={this.props.currentTimeZone}
                    userTimeZone={this.props.timeZone}
                    />
                  : <img src='/img/loader.gif' className='loader' alt='Loader' />
                }

              </div>
        }
        {
          !this.props.filteredTransactions.content && this.state && this.state.loading &&
            <img src='/img/loader.gif' className='loader' alt='Loader' />
        }
        {
          this.props.filteredTransactions.content &&
          this.state &&
          !this.state.loading
            ? <Pagination elements={this.props.filteredTransactions}
              onPagination={this.handleNewPage}
              onPageSizeChange={this.handlePageSizeChange}
              currentPage={this.props.currentPage}
              maxPagesLinks={10}
              elementName={'transactions'}
              blocked={this.state && this.state.loading} />
            : null
        }
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    filteredTransactions: state.transaction.filteredTransactions,
    report: state.transaction.report,
    currentFilter: state.transaction.currentFilter,
    currentPage: state.transaction.currentPage,
    availableLegalEntities: state.misc.legalEntities,
    reconciliationStatus: state.misc.reconciliationStatus,
    applications: state.misc.applications,
    paymentFrequencies: state.misc.paymentFrequencies,
    transactionTypes: state.transactionType.transactionTypes,
    transactionStatusCodes: state.statusCodes.statusCodes,
    processorNames: state.processor.paymentProcessors,
    username: state.auth.profile.username,
    currentTimeZone: state.transaction.currentTimeZone,
    timeZone: state.misc.timeZone
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

GlobalSearch.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(GlobalSearch);
