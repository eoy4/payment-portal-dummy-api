import React from 'react';
import { connect } from 'react-redux';
import ProcessorForm from '../forms/ProcessorForm';
import { getProcessor, createProcessor, updateProcessor, cleanProcessor } from '../redux/modules/Processor';
import { handleErrorToastr, handleSuccessToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  params: Object,
  mode: string,
  title: string,
  currentProcessor: Object
}
export class ProcessorUpdate extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);

    this.confirmSubmit = this.confirmSubmit.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    store.dispatch(blockUI());

    if (this.props.mode === 'edit') {
      const processorId = this.props.params.paymentProcessorId || this.props.currentProcessor.paymentProcessorId;

      store.dispatch(getProcessor(processorId))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        };
        store.dispatch(unblockUI());
      });
    } else {
      store.dispatch(cleanProcessor());
      store.dispatch(unblockUI());
    }
  }

  confirmSubmit (data) {
    const { store } = this.context;
    store.dispatch(blockUI(false, 'Are you sure you want to save your changes to the Payment Processor?',
      () => {
        this.handleSubmit(data);
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  handleSubmit (data) {
    const { store, router } = this.context;
    store.dispatch(blockUI());

    const { paymentProcessorId } = this.props.currentProcessor;
    const processorObj = {
      processorName: data.processorName,
      isActive: data.isActive ? 1 : 0
    };

    if (this.props.mode === 'edit') {
      store.dispatch(updateProcessor(paymentProcessorId, processorObj))
      .then((payload) => {
        store.dispatch(unblockUI());
        router.replace({
          pathname: '/processors'
        });
        if (payload.error) {
          handleErrorToastr(payload.error);
        } else {
          handleSuccessToastr(`Payment Processor ${data.processorName} successfuly updated.`);
        }
      });
    } else {
      store.dispatch(createProcessor(processorObj))
      .then((payload) => {
        store.dispatch(unblockUI());
        router.replace({
          pathname: '/processors'
        });
        if (payload.error) {
          handleErrorToastr(payload.error);
        } else {
          handleSuccessToastr(`Payment Processor ${data.processorName} successfuly created.`);
        }
      });
    }
  }

  render () {
    return (
      <div>
        <h2 className='sub-header'>{this.props.title}</h2>
        <ProcessorForm onSubmit={this.confirmSubmit}
          initialValues={this.props.currentProcessor}
          mode={this.props.mode}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    currentProcessor: state.processor.currentProcessor
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

ProcessorUpdate.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProcessorUpdate);
