import React from 'react';
import { connect } from 'react-redux';
import {
  getLegalEntities,
  createLegalEntity,
  updateLegalEntity,
  deleteLegalEntity
} from '../redux/modules/LegalEntity';
import MultipleLegalEntities from '../components/MultipleLegalEntities/MultipleLegalEntities';
import { handleErrorToastr, handleSuccessToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  location: Object,
  legalEntities: Array,
}

export class LegalEntities extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);

    this.state = {
      reloading: false
    };

    this.confirmInputChange = this.confirmInputChange.bind(this);
    this.confirmSave = this.confirmSave.bind(this);
    this.confirmDelete = this.confirmDelete.bind(this);
  }

  componentDidMount () {
    this.reloadData();
  }

  reloadData (successMessage = false) {
    const { store } = this.context;
    store.dispatch(blockUI());

    store.dispatch(getLegalEntities())
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      };
      this.setState({reloading: true}, () => {
        store.dispatch(unblockUI());
        successMessage && handleSuccessToastr(successMessage);
        this.setState({reloading: false});
      });
    });
  }

  confirmInputChange (legalEntityAppId, legalEntity) {
    return this.confirmAction(
      legalEntityAppId,
      legalEntity,
      this.handleLegalEntityNameChange.bind(this),
      'Do you want to save your changes? ' +
      'Please keep in mind this may potentially harm the system.');
  }

  confirmSave (newLegalEntity) {
    // NOTE: This is different as this is not used in <MultipleLegalEntities /> as the click handler.
    // Instead this is called within the click handler in <MultipleLegalEntities />. Notice the () at
    // the end, immediately calling the function returned by confirmAction().
    return this.confirmAction(
      null,
      newLegalEntity,
      this.handleNewLegalEntitySave.bind(this),
      'Do you want to save the new Legal Entity?')();
  }

  confirmDelete (legalEntityAppId) {
    return this.confirmAction(
      legalEntityAppId,
      {},
      this.handleDelete.bind(this),
      'Are you sure you want to delete the Legal Entity? ' +
      'Please keep in mind this may potentially harm the system.');
  }

  confirmAction (legalEntityAppId, legalEntity, action, message) {
    return (event) => {
      event && (typeof event.persist === 'function') && event.persist();
      event && (typeof event.preventDefault === 'function') && event.preventDefault();

      const { store } = this.context;

      store.dispatch(blockUI(false, message,
        () => {
          action(event, legalEntityAppId, legalEntity);
        },
        () => {
          this.setState({reloading: true});
          setTimeout(() => {
            this.setState({reloading: false});
            store.dispatch(unblockUI());
          }, 0);
        }
      ));
    };
  }

  handleLegalEntityNameChange (value, legalEntityAppId, legalEntity) {
    const { store } = this.context;
    store.dispatch(blockUI());

    const newLegalEntity = {};
    newLegalEntity.legalEntityAppName = value;

    store.dispatch(updateLegalEntity(legalEntityAppId, newLegalEntity))
    .then((payload) => {
      if (payload.error) {
        store.dispatch(unblockUI());
        handleErrorToastr(payload.error);
      } else {
        this.reloadData('The Legal Entity was updated successfully');
      }
    });
  }

  handleNewLegalEntitySave (value, legalEntityAppId, legalEntity) {
    const { store } = this.context;
    store.dispatch(blockUI());

    store.dispatch(createLegalEntity(legalEntity))
    .then((payload) => {
      if (payload.error) {
        store.dispatch(unblockUI());
        handleErrorToastr(payload.error);
      } else {
        this.reloadData('The Legal Entity was created successfully');
      }
    });
  }

  handleDelete (value, legalEntityAppId, legalEntity) {
    const { store } = this.context;
    store.dispatch(blockUI());

    store.dispatch(deleteLegalEntity(legalEntityAppId))
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      } else {
        this.reloadData('The Legal Entity was deleted successfully');
      }
    });
  }

  render () {
    return this.state.reloading
    ? null
    : (
      <div className='global-search other tab-content'>
        <div className='tab-pane active'>
          <MultipleLegalEntities
            legalEntities={this.props.legalEntities}
            handleInputChange={this.confirmInputChange}
            handleCreate={this.confirmSave}
            handleDelete={this.confirmDelete}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    legalEntities: state.legalEntity.legalEntities
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

LegalEntities.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LegalEntities);
