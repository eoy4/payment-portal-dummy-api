import React from 'react';
import { connect } from 'react-redux';
import { ResponseCodeRow } from '../components/ResponseCodeRow/ResponseCodeRow';
import {
  getResponseCodes,
  insertResponseCode,
  updateResponseCode,
  deleteResponseCode,
  modifyResponseCode,
  clearResponseCodes
} from '../redux/modules/ResponseCodes';
import { CodesMapping } from './CodesMapping';

type Props = {
  params: Object,
  responseCodesRows: Object,
  paymentProcessors: Array,
  transactionTypes: Array,
  selectProcessorsForm: Object
}

export class ResponseCodes extends CodesMapping {
  props: Props;

  codeTitle = 'Response Code';
  baseURL = '/response-codes';

  getGetCodesAction () { return getResponseCodes; }
  getInsertCodeAction () { return insertResponseCode; }
  getUpdateCodeAction () { return updateResponseCode; }
  getDeleteCodeAction () { return deleteResponseCode; }
  getModifyCodeAction () { return modifyResponseCode; }
  getClearCodesAction () { return clearResponseCodes; }

  validateData (data) {
    // ToDo
    return true;
  }

  // Creates a new function that retrieves a specific code's data, to be used at save time.
  getDataRetriever (codeId) {
    return () => {
      const { responseCodesRows } = this.props;
      const row = responseCodesRows && responseCodesRows[codeId];
      if (!row) {
        return {};
      }

      let responseCode = {};
      responseCode.code = row.internalResponseCode;
      responseCode.description = row.internalResponseCodeDescription;
      responseCode.internalCodeId = codeId;
      responseCode.transactionTypeName = row.transactionTypeName;
      responseCode.paymentProcessorCodes = [];

      row.processorResponseCodes &&
      Object.keys(row.processorResponseCodes).forEach((key) => {
        const processorCodes = row.processorResponseCodes[key];
        processorCodes && Object.keys(processorCodes).forEach((key) => {
          const processorCode = processorCodes[key];
          let newProcessorCode = {};
          newProcessorCode.code =
            processorCode.paymentProcessorResponseCode.paymentProcessorResponseCode;
          newProcessorCode.description =
            processorCode.paymentProcessorResponseCode.paymentProcessorResponseCodeDescription;
          newProcessorCode.paymentProcessorCodeId =
            processorCode.paymentProcessorResponseCode.paymentProcessorResponseCodeId;
          newProcessorCode.paymentProcessorId =
            processorCode.paymentProcessorResponseCode.processorId;
          responseCode.paymentProcessorCodes.push(newProcessorCode);
        });
      });
      return responseCode;
    };
  }

  renderRows (empty = false) {
    const {
      props: {
        responseCodesRows
      },
      state: { dirtyRows }
    } = this;

    const processorIds = this.getProcessorIds();

    if (!responseCodesRows) {
      return null;
    }

    if (empty) {
      return (
        <ResponseCodeRow
          codeId={false}
          codes={responseCodesRows[false]}
          paymentProcessorIds={processorIds}
          getInputHandler={this.getInputHandler}
          getSaveHandler={this.getSaveHandler}
          notifyChanges={this.notifyChanges}
          dirty={dirtyRows.includes(false)}
        />
      );
    } else {
      var rowsArray = [];
      Object.keys(responseCodesRows).forEach((key) => {
        key && (key !== 'false') && rowsArray.push(
          <ResponseCodeRow key={'row-' + key}
            codeId={key}
            codes={responseCodesRows[key]}
            paymentProcessorIds={processorIds}
            getInputHandler={this.getInputHandler}
            getSaveHandler={this.getSaveHandler}
            getDeleteHandler={this.getDeleteHandler}
            notifyChanges={this.notifyChanges}
            dirty={dirtyRows.includes(key)}
          />
        );
      });

      return rowsArray;
    }
  }

  renderRowEmpty () {
    return this.renderRows(true);
  }
}

const mapStateToProps = (state) => {
  return {
    paymentProcessors: state.processor.paymentProcessors,
    transactionTypes: state.transactionType.transactionTypes,
    selectProcessorsForm: state.form.SelectProcessorsForm,
    responseCodesRows: state.responseCodes.responseCodesRows
  };
};

ResponseCodes.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(ResponseCodes);
