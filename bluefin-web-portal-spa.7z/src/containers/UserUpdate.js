import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router';
import UserInformationForm from '../forms/UserInformationForm';
import { getUser, createUser, updateUser, cleanUser, updateUserEntities, updateUserRoles } from '../redux/modules/User';
import { getRoles, getEntities, getTimeZone, setAndSaveTimeZone } from '../redux/modules/Misc';
import { handleErrorToastr, handleSuccessToastr, stringArrayToInt } from '../utils/utils';
import 'toastr/build/toastr.min.css';
import TimeZoneSelect from 'components/TimeZoneSelect/TimeZoneSelect';

type Props = {
  params: Object,
  mode: string,
  availableRoles: [],
  availableLegalEntities: [],
  currentUser: {
    legalEntityApps: [],
    roles: []
  },
  title: string,
  user: Object,
  timeZone: string
}
export class UserUpdate extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
    this.onTzChange = this.onTzChange.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    this.setState({loading: true, tzSaved: false});

    if (this.props.mode === 'edit' || this.props.mode === 'self') {
      const username = this.props.params.username || this.props.user.username;

      Promise.all([
        store.dispatch(getEntities()),
        store.dispatch(getRoles()),
        store.dispatch(getUser(username)),
        store.dispatch(getTimeZone())
      ])
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
      });
    } else {
      Promise.all([
        store.dispatch(getEntities()),
        store.dispatch(getRoles())
      ])
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
        store.dispatch(cleanUser());
      });
    }
  }

  transformData (data) {
    let { username, firstName, lastName, email, legalEntityApps, roles } = data;
    for (let index in roles) {
      const id = roles[index];
      if (id === '6') {
        const elements = this.props.availableLegalEntities.map((le) => {
          return le.legalEntityAppId.toString();
        });
        legalEntityApps = elements;
      }
    }
    legalEntityApps = stringArrayToInt(legalEntityApps);
    roles = stringArrayToInt(roles);

    return {
      username,
      firstName,
      lastName,
      email,
      legalEntityApps,
      roles
    };
  }

  handleSubmit (data) {
    const { store } = this.context;
    let processedData = this.transformData(data);
    let { username, firstName, lastName, email, legalEntityApps, roles } = processedData;

    if (this.props.mode === 'self') {
      store.dispatch(updateUser(username, {firstName, lastName, email}))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        } else {
          handleSuccessToastr('User information successfuly updated.');
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
      });
    } else if (this.props.mode === 'edit') {
      Promise.all([
        store.dispatch(updateUser(username, {firstName, lastName, email})),
        store.dispatch(updateUserRoles(username, roles)),
        store.dispatch(updateUserEntities(username, legalEntityApps))
      ])
      .then((payload) => {
        let error = payload[0].error || payload[1].error || payload[2].error;
        if (error) {
          handleErrorToastr(error);
        } else {
          handleSuccessToastr('User information successfuly updated.');
        }
        if (!error || (error && error.details && error.details.status !== 401)) {
          this.setState({loading: false});
        }
      });
    } else {
      store.dispatch(createUser(processedData)).then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        } else {
          handleSuccessToastr('User successfuly created.');
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
      });
    }
  }

  onTzChange (e) {
    // this.setState({tz: e.value});
    const { store } = this.context;
    if (e !== null) {
      store.dispatch(setAndSaveTimeZone(e.value));
      this.setState({tzSaved: true});
    }
  }

  render () {
    return (
      <div className='tab-content'>
        <div className='tab-pane active'>
          <h2 className='sub-header'>
            <i className={(this.props.mode === 'self') ? 'glyphicon glyphicon-user' : 'glyphicon glyphicon-edit'}></i>
            &nbsp;
            {this.props.title}
          </h2>
          {
            (this.props.mode !== 'self')
            ? <div className='form-group'>
              <Link to={'/users'}><button className='btn btn-default'
                id='all-users-button'>&larr; All Users</button></Link>
            </div>
            : null
          }
          {
            (this.props.mode === 'self')
            ? <div>
              <h3><i className='glyphicon glyphicon-cog'></i> Settings</h3>
              <div className='form-group'>
                <div className='row'>
                  <div className='col-md-3'>
                    <label className='control-label'>Time Zone</label>
                    <TimeZoneSelect onChange={this.onTzChange} value={this.props.timeZone} />
                  </div>
                  <div className='col-md-3'>
                    {
                      (this.state && this.state.tzSaved && this.state.tzSaved === true)
                      ? <div className='saved-success'>
                        <i className='glyphicon glyphicon-ok' aria-hidden='true'></i>  Saved.
                      </div>
                      : null
                    }
                  </div>
                </div>
              </div>
              <hr />
            </div>
            : null
          }
          {
            this.state && !this.state.loading &&
              <UserInformationForm onSubmit={this.handleSubmit}
                initialValues={this.props.currentUser}
                availableRoles={this.props.availableRoles}
                availableLegalEntities={this.props.availableLegalEntities}
                mode={this.props.mode}
              />
          }
          {
            this.state && this.state.loading &&
              <img src='/img/loader.gif' className='loader' alt='Loader' />
          }
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    availableRoles: state.misc.roles,
    availableLegalEntities: state.misc.legalEntities,
    currentUser: state.user.currentUser,
    user: state.auth.profile,
    timeZone: state.misc.timeZone
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

UserUpdate.contextTypes = {
  store: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserUpdate);
