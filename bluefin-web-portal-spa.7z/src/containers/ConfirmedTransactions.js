import React from 'react';
import { connect } from 'react-redux';
import MultipleTransactionConfirmationList from
'../components/MultipleTransactionConfirmationList/MultipleTransactionConfirmationList';
import { cleanFilteredTransactions } from '../redux/modules/Transaction';

type Props = {
  params: Object,
  transactions: Object,
  message: string
}
export class ConfirmedTransactions extends React.Component {
  props: Props;

  componentDidMount () {
    const { router } = this.context;
    if (!this.props.transactions.size) {
      router.push('/');
    }
  }

  componentWillUnmount () {
    const { store } = this.context;
    store.dispatch(cleanFilteredTransactions());
  }

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles}>
        <h1 className='page-header'>{this.props.message}</h1>
        <MultipleTransactionConfirmationList transactions={this.props.transactions} />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    transactions: state.transaction.currentTransactions
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

ConfirmedTransactions.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConfirmedTransactions);
