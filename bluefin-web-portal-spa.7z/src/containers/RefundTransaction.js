import React from 'react';
import { connect } from 'react-redux';
import GlobalSearchForm from '../forms/GlobalSearchForm';
import { getTransactions,
  refundTransaction,
  cleanTransaction,
  cleanFilteredTransactions,
  cacheTransactionConfirmation } from '../redux/modules/Transaction';
import { blockUI, unblockUI, getTimeZone } from '../redux/modules/Misc';
import MultipleTransactions from '../components/MultipleTransactions/MultipleTransactions';
import Pagination from '../components/Pagination/Pagination';
import { handleErrorToastr, generateTransactionId } from '../utils/utils';
import 'toastr/build/toastr.min.css';

type Props = {
  params: Object,
  filteredTransactions: Object,
  currentPage: number,
  username: string,
  timeZone: string
}
export class RefundTransaction extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
    this.doRefund = this.doRefund.bind(this);
    this.selectTransaction = this.selectTransaction.bind(this);
    this.selectAll = this.selectAll.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    this.setState({selectedTransactions: {}, allSelected: false});
    store.dispatch(cleanTransaction());
    store.dispatch(cleanFilteredTransactions());
    store.dispatch(getTimeZone());
    if (this.props.params.id) {
      this.setState({loading: true});
      this.dispatchAction(this.props.params.id);
    }
  }

  handleSubmit (data) {
    const { router } = this.context;
    const tid = data.applicationTransactionId;

    router.replace({
      pathname: `/refund/${tid}`
    });

    if (tid) {
      this.dispatchAction(tid);
    }
  }

  dispatchAction (id) {
    const { store } = this.context;
    this.setState({
      loading: true,
      selectedTransactions: {},
      allSelected: false
    }, () => {
      const filter =
        `transactionId:${id}$$transactionType:SALE&page=0&size=20&sort=transactionDateTime:desc,amount:asc`;

      store.dispatch(getTransactions({ filter, page: 0 }))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
      });
    });
  }

  selectTransaction (item) {
    let currentSelection = this.state.selectedTransactions;
    if (item.checked) {
      currentSelection[item.id] = item;
    } else {
      delete currentSelection[item.id];
    }
    this.setState({allSelected: false, selectedTransactions: currentSelection});
  }

  selectAll (checked, transactions) {
    this.setState({allSelected: checked, selectedTransactions: transactions});
  }

  doRefund () {
    const { store, router } = this.context;
    store.dispatch(blockUI(false, 'Are you sure you want to refund the selected transaction(s)?',
      () => {
        store.dispatch(blockUI());
        let transactions = this.state.selectedTransactions;
        let promises = [];
        let pendingTransactions = [];

        for (let key in transactions) {
          const transaction = transactions[key].item;
          const { amount, applicationTransactionId } = transaction;
          promises.push(
            store.dispatch(
              refundTransaction(applicationTransactionId, amount, this.props.username, generateTransactionId()))
          );
          pendingTransactions.push(transaction);
        }

        Promise.all(promises)
        .then((payload) => {
          store.dispatch(unblockUI());
          store.dispatch(cacheTransactionConfirmation({pendingTransactions, responses: payload}));
          router.push('/summary/refund');
        })
        .catch((err) => {
          handleErrorToastr(err);
          store.dispatch(unblockUI());
        });
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    const ready = this.props.filteredTransactions.content && this.state && !this.state.loading;
    const transactions = (this.state) ? this.state.selectedTransactions : {};
    const disableButton = !this.props.params.id || !Object.keys(transactions).length;

    return (
      <section style={styles}>
        <h1 className='page-header' id='refund-transaction-h1'>Refund</h1>
        <div className='tab-content'>
          <div className='tab-pane active'>
            <h2 className='sub-header'>
              <i className='glyphicon glyphicon-search'></i> Search for a Transaction to Refund
            </h2>
            <GlobalSearchForm type={'simple'}
              initialValues={{applicationTransactionId: this.props.params.id}}
              customSubmitHandler={this.handleSubmit} />
          </div>
        </div>
        {
          ready && <Pagination elements={this.props.filteredTransactions}
            onPagination={this.handleNewPage}
            currentPage={this.props.currentPage}
            numbersOnly
            maxPagesLinks={10}
            elementName={'transactions'} />
        }
        {
          ready &&
            <MultipleTransactions
              transactions={this.props.filteredTransactions}
              selectedTransactions={transactions}
              currentId={this.props.params.id}
              type='check'
              onSelectItem={this.selectTransaction}
              onSelectAll={this.selectAll}
              allSelected={this.state.allSelected}
              userTimeZone={this.props.timeZone}
            />
        }
        {
          !ready && this.props.params.id &&
            <img src='/img/loader.gif' className='loader' alt='Loader' />
        }
        {
          ready &&
            <div>
              <Pagination elements={this.props.filteredTransactions}
                onPagination={this.handleNewPage}
                currentPage={this.props.currentPage}
                maxPagesLinks={10}
                elementName={'transactions'} />
              <button className='btn btn-warning'
                disabled={disableButton} onClick={this.doRefund} id='refund-transaction-button'>Refund</button>
            </div>
        }
      </section>
  );
  }
}

const mapStateToProps = (state) => {
  return {
    filteredTransactions: state.transaction.filteredTransactions,
    currentPage: state.transaction.currentPage,
    username: state.auth.profile.username,
    timeZone: state.misc.timeZone
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

RefundTransaction.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RefundTransaction);
