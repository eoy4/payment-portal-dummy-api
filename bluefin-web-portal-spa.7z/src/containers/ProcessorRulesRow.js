import React from 'react';
import { Checkbox } from '../components/Checkbox/Checkbox';
import { ConvertibleInput } from '../components/ConvertibleInput/ConvertibleInput';
import { ConvertibleInputUSDollar } from '../components/ConvertibleInputUSDollar/ConvertibleInputUSDollar';
import { ConvertibleSelect } from '../components/ConvertibleSelect/ConvertibleSelect';
import numeral from 'numeral';

type Props = {
  paymentProcessorId: String,
  paymentProcessors: Object,
  processorRule: Object,
  processorName: string,
  confirmUpdate: Function,
  notifyChanges: Function,
  dirty: boolean
}

export class ProcessorRulesRow extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = this.getDefaultState();

    this.handleProcessorChange = this.handleProcessorChange.bind(this);
    this.handleCardTypeChange = this.handleCardTypeChange.bind(this);
    this.handlePriorityChange = this.handlePriorityChange.bind(this);
    this.handleAmountChange = this.handleAmountChange.bind(this);
    this.handleLimitToggle = this.handleLimitToggle.bind(this);
    this.unsavedChanges = this.unsavedChanges.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
  }

  clearState () {
    this.setState({
      paymentProcessorId: '',
      cardType: 'CREDIT',
      maximumMonthlyAmount: 0,
      noMaximumMonthlyAmountFlag: 0,
      priority: 1
    });
  }

  getDefaultState () {
    const {
      paymentProcessorId,
      processorRule: {
        cardType,
        maximumMonthlyAmount,
        noMaximumMonthlyAmountFlag,
        priority
      }
    } = this.props;

    return {
      paymentProcessorId,
      cardType,
      maximumMonthlyAmount,
      noMaximumMonthlyAmountFlag,
      priority
    };
  }

  setDefaultState () {
    this.setState(this.getDefaultState());
  }

  /**
  * Determines if we are editing an existing rule, or creating a new one. Then formats the data from
  * Props and State and passes it on to the confirmUpdate callback that was provided via Props.
  */
  handleUpdate () {
    const { paymentProcessorId, processorRule } = this.props;

    if (processorRule.paymentProcessorRuleId) {
      // We are editing an existing rule
      const { cardType, maximumMonthlyAmount, noMaximumMonthlyAmountFlag, priority } = this.state;
      if (processorRule.cardType !== cardType ||
        processorRule.maximumMonthlyAmount !== maximumMonthlyAmount ||
        processorRule.noMaximumMonthlyAmountFlag !== noMaximumMonthlyAmountFlag ||
        processorRule.priority !== priority
      ) {
        const { confirmUpdate } = this.props;
        const { paymentProcessorRuleId } = processorRule;
        const data = Object.assign({ paymentProcessorId, paymentProcessorRuleId },
          { cardType, maximumMonthlyAmount, noMaximumMonthlyAmountFlag, priority }
        );
        confirmUpdate(data, 'update');
      } else {
        this.props.notifyChanges(false);
      }
    } else {
      // We are creating a new rule
      const { confirmUpdate } = this.props;
      const {
        paymentProcessorId,
        cardType,
        maximumMonthlyAmount,
        noMaximumMonthlyAmountFlag,
        priority
      } = this.state;

      confirmUpdate({
        paymentProcessorId,
        cardType,
        maximumMonthlyAmount,
        noMaximumMonthlyAmountFlag,
        priority
      }, 'create');
    }
  }

  handleProcessorChange (event) {
    this.setState({paymentProcessorId: event.target.value});
  }

  handleCardTypeChange (event) {
    const callbackFunc = this.props.paymentProcessorId ? this.handleUpdate.bind(this) : null;
    this.setState({cardType: event.target.value}, () => {
      /* if (this.state.cardType === 'UNKNOWN') {
        this.setState({noMaximumMonthlyAmountFlag: 1}, callbackFunc);
      } else {
        callbackFunc && callbackFunc();
      }*/
      callbackFunc && callbackFunc();
    });
  }

  handleAmountChange (event) {
    this.handleNumberInput('maximumMonthlyAmount', event);
  }

  handlePriorityChange (event) {
    this.handleNumberInput('priority', event);
  }

  handleNumberInput (stateVar, event) {
    let value = parseFloat(event.target.value);
    value = isNaN(value) ? 0 : value;
    let newState = {};
    newState[stateVar] = value;
    this.setState(newState, this.props.paymentProcessorId ? this.handleUpdate : null);
  }

  handleLimitToggle (value) {
    this.setState({
      noMaximumMonthlyAmountFlag: value ? 1 : 0
    }, this.props.paymentProcessorId ? this.handleUpdate : null);
  }

  handleDelete (event) {
    event.preventDefault();
    const { confirmUpdate } = this.props;
    const { paymentProcessorRuleId } = this.props.processorRule;
    confirmUpdate({ paymentProcessorRuleId }, 'delete');
  }

  handleCreate (event) {
    event.preventDefault();
    this.handleUpdate();
  }

  unsavedChanges () {
    if (!this.props.dirty) {
      // Call the notifyChanges callback funciton (provided via Props)
      // to notify the parent that there are unsaved changes.
      this.props.notifyChanges && this.props.notifyChanges(this.props.processorRule.paymentProcessorRuleId);
    };
  }

  render () {
    const {
      processorRule: {
        paymentProcessorRuleId,
        monthToDateCumulativeAmount
      },
      paymentProcessors,
      processorName
    } = this.props;

    const {
      paymentProcessorId,
      cardType,
      maximumMonthlyAmount,
      noMaximumMonthlyAmountFlag,
      priority
    } = this.state;

    const formattedMonthToDateCumulativeAmount = numeral(monthToDateCumulativeAmount).format('$0,0,0.00');

    // Render the 'Payment Processor Name' React element: Either a <p> if we are
    // editing an existing rule, or a <select> if we are creating a new rule.

    let processorNameField = null;

    if (paymentProcessorRuleId) {
      processorNameField = <p>{processorName}</p>;
    } else {
      let processorOptions = new Map();
      processorOptions.set('', 'Choose one');

      paymentProcessors &&
      paymentProcessors.forEach((processor) => {
        processorOptions.set(processor.paymentProcessorId, processor.processorName);
      });

      processorNameField = (
        <ConvertibleSelect id='paymentProcessorId'
          onChange={this.handleProcessorChange}
          value={paymentProcessorId}
          options={processorOptions}
          style={{padding: '6px 1px'}}
        />
      );
    }

    // Removing UNKNOWN from options as per David's request
    // const transactionOptions = new Map([['CREDIT', 'CREDIT'], ['DEBIT', 'DEBIT'], ['UNKNOWN', 'UNKNOWN']]);
    const transactionOptions = new Map([['CREDIT', 'CREDIT'], ['DEBIT', 'DEBIT']]);
    const transactionTypeField = <ConvertibleSelect id='cardType'
      onChange={this.handleCardTypeChange}
      value={cardType}
      options={transactionOptions}
      style={{padding: '6px 1px'}}
    />;

    const maximumMonthlyAmountField = !noMaximumMonthlyAmountFlag
    ? <ConvertibleInputUSDollar id='maximumMonthlyAmount'
      notifyChanges={this.unsavedChanges}
      onChange={this.handleAmountChange}
      value={maximumMonthlyAmount}
    />
    : null;

    const priorityField = <ConvertibleInput id='priority'
      notifyChanges={this.unsavedChanges}
      onChange={this.handlePriorityChange}
      value={priority}
    />;

    // The column width
    const cols = paymentProcessorRuleId ? 7 : 6;
    const width = (100 + (100 / cols)) / (cols + 1);
    const styles = {width: width + '%'};

    return (
      <tr className={this.props.dirty ? 'unsaved-changes' : ''}>
        <td className='text-center' style={styles}>{processorNameField}</td>
        <td className='text-center' style={styles}>
          {transactionTypeField}
        </td>
        <td className='text-center' style={styles}>
          {priorityField}
        </td>
        <td className='text-right' style={styles}>
          {maximumMonthlyAmountField}
        </td>
        <td style={styles} className='text-center'>
          <Checkbox key={(noMaximumMonthlyAmountFlag/* || cardType === 'UNKNOWN'*/) ? 1 : 0}
            value={(noMaximumMonthlyAmountFlag/* || cardType === 'UNKNOWN'*/) ? 1 : 0}
            onChange={this.handleLimitToggle} />
        </td>
        {
          paymentProcessorRuleId
          ? (<td className='text-right' style={styles}>
            {formattedMonthToDateCumulativeAmount}
          </td>)
          : null
        }
        <td style={{width: width / 2 + '%'}} className='text-center'>
          {
            paymentProcessorRuleId
            ? <a href='#' onClick={this.handleDelete}>
              <i className='glyphicon glyphicon-remove' aria-hidden='true' title='Delete'></i>
            </a>
            : <a href='#' onClick={this.handleCreate}>
              <i className='glyphicon glyphicon-floppy-disk' aria-hidden='true' title='Save'></i>
            </a>
          }
        </td>
      </tr>
    );
  }
}

ProcessorRulesRow.defaultProps = {
  paymentProcessorId: '',
  processorRule: {
    cardType: 'CREDIT',
    maximumMonthlyAmount: 0,
    monthToDateCumulativeAmount: 0,
    noMaximumMonthlyAmountFlag: 0,
    paymentProcessorRuleId: '',
    priority: 1
  },
  processorName: ''
};
