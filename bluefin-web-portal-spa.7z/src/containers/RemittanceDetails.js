import React from 'react';
import { connect } from 'react-redux';
import { getPaymentProcessorRemittance, cleanCurrentRemittance } from '../redux/modules/Transaction';
import { blockUI, unblockUI, getReconciliationStatus } from '../redux/modules/Misc';
import { handleErrorToastr, getTransactionObject } from '../utils/utils';
import numeral from 'numeral';
import { default as moment } from 'moment';

type Props = {
  currentRemittance: Object,
  reconciliationStatusMap: Object,
  params: Object
}

class RemittanceDetails extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.goBack = this.goBack.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    const { remittanceId, transactionType, processorTransactionType } = this.props.params;

    store.dispatch(blockUI());
    store.dispatch(cleanCurrentRemittance());

    Promise.all([
      store.dispatch(getReconciliationStatus()),
      store.dispatch(getPaymentProcessorRemittance({ remittanceId, transactionType, processorTransactionType }))
    ])
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      store.dispatch(unblockUI());
    });
  }

  goBack () {
    const { router } = this.context;

    router.goBack();
  }

  getTransactionDetails () {
    const { currentRemittance } = this.props;

    const transactionDetails = getTransactionObject(currentRemittance);

    // Get the reconciliation status for each field
    if (transactionDetails) {
      transactionDetails.recon = {};

      transactionDetails.recon.accountId =
        (transactionDetails.paymentProcessorRemittance.accountId &&
          transactionDetails.saleTransaction.accountNumber &&
          (transactionDetails.paymentProcessorRemittance.accountId.toLowerCase() ===
            transactionDetails.saleTransaction.accountNumber.toLowerCase()));
      transactionDetails.recon.application =
        (transactionDetails.paymentProcessorRemittance.application &&
          transactionDetails.saleTransaction.application &&
          (transactionDetails.paymentProcessorRemittance.application.toLowerCase() ===
            transactionDetails.saleTransaction.application.toLowerCase()));
      transactionDetails.recon.firstName =
        (transactionDetails.paymentProcessorRemittance.firstName &&
          transactionDetails.saleTransaction.firstName &&
          (transactionDetails.paymentProcessorRemittance.firstName.toLowerCase() ===
            transactionDetails.saleTransaction.firstName.toLowerCase()));
      transactionDetails.recon.lastName =
        (transactionDetails.paymentProcessorRemittance.lastName &&
          transactionDetails.saleTransaction.lastName &&
          (transactionDetails.paymentProcessorRemittance.lastName.toLowerCase() ===
            transactionDetails.saleTransaction.lastName.toLowerCase()));
      transactionDetails.recon.merchantId =
        (transactionDetails.paymentProcessorRemittance.merchantId &&
          transactionDetails.saleTransaction.merchantId &&
          (transactionDetails.paymentProcessorRemittance.merchantId.toLowerCase() ===
            transactionDetails.saleTransaction.merchantId.toLowerCase()));
      transactionDetails.recon.transactionType =
        (transactionDetails.paymentProcessorRemittance.transactionType &&
          transactionDetails.saleTransaction.transactionType &&
          (transactionDetails.paymentProcessorRemittance.transactionType.toLowerCase() ===
            transactionDetails.saleTransaction.transactionType.toLowerCase()));
      transactionDetails.recon.processorName =
        (transactionDetails.paymentProcessorRemittance.processorName &&
          transactionDetails.saleTransaction.processorName &&
          (transactionDetails.paymentProcessorRemittance.processorName.toLowerCase() ===
            transactionDetails.saleTransaction.processorName.toLowerCase()));
      transactionDetails.recon.processorTransactionId =
        (transactionDetails.paymentProcessorRemittance.processorTransactionId ===
        transactionDetails.saleTransaction.processorTransactionId);
      transactionDetails.recon.transactionAmount =
        (Math.abs(transactionDetails.paymentProcessorRemittance.transactionAmount) ===
        Math.abs(transactionDetails.saleTransaction.amount));
      transactionDetails.recon.reconciliationStatusId =
        (transactionDetails.paymentProcessorRemittance.reconciliationStatusId ===
        transactionDetails.saleTransaction.reconciliationStatusId);
    }

    return transactionDetails;
  }

  render () {
    const td = this.getTransactionDetails();
    const diffStyles = {color: '#c02'};

    return td ? <div className='remittance-details transaction-details tab-content'>
      <div className='tab-pane active'>
        <div className='form-group'>
          <button className='btn btn-default' onClick={this.goBack} >&larr; Go Back</button>
        </div>
        <h2 className='sub-header'><i className='glyphicon glyphicon-list'></i> Transaction Details</h2>
        <div className='row'>
          <div className='col-xs-12'>
            <div>
              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th>Field</th>
                    <th>Bluefin</th>
                    <th>Remittance</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Bluefin Transaction ID</th>
                    <td>{td.saleTransaction.applicationTransactionId}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Transaction Date (Local Time)</th>
                    <td>
                      {
                        td.saleTransaction.transactionDateTime &&
                        moment.utc(td.saleTransaction.transactionDateTime)
                          .local()
                          .format('YYYY-MM-DD HH:mm:ss')
                      }
                    </td>
                    <td>
                      {
                        td.paymentProcessorRemittance.transactionDate &&
                        moment.utc(td.paymentProcessorRemittance.transactionDate)
                          .local()
                          .format('YYYY-MM-DD HH:mm:ss')
                      }
                    </td>
                  </tr>
                  <tr>
                    <th>Payment Frequency</th>
                    <td>{td.saleTransaction.paymentFrequency}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Merchant ID</th>
                    <td style={td.recon.merchantId ? {} : diffStyles}>
                      {td.saleTransaction.merchantId}
                    </td>
                    <td style={td.recon.merchantId ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.merchantId}
                    </td>
                  </tr>
                  <tr>
                    <th>Application</th>
                    <td style={td.recon.application ? {} : diffStyles}>
                      {td.saleTransaction.application}
                    </td>
                    <td style={td.recon.application ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.application}
                    </td>
                  </tr>
                  <tr>
                    <th>Account ID</th>
                    <td style={td.recon.accountId ? {} : diffStyles}>
                      {td.saleTransaction.accountNumber}
                    </td>
                    <td style={td.recon.accountId ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.accountId}
                    </td>
                  </tr>
                  <tr>
                    <th>Payment Processor</th>
                    <td style={td.recon.processorName ? {} : diffStyles}>
                      {td.saleTransaction.processorName}
                    </td>
                    <td style={td.recon.processorName ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.processorName}
                    </td>
                  </tr>
                  <tr>
                    <th>Processor Transaction ID</th>
                    <td style={td.recon.processorTransactionId ? {} : diffStyles}>
                      {td.saleTransaction.processorTransactionId}
                    </td>
                    <td style={td.recon.processorTransactionId ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.processorTransactionId}
                    </td>
                  </tr>
                  <tr>
                    <th>Transaction Type</th>
                    <td style={td.recon.transactionType ? {} : diffStyles}>
                      {td.saleTransaction.transactionType}
                    </td>
                    <td style={td.recon.transactionType ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.transactionType}
                    </td>
                  </tr>
                  <tr>
                    <th>Bluefin Status</th>
                    <td>{td.saleTransaction.internalStatusDescription}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Internal response</th>
                    <td>{td.saleTransaction.internalResponseDescription}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Account Period</th>
                    <td>{td.saleTransaction.accountPeriod}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>User</th>
                    <td>{td.saleTransaction.processUser}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Desk</th>
                    <td>{td.saleTransaction.desk}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Invoice Number</th>
                    <td>{td.saleTransaction.invoiceNumber}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>User Defined Field 1</th>
                    <td>{td.saleTransaction.userDefinedField1}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>User Defined Field 2</th>
                    <td>{td.saleTransaction.userDefinedField2}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>User Defined Field 3</th>
                    <td>{td.saleTransaction.userDefinedField3}</td>
                    <td></td>
                  </tr>
                </tbody>
              </table>

              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th colSpan='3'>Credit Card Information</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Card Number (last 4)</th>
                    <td>{td.saleTransaction.cardNumberLast4Char}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Expiration Date</th>
                    <td>{moment(td.saleTransaction.expiryDate).format('MM-YY')}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>CVV2</th>
                    <td>{td.saleTransaction.cvv2}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Amount</th>
                    <td style={td.recon.transactionAmount ? {} : diffStyles}>
                      {td.saleTransaction.amount &&
                        numeral(td.saleTransaction.amount).format('$0,0.00')}
                    </td>
                    <td style={td.recon.transactionAmount ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.transactionAmount &&
                        numeral(td.paymentProcessorRemittance.transactionAmount).format('$0,0.00')}
                    </td>
                  </tr>
                </tbody>
              </table>

              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th colSpan='3'>Billing Address</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>First Name</th>
                    <td style={td.recon.firstName ? {} : diffStyles}>
                      {td.saleTransaction.firstName}
                    </td>
                    <td style={td.recon.firstName ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.firstName}
                    </td>
                  </tr>
                  <tr>
                    <th>Last Name</th>
                    <td style={td.recon.lastName ? {} : diffStyles}>
                      {td.saleTransaction.lastName}
                    </td>
                    <td style={td.recon.lastName ? {} : diffStyles}>
                      {td.paymentProcessorRemittance.lastName}
                    </td>
                  </tr>
                  <tr>
                    <th>Email</th>
                    <td>{td.saleTransaction.email}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Street Address</th>
                    <td>{td.saleTransaction.address1} {td.saleTransaction.address2}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>City</th>
                    <td>{td.saleTransaction.city}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>State/Province</th>
                    <td>{td.saleTransaction.state}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Zip/Postal Code</th>
                    <td>{td.saleTransaction.postalCode}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Country</th>
                    <td>{td.saleTransaction.country}</td>
                    <td></td>
                  </tr>
                </tbody>
              </table>

              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th colSpan='3'>Other</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Transaction Source</th>
                    <td>
                      {td.saleTransaction.origin}
                    </td>
                    <td>
                      {td.paymentProcessorRemittance.transactionSource}
                    </td>
                  </tr>
                  <tr>
                    <th>Test Mode</th>
                    <td>{td.saleTransaction.testMode === 1 ? 'Yes' : 'No'}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Tokenized</th>
                    <td>{td.saleTransaction.tokenized === 1 ? 'Yes' : 'No'}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Approval Code</th>
                    <td>{td.saleTransaction.approvalCode}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Bluefin Status Code</th>
                    <td>{td.saleTransaction.internalStatusCode}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Bluefin Status Description</th>
                    <td>{td.saleTransaction.internalStatusDescription}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Processor Status Code</th>
                    <td>{td.saleTransaction.paymentProcessorStatusCode}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Processor Status Description</th>
                    <td>{td.saleTransaction.paymentProcessorStatusCodeDescription}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Bluefin Response Code</th>
                    <td>{td.saleTransaction.internalResponseCode}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Bluefin Response Description</th>
                    <td>{td.saleTransaction.internalResponseDescription}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Processor Response Code</th>
                    <td>{td.saleTransaction.paymentProcessorResponseCode}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Processor Response Description</th>
                    <td>{td.saleTransaction.paymentProcessorResponseCodeDescription}</td>
                    <td></td>
                  </tr>
                  <tr>
                    <th>Payment Method</th>
                    <td>
                      {td.saleTransaction.cardType}
                    </td>
                    <td>
                      {td.paymentProcessorRemittance.paymentMethod}
                    </td>
                  </tr>
                  <tr>
                    <th>Reconcilitaion Status</th>
                    <td style={td.recon.reconciliationStatusId ? {} : diffStyles}>
                      {
                        this.props.reconciliationStatusMap &&
                        this.props.reconciliationStatusMap
                          .get(td.saleTransaction.reconciliationStatusId) &&
                        this.props.reconciliationStatusMap
                          .get(td.saleTransaction.reconciliationStatusId)
                          .reconciliationStatus
                      }
                    </td>
                    <td style={td.recon.reconciliationStatusId ? {} : diffStyles}>
                      {
                        this.props.reconciliationStatusMap &&
                        this.props.reconciliationStatusMap
                          .get(td.paymentProcessorRemittance.reconciliationStatusId) &&
                        this.props.reconciliationStatusMap
                          .get(td.paymentProcessorRemittance.reconciliationStatusId)
                          .reconciliationStatus
                      }
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <br />
        <button className='btn btn-default' onClick={this.goBack} >&larr; Go Back</button>
      </div>
    </div>
    : null;
  }
}

const mapStateToProps = (state) => {
  return {
    currentRemittance: state.transaction.currentRemittance,
    reconciliationStatusMap: state.misc.reconciliationStatusMap
  };
};

RemittanceDetails.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
)(RemittanceDetails);
