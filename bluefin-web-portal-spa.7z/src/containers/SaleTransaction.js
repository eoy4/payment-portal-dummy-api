import React from 'react';
import { connect } from 'react-redux';
import SaleTransactionForm from '../forms/SaleTransactionForm';
import { cacheTransaction, createTransaction } from '../redux/modules/Transaction';
import { prepareSaleTransaction, mergeTransactionInformation, handleErrorToastr } from '../utils/utils';
import { getEntities, getLocation, cleanLocation, blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  availableLegalEntities: Array,
  locationInfo: Object,
  username: string
}
export class SaleTransaction extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
    this.getLocation = this.getLocation.bind(this);
    this.cleanLocation = this.cleanLocation.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    this.setState({loading: true});

    store.dispatch(getEntities())
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
        this.setState({loading: false});
      }
    });
  }

  handleSubmit (data) {
    const { store, router } = this.context;
    store.dispatch(blockUI());
    data.username = data.processUser || this.props.username;
    const transaction = prepareSaleTransaction(data);

    store.dispatch(createTransaction(transaction.transaction))
    .then((payload) => {
      let tran = null;
      if (payload.error && payload.error.details) {
        tran = mergeTransactionInformation(transaction.cachedTransaction,
          payload.error.details);
      } else if (payload.error && payload.error.message) {
        tran = mergeTransactionInformation(transaction.cachedTransaction,
          {transactionResponseCode: payload.error.message, responseDesc: payload.error.message});
      } else {
        tran = mergeTransactionInformation(transaction.cachedTransaction,
          payload.payload
            ? payload.payload.Envelope.Header.Body.PaymentProcessingResponse
            : {});
      }
      store.dispatch(cacheTransaction(tran));
      router.push(`/confirmed/sale/${tran.applicationTransactionId}`);
      store.dispatch(unblockUI());
    })
    .catch((err) => {
      handleErrorToastr(err);
      store.dispatch(unblockUI());
    });
  }

  getLocation (country, zip) {
    const { store } = this.context;
    return store.dispatch(getLocation(country, zip));
  }

  cleanLocation () {
    const { store } = this.context;
    return store.dispatch(cleanLocation());
  }

  render () {
    const initialValues =
      {
        'country': 'US', 'origin': 'INTERNET', 'currency': '$', 'merchantId': ''
      };
    const styles = {
      padding: '0 30px 30px'
    };

    return (
      <div style={styles}>
        <h1 className='page-header' id='sale-transaction-h1'>Sale</h1>
        <SaleTransactionForm customSubmitHandler={this.handleSubmit}
          initialValues={initialValues}
          locationInfo={this.props.locationInfo}
          getLocation={this.getLocation}
          cleanLocation={this.cleanLocation}
          availableLegalEntities={this.props.availableLegalEntities} />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    transaction: state.transaction.currentTransaction,
    availableLegalEntities: state.misc.legalEntities,
    locationInfo: state.misc.location,
    username: state.auth.profile.username
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
  };
};

SaleTransaction.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SaleTransaction);
