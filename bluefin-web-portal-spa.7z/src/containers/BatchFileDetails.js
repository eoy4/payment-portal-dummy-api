import React from 'react';
import { connect } from 'react-redux';
import { blockUI, unblockUI, getTimeZone } from '../redux/modules/Misc';
import { default as moment } from 'moment';
import numeral from 'numeral';
import { getBatchFile, downloadTransactionsReport, cleanTransactionsReport } from '../redux/modules/BatchFile';
import { handleErrorToastr, createFilter, saveFile } from '../utils/utils';

type Props = {
  params: Object,
  currentBatchFile: Object,
  transactionsReport: Object,
  userTimeZone: string
}

export class BatchFileDetails extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = {processing: false};
    this.interval = null;

    this.goBack = this.goBack.bind(this);
    this.goToDetails = this.goToDetails.bind(this);
    this.handleDownloadReport = this.handleDownloadReport.bind(this);
    this.toggleAutoReload = this.toggleAutoReload.bind(this);
  }

  componentDidMount () {
    this.reloadData();
  }

  componentWillUnmount () {
    this.setAutoReload(false);
  }

  reloadData (timeout = 0) {
    const { store } = this.context;

    store.dispatch(blockUI());
    store.dispatch(getTimeZone());
    setTimeout(() => {
      this.silentLoad()
      .then((payload) => {
        store.dispatch(unblockUI());
      });
    }, timeout);
  }

  silentLoad () {
    const { store } = this.context;
    return store.dispatch(getBatchFile(this.props.params.batchUploadId));
  }

  setAutoReload (autoReload) {
    if (autoReload) {
      this.interval =
      this.interval || setInterval(() => {
        this.silentLoad();
      }, 5000);
      this.silentLoad();
    } else {
      this.interval &&
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  toggleAutoReload (e) {
    this.setState({autoReload: e.target.checked}, () => {
      return this.setAutoReload(this.state.autoReload);
    });
  }

  goBack () {
    const { router } = this.context;

    router.goBack();
  }

  goToDetails (e) {
    e.preventDefault && e.preventDefault();
    const { router } = this.context;
    const { currentBatchFile } = this.props;
    const filter = createFilter({
      batchUploadId: currentBatchFile.batchUploadId,
      mintransactionDateTime: moment(currentBatchFile.dateUploaded, 'MM/DD/YYYY hh:mm:ss A')
        .subtract(1, 'months'),
      maxtransactionDateTime: moment()
    });

    router.push({
      pathname: '/search/transactions',
      query: { filter: filter }
    });
  }

  handleDownloadReport (e) {
    e.preventDefault && e.preventDefault();
    const { currentBatchFile } = this.props;

    const { store } = this.context;

    this.setState({processing: true});
    store.dispatch(downloadTransactionsReport(currentBatchFile.batchUploadId))
    .then(() => {
      const fileName = `batch_return_file_${currentBatchFile.batchUploadId}_${moment().format('YYYY-MM-DD')}.txt`;
      saveFile(fileName, this.props.transactionsReport);

      this.setState({processing: false});

      store.dispatch(cleanTransactionsReport());
    })
    .catch((err) => {
      this.setState({processing: false});
      handleErrorToastr(err);
    });
  }

  render () {
    const { currentBatchFile } = this.props;
    const percentage = currentBatchFile.numberOfTransactions > 0
      ? (currentBatchFile.numberOfTransactionsProcessed +
        currentBatchFile.numberOfRejected) *
        100 / currentBatchFile.numberOfTransactions
      : 100;

    const emptyStyles = {color: '#CCC'};

    const tz = (this.props.params.timeZone) ? this.props.params.timeZone
    : ((this.props.userTimeZone) ? this.props.userTimeZone : moment.tz.guess());

    return (
      <div className='tab-content batch-transactions batch-transactions-details '>
        <div className='tab-pane active'>
          <div className='row'>
            <div className='col-xs-12'>
              <div className='form-group'>
                {currentBatchFile.processEnd
                  ? <button className='btn btn-primary'
                    style={{float: 'right'}}
                    disabled={this.state.processing}
                    onClick={this.handleDownloadReport} >
                      {(this.state.processing)
                        ? 'Processing'
                        : <span>
                          <i className='glyphicon glyphicon-circle-arrow-down'></i> Download Return File
                        </span>}
                  </button>
                  : null}
                <button className='btn btn-default' onClick={this.goBack} >&larr; Go Back</button>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xs-12'>
              <h2 className='sub-header'>
                <i className='glyphicon glyphicon-list'></i>
                &nbsp;
                Details for Batch Transaction with ID "{currentBatchFile.batchUploadId}"
              </h2>
            </div>
          </div>
          <div className='row'>
            <div className='form-group'>
              <label className='control-label' style={{whiteSpace: 'nowrap'}}>
                <input type="checkbox" onClick={this.toggleAutoReload} initialChecked={this.state.autoReload} />
                &nbsp;
                Auto-refresh
              </label>
            </div>
          </div>
          <div className='row'>
            <div className='col-xs-12'>
              <p style={{fontSize: '1.5em'}}>
                <strong>Percentage Completed:</strong>
                &nbsp;
                <strong>{numeral(percentage).format('0[.]0')}%</strong>
              </p>
            </div>
          </div>
          <div className='row'>
            <div className='col-md-6'>
              <p>
                <strong>Date Uploaded:</strong>
                &nbsp;
                {
                  currentBatchFile.dateUploaded
                  ? moment.utc(currentBatchFile.dateUploaded, 'MM/DD/YYYY hh:mm:ss A')
                    .tz(tz).format('YYYY/MM/DD HH:mm:ss')
                  : <span style={emptyStyles}>[empty]</span>
                }
              </p>
            </div>
            <div className='col-md-6'>
              <p>
                <strong>File Name:</strong>
                &nbsp;
                {
                  currentBatchFile.fileName
                  ? currentBatchFile.fileName
                  : <span style={emptyStyles}>[empty]</span>
                }
              </p>
            </div>
            <div className='col-md-6'>
              <p>
                <strong>Name:</strong>
                &nbsp;
                {
                  currentBatchFile.name
                  ? currentBatchFile.name
                  : <span style={emptyStyles}>[empty]</span>
                }
              </p>
            </div>
            <div className='col-md-6'>
              <p>
                <strong>User:</strong>
                &nbsp;
                {
                  currentBatchFile.upLoadedBy
                  ? currentBatchFile.upLoadedBy
                  : <span style={emptyStyles}>[empty]</span>
                }
              </p>
            </div>
          </div>
          <div className='row'>
            <div className='col-xs-12'>
              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th>Field</th>
                    <th>Value</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Total Number of Transactions</td>
                    <td>
                      {
                        (currentBatchFile.numberOfTransactions ||
                        currentBatchFile.numberOfTransactions === 0)
                        ? currentBatchFile.numberOfTransactions
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>Number of Transactions Processed</td>
                    <td>
                      {
                        (currentBatchFile.numberOfTransactionsProcessed ||
                        currentBatchFile.numberOfTransactionsProcessed === 0)
                        ? currentBatchFile.numberOfTransactionsProcessed
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>Number of Approved Transactions</td>
                    <td>
                      {
                        (currentBatchFile.numberOfApprovedTransactions ||
                        currentBatchFile.numberOfApprovedTransactions === 0)
                        ? currentBatchFile.numberOfApprovedTransactions
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>Number of Declined Transactions</td>
                    <td>
                      {
                        (currentBatchFile.numberOfDeclinedTransactions ||
                        currentBatchFile.numberOfDeclinedTransactions === 0)
                        ? currentBatchFile.numberOfDeclinedTransactions
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr className={currentBatchFile.numberOfErrorTransactions > 0 ? 'errors' : ''}>
                    <td>Number of Errors</td>
                    <td>
                      {
                        (currentBatchFile.numberOfErrorTransactions ||
                        currentBatchFile.numberOfErrorTransactions === 0)
                        ? currentBatchFile.numberOfErrorTransactions
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr className={currentBatchFile.numberOfRejected > 0 ? 'rejected' : ''}>
                    <td>Number of Rejected Transactions</td>
                    <td>
                      {
                        (currentBatchFile.numberOfRejected ||
                        currentBatchFile.numberOfRejected === 0)
                        ? currentBatchFile.numberOfRejected
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>Process Start Date/Time</td>
                    <td>
                      {
                        currentBatchFile.processStart
                        ? moment.utc(currentBatchFile.processStart, 'MM/DD/YYYY hh:mm:ss A')
                          .tz(tz).format('YYYY/MM/DD HH:mm:ss')
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                  <tr>
                    <td>Process End Date/Time</td>
                    <td>
                      {
                        currentBatchFile.processEnd
                        ? moment.utc(currentBatchFile.processEnd, 'MM/DD/YYYY hh:mm:ss A')
                          .tz(tz).format('YYYY/MM/DD HH:mm:ss')
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className='row'>
            <div className='col-xs-12'>
              <div className='form-group text-right'>
                <a href='#' onClick={this.goToDetails}>
                  <i className='glyphicon glyphicon-eye-open'></i>
                  &nbsp;
                  <strong>View this file's transactions</strong>
                </a>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-xs-12'>
              <button className='btn btn-default' onClick={this.goBack} >&larr; Go Back</button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    currentBatchFile: state.batchFile.currentBatchFile,
    transactionsReport: state.batchFile.transactionsReport,
    userTimeZone: state.misc.timeZone
  };
};

BatchFileDetails.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(BatchFileDetails);

