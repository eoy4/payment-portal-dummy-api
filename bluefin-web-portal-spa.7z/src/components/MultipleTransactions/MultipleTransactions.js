import React from 'react';
import { Link } from 'react-router';
import { Checkbox } from '../Checkbox/Checkbox';
import { CheckboxWithID } from '../CheckboxWithID/CheckboxWithID';
import { default as numeral } from 'numeral';
import { default as moment } from 'moment';

type Props = {
  transactions: Object,
  selectedTransactions: Object,
  type: string,
  onSelectItem: Function,
  onSelectAll: Function,
  allSelected: bool,
  currentFilter: string,
  currentId: string,
  maxResultsToRender: Number,
  timeZone: string,
  userTimeZone: string,
  params: Object
};
export default class MultipleTransactions extends React.Component {
  props: Props;

  static defaultProps = {
    maxResultsToRender: 100
  };

  constructor (props, defaultProps) {
    super(props, defaultProps);

    this.onChecked = this.onChecked.bind(this);
    this.handleSelectAll = this.handleSelectAll.bind(this);
  }

  componentDidMount () {
    this.onResize();

    const $ = window.$ || {};
    $(window).on('resize', this.onResize);
  }

  componentDidUpdate () {
    this.onResize();
  }

  onChecked (item) {
    this.props.onSelectItem(item);
  }

  handleSelectAll (value) {
    let transactions = {};
    if (value) {
      this.props.transactions.content.forEach((transaction) => {
        if ((transaction.transactionType === 'SALE' &&
          !(transaction.isVoided || transaction.isRefunded) &&
          transaction.internalStatusCode === '1')) {
          transactions[transaction.applicationTransactionId] = {
            checked: true,
            id: transaction.applicationTransactionId,
            item: transaction
          };
        }
      });
    }
    return this.props.onSelectAll(value, transactions);
  }

  customOnScroll (e) {
    const $ = window.$ || {};

    const $target = $(e.target);
    $('.scroller').not(e.target).scrollLeft($target.scrollLeft());
  }

  onResize () {
    const $ = window.$ || {};

    const $scroller = $('.scroller > div');
    const $target = $('.scroller-target');
    $scroller &&
    $scroller.length &&
    $scroller.each((index, element) => {
      const $element = $(element);
      const $parent = $element.parent();
      $element.css({width: $target.width(), height: '1px'});
      $parent.css({overflowX: 'auto'});
    });
  }

  render () {
    const transactions = this.props.transactions.content || [];
    const { selectedTransactions } = this.props;
    const styles = {
      padding: 0
    };

    const highlight = {
      'fontWeight': 'bold',
      'backgroundColor': 'yellow'
    };

    let filter = this.props.currentFilter;
    let match = '';
    try {
      match = filter.match(/transactionId:[\d\w]+/g)[0].split(':')[1];
    } catch (e) { }

    if (this.props.currentId) {
      match = this.props.currentId;
    }

    const tz = (this.props.params && this.props.params.timeZone) ? this.props.params.timeZone
    : (this.props.timeZone) ? this.props.timeZone
    : (this.props.userTimeZone) ? this.props.userTimeZone : moment.tz.guess();
    return (
      <div>
        <div className='scroller' onScroll={this.customOnScroll}>
          <div></div>
        </div>
        <div style={styles} className='scroller table-responsive' onScroll={this.customOnScroll}>
          <table className='table table-bordered editable-table scroller-target'>
            <thead>
              <tr>
                {
                  (this.props.type === 'check') &&
                    <th style={{whiteSpace: 'nowrap'}}>
                      <Checkbox value={this.props.allSelected} onChange={this.handleSelectAll} label='Select All' />
                    </th>
                }
                <th>Bluefin transaction ID</th>
                <th>Processor transaction ID</th>
                <th>Invoice Number</th>
                <th>Transaction Date</th>
                <th>Payment Frequency</th>
                <th>Accounting Period</th>
                <th>Account Number</th>
                <th>Amount</th>
                <th>User</th>
                <th>Legal Entity</th>
                <th>Latitude Desk</th>
                <th>Origin</th>
                <th>Card Number</th>
                <th>Card Type</th>
                <th>Customer</th>
                <th>Processor</th>
                <th>Status</th>
                <th>Transaction type</th>
              </tr>
            </thead>
            <tbody>
              {
                transactions.map((transaction, index) => {
                  if (index > this.props.maxResultsToRender) return null;
                  const idStyles =
                    (transaction.applicationTransactionId &&
                      (transaction.applicationTransactionId.toString() === match)) ? highlight : {};
                  const processorIdStyles =
                    (transaction.processorTransactionId &&
                      transaction.processorTransactionId.toString() === match) ? highlight : {};

                  let customerName = '';
                  customerName += (transaction.firstName ? transaction.firstName : '');
                  customerName += (customerName ? ' ' : '');
                  customerName += (transaction.lastName ? transaction.lastName : '');

                  const displayCheckbox = (transaction.transactionType === 'SALE' &&
                    !(transaction.isVoided || transaction.isRefunded) &&
                    transaction.internalStatusCode === '1');

                  const checkboxOptions = {};

                  if (displayCheckbox) {
                    checkboxOptions.item = transaction;
                    checkboxOptions.onChange = this.onChecked;

                    if (selectedTransactions[transaction.applicationTransactionId]) {
                      checkboxOptions.value = true;
                    }
                  }

                  return <tr key={`transaction-${index}`}>
                    {
                      (this.props.type === 'check') &&
                        <td className='text-center' style={{width: '90px'}}>
                          {
                            displayCheckbox
                            ? <CheckboxWithID {...checkboxOptions} />
                            : null
                          }
                        </td>
                    }
                    <td>
                      <p style={idStyles}>
                        <Link to={'/search/transactions/details/' +
                          transaction.applicationTransactionId +
                          '/' +
                          transaction.transactionType +
                          `${this.props.timeZone ? '/' + encodeURIComponent(this.props.timeZone) : ''}`}
                        >
                          {transaction.applicationTransactionId}
                        </Link>
                      </p>
                    </td>
                    <td>
                      <p style={processorIdStyles}>
                        <Link to={'/search/transactions/details/' + transaction.applicationTransactionId +
                          '/' +
                          transaction.transactionType}
                        >
                          {transaction.processorTransactionId}
                        </Link>
                      </p>
                    </td>
                    <td>{transaction.invoiceNumber}</td>
                    <td>
                      {moment.utc(transaction.transactionDateTime)
                        .tz(tz).format('MM/DD/YYYY hh:mm:ss a')}
                    </td>
                    <td>{transaction.paymentFrequency}</td>
                    <td>{transaction.accountPeriod}</td>
                    <td>{transaction.accountNumber}</td>
                    <td>{numeral(transaction.amount).format('$0,0.00')}</td>
                    <td>{transaction.processUser}</td>
                    <td>{transaction.legalEntity}</td>
                    <td>{transaction.desk}</td>
                    <td>{transaction.origin}</td>
                    <td>{transaction.cardNumberLast4Char}</td>
                    <td>{transaction.cardType}</td>
                    <td>{customerName}</td>
                    <td>{transaction.processorName}</td>
                    <td>{transaction.internalStatusDescription}</td>
                    <td>{transaction.transactionType}</td>
                  </tr>;
                })
              }
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}
