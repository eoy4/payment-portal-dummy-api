import React from 'react';
import { pageSize } from '../../utils/utils';

type Props = {
  onPagination: Function,
  onPageSizeChange: Function,
  currentPage: number,
  elements: Object,
  elementName: string,
  maxPagesLinks: number,
  numbersOnly: boolean,
  blocked: boolean
};

export class Pagination extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.clickHandlerPrev = this.clickHandlerPrev.bind(this);
    this.clickHandlerNext = this.clickHandlerNext.bind(this);
    this.clickHandlerFirst = this.clickHandlerFirst.bind(this);
    this.clickHandlerLast = this.clickHandlerLast.bind(this);
    this.getPageClickHandler = this.getPageClickHandler.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.onPageInputChange = this.onPageInputChange.bind(this);
    this.onPageSizeChangeHandler = this.onPageSizeChangeHandler.bind(this);
  }

  componentDidMount () {
    this.setState({pageInput: this.props.currentPage});
  }

  componentWillUpdate (nextProps) {
    if (nextProps.currentPage !== this.props.currentPage) {
      this.setState({pageInput: nextProps.currentPage});
    }
  }

  clickHandlerPrev (e) {
    e.preventDefault && e.preventDefault();
    if (this.props.blocked) {
      return false;
    }
    this.props.onPagination(this.props.currentPage - 1);
  }

  clickHandlerNext (e) {
    e.preventDefault && e.preventDefault();
    if (this.props.blocked) {
      return false;
    }
    this.props.onPagination(this.props.currentPage + 1);
  }

  clickHandlerFirst (e) {
    e.preventDefault && e.preventDefault();
    if (this.props.blocked) {
      return false;
    }
    this.props.onPagination(0);
  }

  clickHandlerLast (e) {
    e.preventDefault && e.preventDefault();
    if (this.props.blocked) {
      return false;
    }
    this.props.onPagination(this.props.elements.totalPages - 1);
  }

  getPageClickHandler (index) {
    return (e) => {
      e.preventDefault && e.preventDefault();
      if (this.props.blocked) {
        return false;
      }
      this.props.onPagination(index);
    };
  }

  onPageSizeChangeHandler (e) {
    e.preventDefault && e.preventDefault();
    if (this.props.blocked) {
      return false;
    }
    this.props.onPageSizeChange(e.target.value);
  }

  handleSubmit (e) {
    e.persist && e.persist();
    e.preventDefault && e.preventDefault();
    e.stopPropagation && e.stopPropagation();
    this.props && this.props.onPagination(--(e.target.elements['pageNumber'].value));
  }

  onPageInputChange (e) {
    let value = typeof e === 'string' ? e : (e.target && e.target.value);
    if (value !== '') {
      if (isNaN(value)) {
        value = 0;
      }
      --value;
      const {
        elements: { totalPages }
      } = this.props;

      if (value > totalPages - 1) {
        value = totalPages - 1;
      }
      if (value < 0) {
        value = 0;
      }
    }
    this.setState({pageInput: value});
  }

  render () {
    const {
      elements: { totalPages, first, last, size, number, totalElements },
      maxPagesLinks
    } = this.props;

    const page = this.props.currentPage;
    const currentPageSize = pageSize(this.props.elementName);

    const pages = [];
    let startPage = 0;
    let endPage = totalPages;

    const lowerLimit = Math.floor(page - (maxPagesLinks / 2));
    const higherLimit = Math.floor(page + (maxPagesLinks / 2));

    if (totalPages > maxPagesLinks) {
      if (lowerLimit > 0) {
        startPage = lowerLimit;
      }

      if (higherLimit < totalPages) {
        endPage = higherLimit;
      }
      if (higherLimit < maxPagesLinks) {
        endPage = maxPagesLinks;
      }

      if (endPage - startPage < maxPagesLinks) {
        startPage = endPage - maxPagesLinks;
      }
    }

    const nextClass = (last) ? 'disabled' : '';
    const prevClass = (first) ? 'disabled' : '';

    const firstPage = <li><a href='#' className={prevClass} aria-label='First'
      onClick={this.clickHandlerFirst}><span aria-hidden='true'>
        <i className='fa fa-angle-double-left'></i></span></a></li>;
    const prev = <li><a href='#' className={prevClass} aria-label='Previous'
      onClick={this.clickHandlerPrev}><span aria-hidden='true'>
        <i className='fa fa-angle-left'></i></span></a></li>;
    const next = <li><a href='#' className={nextClass} aria-label='Next'
      onClick={this.clickHandlerNext}><span aria-hidden='true'>
        <i className='fa fa-angle-right'></i></span></a></li>;
    const lastPage = <li><a href='#' className={nextClass} aria-label='First'
      onClick={this.clickHandlerLast}><span aria-hidden='true'>
        <i className='fa fa-angle-double-right'></i></span></a></li>;

    for (var i = startPage; i < endPage; i++) {
      const index = i;
      const currentClassName = (page === index) ? 'active' : '';
      const li = <li className={currentClassName} key={index}>
        <a href='#' onClick={this.getPageClickHandler(index)}>{index + 1}</a>
      </li>;
      pages.push(li);
    }

    const noResults = totalElements < 1;
    const elementName = this.props.elementName;

    let starting, ending;

    if (last && this.first) {
      starting = 0;
      ending = totalElements;
    } else if (last && !first) {
      starting = number * size;
      ending = totalElements;
    } else {
      starting = number * size;
      ending = starting + size;
    }

    let pageInputValue = this.state && this.state.pageInput;
    if (pageInputValue !== '') {
      ++pageInputValue;
    }

    const pageInput = <form className='pagination-input' onSubmit={this.handleSubmit}>
      <input type='text' value={pageInputValue} name='pageNumber' className='form-control'
        onChange={this.onPageInputChange} placeholder='#' />
      <button className='btn btn-primary' type='submit'>Go</button>
    </form>;

    const pageSizeOptions = [10, 15, 30, 50];
    const intSize = parseInt(currentPageSize);
    if (!pageSizeOptions.includes(intSize)) {
      pageSizeOptions.push(intSize);
    }
    pageSizeOptions.sort((a, b) => {
      return (a > b) ? 1 : -1;
    });
    const pageSizeSelect = <select name='pageSize'
      className='form-control'
      onChange={this.onPageSizeChangeHandler}
      value={currentPageSize}
    >
      {
        pageSizeOptions.map((size, index) => {
          return <option key={`size-option-${index}`} value={size}>{size}</option>;
        })
      }
    </select>;

    const blockedStyles = {
      opacity: this.props.blocked ? 0.5 : 1
    };

    return (
      <div style={blockedStyles}>
        {
          !this.props.numbersOnly && !noResults &&
            <p style={{margin: 0}}>
              Page {page + 1} of {totalPages}. Showing {elementName} {starting + 1}-{ending} out
              of {totalElements} total {elementName}.
            </p>
        }
        {
          !this.props.numbersOnly && totalElements === 1 &&
            <p style={{margin: 0}}>
              Showing 1 result.
            </p>
        }
        {
          !this.props.numbersOnly && noResults &&
            <p style={{margin: 0}}>
              No results to show.
            </p>
        }

        <div className='row'>
          <div className='col-lg-9 col-md-12'>
            {
              totalPages < 2 ? null
              : <ul className='pagination'>
                {firstPage}
                {prev}
                {pages}
                {next}
                {lastPage}
              </ul>
            }
          </div>
          <div className={`col-lg-1 col-md-2 col-sm-4 col-xs-5 page-size-container
            ${totalPages < 2 ? ' col-lg-offset-2' : ''}`}>
            <div className='form-group'>
              <label className='control-label'>Page&nbsp;Size</label>
              {pageSizeSelect}
            </div>
          </div>
          <div className='col-lg-2 col-md-2 col-sm-4 col-xs-7 page-input-container'>
            {
              totalPages < 2 ? null
              : <div className='form-group'>
                <label className='control-label'>Go to Page</label>
                {pageInput}
              </div>
            }
          </div>
        </div>
      </div>
    );
  }
}

export default Pagination;
