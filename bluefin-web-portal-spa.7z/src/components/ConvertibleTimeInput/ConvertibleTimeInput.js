import React from 'react';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';
import { ClockInput } from 'react-date-picker';
import { default as moment } from 'moment';

type Props = {
};

export class ConvertibleTimeInput extends ConvertibleInput {
  props: Props;

  constructor (props) {
    super(props);

    this.linkClassName = 'convertible-input-link time';
  }

  setEditing (event) {
    super.setEditing(event);

    setTimeout(() => {
      const $ = window.$ || {};
      const $timeInput = $(this.refs['timeInput']);
      $timeInput.length &&
      $timeInput.is(':visible') &&
      $timeInput.find('input').focus();
    }, 10);
  }

  onFocus () {}

  getLink () {
    const { value, linkDisplay } = this.props;
    const styles = {display: this.state.editing ? 'none' : linkDisplay};

    return value ? (
      <a href='#'
        className={this.linkClassName}
        id={this.props.id}
        onClick={this.setEditing}
        style={styles}
      >
        {this.props.value && moment(this.props.value, 'hh:mm:ss a').format('hh:mm:ss a')}
        &nbsp;
        <i className='glyphicon glyphicon-time'></i>
      </a>
    ) : this.getEmptyLink();
  }

  getInput () {
    const { inputDisplay } = this.props;
    const styles = {display: this.state.editing ? inputDisplay : 'none'};
    return (
      <div className='time-input' style={styles} id={this.props.id} ref='timeInput'>
        <ClockInput
          onBlur={this.onBlur}
          onFocus={this.onFocus}
          onChange={this.props.notifyChanges}
          defaultValue={this.props.value}
          forceValidDate
          dateFormat='hh:mm:ss a'
        />
      </div>
    );
  }
}
