import configure from 'redux-idle-monitor';
import { IDLE_STATUSES } from './constants';
import { idleStatusDelay, activeStatusAction, idleStatusAction } from './actions';

const opts = { appName: 'bluefin-web-portal', IDLE_STATUSES,
  idleStatusDelay, activeStatusAction, idleStatusAction};
const { middleware, reducer, actions } = configure(opts);

export { middleware, reducer, actions };
