import React from 'react';
import { default as numeral } from 'numeral';

type Props = {
  transactions: Array,
  onSelectItem: Object
};
export class MultipleTransactionConfirmationList extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.onChecked = this.onChecked.bind(this);
  }

  onChecked (item) {
    this.props.onSelectItem(item);
  }

  render () {
    const transactions = this.props.transactions.responses || [];
    const pendingTransactions = this.props.transactions.pendingTransactions || [];
    const styles = {
      padding: '15px 0'
    };

    return (
      <div style={styles} className='table-responsive'>
        <table className='table table-bordered'>
          <thead>
            <tr>
              <th>#</th>
              <th>Transaction ID</th>
              <th>Amount</th>
              <th>Processor</th>
              <th>Merchant ID</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
              {
                transactions.map((transaction, index) => {
                  return <tr key={transaction.transId || pendingTransactions[index].applicationTransactionId}>
                    <th scope='row'>{index + 1}</th>
                    <td>{transaction.transId || pendingTransactions[index].applicationTransactionId}</td>
                    <td>{numeral(transaction.amount).format('$0,0.00')}</td>
                    <td>{transaction.processor}</td>
                    <td>{transaction.merchantId}</td>
                    <td>
                      {
                        transaction.error && transaction.error.message
                          ? 'There was an error with the service...'
                          : transaction.responseDesc
                      }
                    </td>
                  </tr>;
                })
              }
          </tbody>
        </table>
      </div>
    );
  }
}

export default MultipleTransactionConfirmationList;

