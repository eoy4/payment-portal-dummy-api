import React from 'react';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';
import Cleave from 'cleave.js/react';

type Props = {
};

export class ConvertibleNumeralInput extends ConvertibleInput {
  props: Props;

  getInput () {
    return (
      <Cleave className='form-control'
        onBlur={this.onBlur}
        onChange={this.props.notifyChanges}
        onKeyUp={this.onKeyPress}
        id={this.props.id}
        ref='input'
        style={this.props.style}
        options={{
          numericOnly: true
        }}
      />
    );
  }

}
