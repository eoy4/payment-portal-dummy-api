import React from 'react';

type Props = {
  onChange: Function,
  value: boolean,
  id: string,
  label: string
};
export class Checkbox extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = {checked: (this.props.value || false)};
    this.toggleCheck = this.toggleCheck.bind(this);
  }

  componentWillUpdate (nextProps, nextState) {
    if (nextProps.value !== this.props.value) {
      nextState.checked = nextProps.value;
    }
  }

  toggleCheck () {
    if (this.state) {
      this.setState({ checked: !this.state.checked }, () => {
        this.props.onChange(this.state.checked);
      });
    }
  }

  render () {
    const checked = this.state && this.state.checked;
    return (
      <span onClick={this.toggleCheck} className={'custom-checkbox' + (checked ? ' checked' : '')}>
        {checked &&
          <i className='glyphicon glyphicon-check'></i>}
        {!checked &&
          <i className='glyphicon glyphicon-unchecked'></i>}
        {this.props && this.props.label &&
          <label>&nbsp;{this.props.label}</label>}
      </span>
    );
  }
}

export default Checkbox;

