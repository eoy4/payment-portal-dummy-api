import { Checkbox } from '../Checkbox/Checkbox';

type Props = {

};
export class CheckboxWithID extends Checkbox {
  props: Props;

  toggleCheck () {
    if (this.state) {
      this.setState({ checked: !this.state.checked }, () => {
        this.props.onChange(
          { item: this.props.item, id: this.props.item.applicationTransactionId, checked: this.state.checked });
      });
    }
  }
}

export default CheckboxWithID;

