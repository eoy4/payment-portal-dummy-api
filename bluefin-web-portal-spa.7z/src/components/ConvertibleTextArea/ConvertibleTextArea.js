import React from 'react';
import ReactDOM from 'react-dom';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';

type Props = {
};

export class ConvertibleTextArea extends ConvertibleInput {
  props: Props;

  constructor (props) {
    super(props);

    this.linkClassName = 'convertible-input-link textarea';
  }

  onKeyPress (event) {
    const input = ReactDOM.findDOMNode(this.refs['input']);
    if (event.key &&
        event.key.toLowerCase() === 'escape') {
      input && input.blur();
    }
  }

  focused () {
    const input = ReactDOM.findDOMNode(this.refs['input']);
    if (input) {
      input.style.height = (input.scrollHeight >= input.clientHeight) ? (input.scrollHeight) + 'px' : 'auto';
    }
  }

  getInput () {
    const { inputDisplay } = this.props;
    const styles = {display: this.state.editing ? inputDisplay : 'none'};
    return (
      <textarea id={this.props.id}
        onBlur={this.onBlur}
        onFocus={this.onFocus}
        onChange={this.props.notifyChanges}
        onKeyUp={this.onKeyPress}
        defaultValue={this.props.value}
        ref='input'
        style={styles}
      />
    );
  }
}
