import React from 'react';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';

type Props = {
  options: Object
};

function isNumber (n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

export class ConvertibleSelect extends ConvertibleInput {
  props: Props;

  getInput () {
    const { options, inputDisplay } = this.props;
    let optionElements = [];

    options &&
    options.forEach((option, index) => {
      optionElements.push(<option key={index} value={index}>{option}</option>);
    });
    const styles = {display: this.state.editing ? inputDisplay : 'none'};

    return (
      <select id={this.props.id}
        className='form-control'
        onChange={this.onBlur}
        onBlur={this.onBlur}
        value={this.props.value}
        ref='input'
        style={styles}
      >
        {optionElements}
      </select>
    );
  }

  getLink () {
    const { linkDisplay } = this.props;
    const selectedValue = isNumber(this.props.value) ? parseInt(this.props.value) : this.props.value;
    const styles = {display: this.state.editing ? 'none' : linkDisplay};
    return (
      <a href='#'
        className='convertible-input-link'
        id={this.props.id}
        onClick={this.setEditing}
        style={styles}
      >
        {typeof this.props.options.get === 'function' &&
          this.props.options.get(selectedValue)}
        &nbsp;
        <sup>
          <i className={this.props.editIconClassName}></i>
        </sup>
      </a>
    );
  }
}
