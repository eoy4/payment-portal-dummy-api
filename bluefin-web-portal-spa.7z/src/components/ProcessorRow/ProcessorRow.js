import React from 'react';
import { Checkbox } from '../Checkbox/Checkbox';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';
import { ConvertibleTimeInput } from '../ConvertibleTimeInput/ConvertibleTimeInput';
import { Link } from 'react-router';
import { handleSuccessToastr } from '../../utils/utils';
import { default as moment } from 'moment';

type Props = {
  processor: Object,
  confirmUpdate: Function,
  notifyChanges: Function,
  dirty: boolean,
  timeZone: string
}

export class ProcessorRow extends React.Component {
  props: Props;

  static defaultProps = {
    processor: {
      paymentProcessorId: false,
      processorName: '',
      remitTransactionOpenTime: '',
      remitTransactionCloseTime: '',
      readyToBeActivated: 0,
      isActive: 0
    }
  };

  constructor (props, defaultProps) {
    super(props, defaultProps);

    this.state = this.getDefaultState();

    this.notifyChanges = this.notifyChanges.bind(this);
    this.handleUpdate = this.handleUpdate.bind(this);
  }

  clearState () {
    this.setState({
      paymentProcessorId: '',
      isActive: 0,
      processorName: '',
      readyToBeActivated: false,
      remitTransactionCloseTime: '00:00:00',
      remitTransactionOpenTime: '00:00:00'
    });
  }

  getDefaultState () {
    const closeTime = this.props.processor && this.props.processor.remitTransactionCloseTime;
    const processor = Object.assign({}, this.props.processor, {
      remitTransactionCloseTime: closeTime
        ? moment.utc(closeTime, 'HH:mm:ss')
          .tz(this.props.timeZone)
          .format('HH:mm:ss')
        : ''
    });

    return {...processor};
  }

  setDefaultState () {
    this.setState(this.getDefaultState());
  }

  hasChanges () {
    const { processor } = this.props;
    const newProcessor = Object.assign({}, this.state);

    return processor.processorName !== newProcessor.processorName ||
    processor.isActive !== newProcessor.isActive ||
    processor.remitTransactionCloseTime !== newProcessor.remitTransactionCloseTime;
  }

  /**
  * Determines if we are editing an existing rule, or creating a new one. Then formats the data from
  * Props and State and passes it on to the confirmUpdate callback that was provided via Props.
  */
  handleUpdate (event) {
    event.preventDefault && event.preventDefault();
    const { confirmUpdate } = this.props;
    const newProcessor = Object.assign({}, this.state);

    if (this.hasChanges()) {
      confirmUpdate(newProcessor);
    } else {
      handleSuccessToastr('No changes to save...');
    }
  }

  getInputHandler (field) {
    return (value) => {
      this.handleInput(field, value);
    };
  }

  getActiveToggleHandler (paymentProcessorId) {
    return (value) => {
      let newState = {};
      newState.isActive = value ? 1 : 0;
      this.setState(newState, () => {
        this.notifyChanges();
      });
    };
  }

  handleInput (field, value) {
    if (typeof value === 'object' && value.target) {
      value = value.target.value;
    }
    if (field === 'remitTransactionCloseTime' || field === 'remitTransactionOpenTime') {
      value = moment(value, 'hh:mm:ss a').format('HH:mm:ss');
    }
    let newState = {};
    newState[field] = value;
    this.setState(newState, () => {
      this.notifyChanges();
    });
  }

  notifyChanges () {
    if (!this.props.dirty) {
      // Call the notifyChanges callback funciton (provided via Props)
      // to notify the parent that there are unsaved changes.

      if (this.hasChanges()) {
        this.props.notifyChanges && this.props.notifyChanges(this.props.processor.paymentProcessorId);
      }
    };
  }

  render () {
    const { processor } = this.props;

    const row = (
      <tr className={this.props.dirty ? 'unsaved-changes' : ''}>
        {processor.paymentProcessorId ? (<td className='processor-status text-center' style={{width: '90px'}}>
          {
            this.state.readyToBeActivated
            ? <i className='glyphicon glyphicon-ok-sign' title='Checklist complete'></i>
            : <i className='glyphicon glyphicon-remove-sign' title='Missing steps in Checklist'></i>
          }
        </td>) : null}
        <td>
          <ConvertibleInput id={'processorName-' + this.state.paymentProcessorId}
            onChange={this.getInputHandler('processorName')}
            value={this.state.processorName}
            regex={/\w[\w|\s|\.|'|\-]*/g}
          />
        </td>
        <td style={{width: '160px'}}>
          <ConvertibleTimeInput
            value={this.state.remitTransactionCloseTime}
            onChange={this.getInputHandler('remitTransactionCloseTime')}
          />
        </td>
        {processor.paymentProcessorId ? (<td className='text-center' style={{width: '90px'}}>
          <Link to={'/processors/' + processor.paymentProcessorId}>
            <i className='glyphicon glyphicon-list'></i>
          </Link>
        </td>) : null}
        {processor.paymentProcessorId ? (<td className='text-center' style={{width: '90px'}}>
          <Checkbox
            onChange={this.getActiveToggleHandler(processor.paymentProcessorId)}
            value={this.state.isActive}
          />
        </td>) : null}
        <td className='text-center' style={{width: '90px'}}>
          <a href='#' title='Save' onClick={this.handleUpdate}>
            <i className='glyphicon glyphicon-floppy-disk'></i>
          </a>
        </td>
      </tr>
    );

    return row;
  }
}
