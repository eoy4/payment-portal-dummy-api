import React from 'react';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';
import { ConvertibleTextArea } from '../ConvertibleTextArea/ConvertibleTextArea';

type Props = {
  codeId: String,
  codes: Object,
  existingCodeInfo: Object,
  paymentProcessorIds: Array,
  getInputHandler: Function,
  getSaveHandler: Function,
  getDeleteHandler: Function,
  notifyChanges: Function,
  dirty: boolean
}

export class StatusCodeRow extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.unsavedChanges = this.unsavedChanges.bind(this);
  }

  unsavedChanges () {
    if (!this.props.dirty) {
      // Call the notifyChanges callback funciton (provided via Props)
      // to notify the parent that there are unsaved changes.
      this.props.notifyChanges && this.props.notifyChanges(this.props.codeId);
    };
  }

  render () {
    const {
      codeId,
      codes: {
        internalStatusCode,
        internalStatusCodeDescription,
        processorStatusCodes
      },
      existingCodeInfo,
      paymentProcessorIds,
      getInputHandler,
      getSaveHandler,
      getDeleteHandler
    } = this.props;

    // calculate width: 100 percent divided by the total columns
    const cols = 3 + (paymentProcessorIds.length * 2);
    const width = 100 / cols;
    const styles = {width: width + '%'};

    const rows = [];

    const initRow = (currentRow) => {
      rows[currentRow] = {};
      paymentProcessorIds.forEach((id) => {
        rows[currentRow][id] = {
          processorCodeId: '',
          processorCode: '',
          processorCodeDescription: ''
        };
      });
    };

    initRow(0);

    const insertCode = (code, currentRow = 0) => {
      if (!rows[currentRow]) {
        initRow(currentRow);
      }
      if (rows[currentRow][code.paymentProcessorStatusCode.processorId] &&
        rows[currentRow][code.paymentProcessorStatusCode.processorId].processorCodeId) {
        return insertCode(code, ++currentRow);
      } else {
        rows[currentRow][code.paymentProcessorStatusCode.processorId] = {
          processorCodeId: code.paymentProcessorInternalStatusCodeId || '',
          processorCode: code.paymentProcessorStatusCode.paymentProcessorStatusCode,
          processorCodeDescription: code.paymentProcessorStatusCode.paymentProcessorStatusCodeDescription
        };
      }
    };

    paymentProcessorIds.forEach((id) => {
      const processorCodes = processorStatusCodes &&
        processorStatusCodes[id];

      processorCodes && Object.keys(processorCodes).forEach((processorCode) => {
        insertCode(processorCodes && processorCodes[processorCode]);
      });
    });

    const internalCodeArr = [
      <td key={`bluefin-code-${codeId}`} rowSpan={rows.length}
        className='text-center' style={{verticalAlign: 'middle', width: width / 4 + '%'}}
      >
        <ConvertibleInput id={`bluefin-code-${codeId}`}
          onChange={getInputHandler && getInputHandler(codeId, false, false, 'internalStatusCode')}
          notifyChanges={this.unsavedChanges}
          value={internalStatusCode}
          regex={/\w[\w|\s|\.|'|\-]*/g}
        />
      </td>,
      <td key={`bluefin-desc-${codeId}`} rowSpan={rows.length}
        className='text-center' style={{verticalAlign: 'middle', width: width / 4 + '%'}}
      >
        {
          existingCodeInfo &&
          existingCodeInfo.internalStatusCodeDescription
          ? <p>{existingCodeInfo.internalStatusCodeDescription}</p>
          : <ConvertibleTextArea id={`bluefin-desc-${codeId}`}
            onChange={getInputHandler && getInputHandler(codeId, false, false, 'internalStatusCodeDescription')}
            notifyChanges={this.unsavedChanges}
            value={internalStatusCodeDescription}
          />
        }
      </td>
    ];
    const actionsArr = [
      <td key={`actions-save-${codeId}`} rowSpan={rows.length} colSpan={codeId ? 1 : 2} className='text-center'
        style={{textAlign: 'center', verticalAlign: 'middle', width: width / 4 + '%'}}
      >
        <a href='#' title='Save'
          onClick={getSaveHandler &&
            getSaveHandler(codeId, existingCodeInfo && existingCodeInfo.internalStatusCodeId)}
        >
          <i className='glyphicon glyphicon-floppy-disk'></i>
        </a>
      </td>,
      codeId
      ? <td key={`actions-delete-${codeId}`} rowSpan={rows.length} className='text-center'
        style={{width: width / 4 + '%', verticalAlign: 'middle'}}
      >
        <a href='#' title='Delete' onClick={getDeleteHandler && getDeleteHandler(codeId)}>
          <i className='glyphicon glyphicon-remove'></i>
        </a>
      </td>
      : null
    ];

    const rowsObject = rows.length
      ? rows.map((row, index) => {
        return <tr key={`row-${index}`}>
          {
          [
            index === 0
              ? internalCodeArr
              : null,
            Object.keys(row).map((processorId) => {
              const mappedCode = row[processorId];
              return [
                <td className='text-center' style={styles} key={`processor-code-${processorId}`}>
                  <ConvertibleInput
                    id={`processor-code-${processorId}`}
                    onChange={getInputHandler && getInputHandler(codeId, mappedCode.processorCodeId,
                      processorId, 'paymentProcessorStatusCode')}
                    notifyChanges={this.unsavedChanges}
                    value={mappedCode.processorCode}
                    regex={/\w[\w|\s|\.|'|\-]*/g}
                  />
                </td>,
                <td className='text-center' style={styles} key={`processor-desc-${processorId}`}>
                  <ConvertibleTextArea
                    id={`processor-desc-${processorId}`}
                    onChange={getInputHandler && getInputHandler(codeId, mappedCode.processorCodeId,
                        processorId, 'paymentProcessorStatusCodeDescription')}
                    notifyChanges={this.unsavedChanges}
                    value={mappedCode.processorCodeDescription}
                  />
                </td>
              ];
            }),
            index === 0
              ? actionsArr
              : null
          ]
          }
        </tr>;
      })
      : <tr>
        {internalCodeArr}
        {actionsArr}
      </tr>;

    return (
      <tbody className={this.props.dirty ? 'unsaved-changes' : ''}>
        {rowsObject}
      </tbody>
    );
  }
}

StatusCodeRow.defaultProps = {
  codeId: false,
  codes: {
    internalStatusCode: '',
    internalStatusCodeDescription: '',
    processorStatusCodes: null
  },
  paymentProcessorIds: [],
  dirty: false
};
