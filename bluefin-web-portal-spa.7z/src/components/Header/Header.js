import React from 'react';
import { Link } from 'react-router';

type Props = {
  isAuthenticated: boolean,
  user: Object,
  onLogout: Function
};

export class Header extends React.Component {
  props: Props;

  render () {
    const innerContent = (this.props.isAuthenticated)
      ? <ul className='nav'>
        <li className='dropdown'>
          <button className='btn-profile dropdown-toggle' type='toggle-profile' name='button' data-toggle='dropdown'>
            <i className='glyphicon glyphicon-user'></i>
            <span className='user-profile'>Welcome, {this.props.user.username}</span>
          </button>
          <ul className='dropdown-menu'>
            <li><Link to={'/account'}><i className='glyphicon glyphicon-user'></i> Profile</Link></li>
            <li className='divider'></li>
            <li>
              <a href='/login' onClick={this.props.onLogout}>
                <i className='glyphicon glyphicon-log-out'></i> Logout</a>
            </li>
          </ul>
        </li>
      </ul> : <a href='/'><img src='/img/logo.png' alt='Encore' className='logo' /></a>;

    return (
      <div className='header-nav-inner col-xs-12'>
        {innerContent}
      </div>
    );
  }
}

export default Header;
