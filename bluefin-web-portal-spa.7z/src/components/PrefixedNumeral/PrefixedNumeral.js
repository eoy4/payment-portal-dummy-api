import React from 'react';
import Cleave from 'cleave.js/react';

type Props = {
  prefix: string,
  onChange: Function,
  onPaste: Function,
  onCopy: Function,
  onBlur: Function,
  value: string,
  name: string,
  placeholder: string,
  id: string
};
export class PrefixedNumeralInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);
    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (event) {
    let value = event.target.rawValue.replace(this.props.prefix, '');
    this.props.onChange(value);
  }

  render () {
    const { value, name, onBlur, onPaste, onCopy, id } = this.props;
    return (
      <Cleave className='form-control'
        value={value}
        name={name}
        placeholder={this.props.placeholder}
        options={{numeral: true, numeralDecimalScale: 2, prefix: this.props.prefix}}
        onChange={this.updateValue}
        onPaste={onPaste}
        onCopy={onCopy}
        onBlur={onBlur}
        id={id} />
    );
  }
}

export default PrefixedNumeralInput;

