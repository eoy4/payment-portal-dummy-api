import React from 'react';

type Props = {
  loading: boolean,
  prompt: string,
  callbackOk: Function,
  callbackCancel: Function
};
export class BlockingOverlay extends React.Component {
  props: Props;

  render () {
    let content = null;

    if (this.props.loading) {
      content = (
        <img src='/img/loader.gif' className='loader' alt='Loader' />
      );
    } else if (this.props.prompt) {
      content = (
        <div className='prompt'>
          <p>{this.props.prompt}</p>
          <div className='button-group'>
            <button className='btn btn-primary' onClick={this.props.callbackOk}>
              OK
            </button>
            <button className='btn btn-default' onClick={this.props.callbackCancel}>
              Cancel
            </button>
          </div>
        </div>
      );
    }
    return (
      (this.props.loading || this.props.prompt)
        ? <div className='overlay'>
          <div>
            <div>
              {content}
            </div>
          </div>
        </div> : null
    );
  }
}

export default BlockingOverlay;

