import React from 'react';
import Cleave from 'cleave.js/react';

type Props = {
  prefix: string,
  onChange: Function,
  onPaste: Function,
  onCopy: Function,
  placeholder: string,
  name: string,
  maxLength: number,
  id: string
};
export class NumeralInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);
    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (event) {
    this.props.onChange(event.target.value);
  }

  render () {
    return (
      <Cleave className='form-control'
        name={this.props.name}
        placeholder={this.props.placeholder}
        options={{
          blocks: [this.props.maxLength],
          numericOnly: true
        }}
        onPaste={this.props.onPaste}
        onCopy={this.props.onCopy}
        onChange={this.updateValue}
        id={this.props.id} />
    );
  }
}

export default NumeralInput;

