import React from 'react';
import { RegexValidatedInput } from '../RegexValidatedInput/RegexValidatedInput';

type Props = {
  onChange: Function,
  handleLocation: Function,
  name: string,
  value: string,
  id: string
};
export class PostalCodeInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);
    this.updateValue = this.updateValue.bind(this);
    this.onBlur = this.onBlur.bind(this);
  }

  onBlur (event) {
    this.props.handleLocation(event.target.value);
  }

  updateValue (value) {
    this.props.onChange(value);
  }

  render () {
    return (
      <RegexValidatedInput value={this.props.value} onBlur={this.onBlur} name={this.props.name}
        className='form-control' type='text' regex={/\w[\w|\s|\.|'|\-]*/g}
        placeholder='ZIP/Postal Code' onChange={this.updateValue} id={this.props.id} />
    );
  }
}

export default PostalCodeInput;

