import React from 'react';
import { default as numeral } from 'numeral';

type Props = {
  transaction: Object
};
export class SingleTransaction extends React.Component {
  props: Props;

  render () {
    const { transaction } = this.props;

    const cardNumber = transaction.cardNumberLast4Char.replace(' ', '');
    const formattedCardNumber =
      `${cardNumber.substr(0, 4)} ${cardNumber.substr(4, 2)}XX XXXX ${cardNumber.substr(cardNumber.length - 4)}`;

    return (
      <div>
        <h2>Details for {transaction.applicationTransactionId}</h2>
        <div className='table-responsive'>
          <table className='table table-bordered'>
            <thead>
              <tr>
                <th>#</th>
                <th>Account Number</th>
                <th>Amount</th>
                <th>Legal Entity App</th>
                <th>Card Number</th>
                <th>Card Type</th>
                <th>Customer</th>
                <th>Processor</th>
                <th>Status</th>
                <th>Transaction type</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope='row'>1</th>
                <td>{transaction.accountNumber}</td>
                <td>{numeral(transaction.amount).format('$0,0.00')}</td>
                <td>{transaction.legalEntity}</td>
                <td>{formattedCardNumber}</td>
                <td style={{whiteSpace: 'nowrap'}}>{transaction.cardType}</td>
                <td>{transaction.customer}</td>
                <td>{transaction.processorName}</td>
                <td>{transaction.transactionResponseCode}</td>
                <td>{transaction.transactionType}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default SingleTransaction;
