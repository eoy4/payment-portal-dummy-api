import React from 'react';
import { Link } from 'react-router';
import { default as numeral } from 'numeral';
import { default as moment } from 'moment';
import { getTransactionObjects } from '../../utils/utils';

type Props = {
  remittances: Array,
  onSelectItem: Object,
  currentFilter: string,
  currentId: string,
  maxResultsToRender: Number,
  reconciliationStatusMap: Object,
  timeZone: string
};

export default class MultipleRemittances extends React.Component {
  props: Props;

  static defaultProps = {
    maxResultsToRender: 100
  };

  constructor (props, defaultProps) {
    super(props, defaultProps);

    this.onChecked = this.onChecked.bind(this);
  }

  componentDidMount () {
    this.onResize();

    const $ = window.$ || {};
    $(window).on('resize', this.onResize);
  }

  componentDidUpdate () {
    this.onResize();
  }

  onChecked (item) {
    this.props.onSelectItem(item);
  }

  customOnScroll (e) {
    const $ = window.$ || {};

    const $target = $(e.target);
    $('.scroller').not(e.target).scrollLeft($target.scrollLeft());
  }

  onResize () {
    const $ = window.$ || {};

    const $scroller = $('.scroller > div');
    const $target = $('.scroller-target');
    $scroller &&
    $scroller.length &&
    $scroller.each((index, element) => {
      const $element = $(element);
      const $parent = $element.parent();
      $element.css({width: $target.width(), height: '1px'});
      $parent.css({overflowX: 'auto'});
    });
  }

  render () {
    const transactionObjects = getTransactionObjects(this.props.remittances.content);
    const styles = {
      padding: 0
    };

    const diffStyles = {color: '#c02'};
    const diffStylesRow = {fontWeight: 'bold', color: 'rgb(100,0,22)'};
    const emptyStyles = {color: '#CCC'};

    const wideLeftBorder = {borderLeftWidth: '4px'};

    const {reconciliationStatusMap} = this.props;

    return (
      <div>
        <div className='scroller' onScroll={this.customOnScroll}>
          <div></div>
        </div>
        <div style={styles} className='scroller table-responsive' onScroll={this.customOnScroll}>
          <table className='table table-bordered editable-table scroller-target'>
            <thead>
              <tr>
                <th rowSpan='2'>Payment Processor</th>
                <th rowSpan='2'>Status</th>
                <th rowSpan='2'>Amount Difference</th>
                <th rowSpan='2'>Transaction Type</th>
                <th colSpan='4' className='text-center' style={wideLeftBorder}>Bluefin</th>
                <th colSpan='4' className='text-center' style={wideLeftBorder}>Remittance</th>
                <th rowSpan='2' style={wideLeftBorder}>Card Type</th>
                <th rowSpan='2'>Card Number (last 4)</th>
                <th rowSpan='2'>Merchant ID</th>
                <th rowSpan='2'>Application</th>
              </tr>
              <tr>
                <th style={wideLeftBorder}>Transaction ID</th>
                <th>Account Number</th>
                <th>Amount</th>
                <th>Date/Time</th>
                <th style={wideLeftBorder}>Transaction ID</th>
                <th>Account Number</th>
                <th>Amount</th>
                <th>Date/Time</th>
              </tr>
            </thead>
            <tbody>
                {
                  transactionObjects &&
                  transactionObjects.map((transactionObject, index) => {
                    if (index > this.props.maxResultsToRender) return null;

                    // Build the "details" link
                    const urlFilters = {id: '', processorType: 'other'};
                    if (transactionObject.saleTransaction.processorTransactionId) {
                      urlFilters.id = transactionObject.saleTransaction.processorTransactionId;
                    } else if (transactionObject.paymentProcessorRemittance.processorTransactionId) {
                      urlFilters.id = transactionObject.paymentProcessorRemittance.processorTransactionId;
                    } else {
                      urlFilters.id = transactionObject.saleTransaction.applicationTransactionId;
                      urlFilters.processorType = 'BlueFin';
                    }

                    // Get the reconciliation status ID from either the sale object or the remit object
                    const reconciliationStatusId =
                      transactionObject.saleTransaction.reconciliationStatusId
                      ? transactionObject.saleTransaction.reconciliationStatusId
                      : transactionObject.paymentProcessorRemittance.reconciliationStatusId;

                    // Store all the reconciliation discrepancies
                    const recon = {};
                    recon.transactionAmount = (Math.abs(transactionObject.saleTransaction.amount) ===
                      Math.abs(transactionObject.paymentProcessorRemittance.transactionAmount));
                    recon.accountId = (transactionObject.saleTransaction.accountNumber ===
                      transactionObject.paymentProcessorRemittance.accountId);
                    recon.reconciliationStatusId =
                      (transactionObject.saleTransaction.reconciliationStatusId ===
                        transactionObject.paymentProcessorRemittance.reconciliationStatusId);
                    recon.merchantId =
                      (transactionObject.saleTransaction.merchantId ===
                        transactionObject.paymentProcessorRemittance.merchantId);
                    recon.application =
                      (transactionObject.saleTransaction.application ===
                        transactionObject.paymentProcessorRemittance.application);

                    let hasDiscrepancy = false;
                    if (transactionObject.saleTransaction.reconciliationStatusId !== 1 ||
                      transactionObject.paymentProcessorRemittance.reconciliationStatusId !== 1 ||
                      !recon.transactionAmount ||
                      !recon.accountId ||
                      !recon.reconciliationStatusId ||
                      !recon.merchantId ||
                      !recon.application) {
                      hasDiscrepancy = true;
                    }

                    return <tr key={`transactionObject-${index}`} style={hasDiscrepancy ? diffStylesRow : {}}>
                      <td>
                        {
                          transactionObject.saleTransaction.processorName
                            ? transactionObject.saleTransaction.processorName
                            : transactionObject.paymentProcessorRemittance.processorName
                        }
                      </td>
                      <td style={recon.reconciliationStatusId ? {} : diffStyles}>
                        {
                          reconciliationStatusId
                          ? <span>
                            {
                              reconciliationStatusMap &&
                              reconciliationStatusMap.get(reconciliationStatusId).reconciliationStatus
                            }
                          </span>
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={recon.transactionAmount ? {} : diffStyles}>
                        {
                          transactionObject.saleTransaction.amount
                          ? <span>
                            {
                              numeral(Math.abs(Math.abs(transactionObject.saleTransaction.amount) -
                                Math.abs(transactionObject.paymentProcessorRemittance.transactionAmount)))
                              .format('$0,0.00')
                            }
                          </span>
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td>
                        {
                          transactionObject.saleTransaction.transactionType
                            ? transactionObject.saleTransaction.transactionType
                            : transactionObject.paymentProcessorRemittance.transactionType
                        }
                      </td>
                      <td style={Object.assign({}, wideLeftBorder, recon.accountId ? {} : diffStyles)}>
                        {
                          transactionObject.saleTransaction.applicationTransactionId
                          ? <Link
                            to={'/search/remittance/details/' +
                              urlFilters.id + '/' +
                              (transactionObject.saleTransaction.transactionType
                              ? transactionObject.saleTransaction.transactionType
                              : transactionObject.paymentProcessorRemittance.transactionType) + '/' +
                              urlFilters.processorType}
                          >
                            {transactionObject.saleTransaction.applicationTransactionId}
                          </Link>
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td>
                        {
                          transactionObject.saleTransaction.accountNumber
                          ? transactionObject.saleTransaction.accountNumber
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={recon.transactionAmount ? {} : diffStyles}>
                        {
                          transactionObject.saleTransaction.amount
                          ? <span>
                            {
                              numeral(transactionObject.saleTransaction.amount)
                              .format('$0,0.00')
                            }
                          </span>
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td>
                        {
                          transactionObject.saleTransaction.transactionDateTime
                          ? moment.utc(transactionObject.saleTransaction.transactionDateTime)
                            .tz(this.props.timeZone)
                            .format('MM/DD/YYYY hh:mm:ss a')
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={wideLeftBorder}>
                        {
                          transactionObject.paymentProcessorRemittance.processorTransactionId
                          ? <Link
                            to={'/search/remittance/details/' +
                              urlFilters.id + '/' +
                              transactionObject.paymentProcessorRemittance.transactionType + '/' +
                              urlFilters.processorType}
                          >
                            {transactionObject.paymentProcessorRemittance.processorTransactionId}
                          </Link>
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={recon.accountId ? {} : diffStyles}>
                        {
                          transactionObject.paymentProcessorRemittance.accountId
                          ? transactionObject.paymentProcessorRemittance.accountId
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={recon.transactionAmount ? {} : diffStyles}>
                        {
                          transactionObject.paymentProcessorRemittance.transactionAmount
                          ? <span>
                            {
                              numeral(transactionObject.paymentProcessorRemittance.transactionAmount)
                                .format('$0,0.00')
                            }
                          </span>
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td>
                        {
                          transactionObject.paymentProcessorRemittance.transactionDate
                          ? moment.utc(transactionObject.paymentProcessorRemittance.transactionDate)
                            .tz(this.props.timeZone)
                            .format('MM/DD/YYYY hh:mm:ss a')
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={wideLeftBorder}>
                        {
                          transactionObject.saleTransaction.cardType
                          ? transactionObject.saleTransaction.cardType
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td>
                        {
                          transactionObject.saleTransaction.cardNumberLast4Char
                          ? transactionObject.saleTransaction.cardNumberLast4Char
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={recon.merchantId ? {} : diffStyles}>
                        {
                          transactionObject.saleTransaction.merchantId
                          ? transactionObject.saleTransaction.merchantId
                          : transactionObject.paymentProcessorRemittance.merchantId
                          ? transactionObject.paymentProcessorRemittance.merchantId
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                      <td style={recon.application ? {} : diffStyles}>
                        {
                          transactionObject.saleTransaction.application
                          ? transactionObject.saleTransaction.application
                          : transactionObject.paymentProcessorRemittance.application
                          ? transactionObject.paymentProcessorRemittance.application
                          : <span style={emptyStyles}>[empty]</span>
                        }
                      </td>
                    </tr>;
                  })
                }
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}
