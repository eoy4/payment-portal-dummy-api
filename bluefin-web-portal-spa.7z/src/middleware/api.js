import { MICROSERVICE } from '../../config/api';
import { UserException } from '../utils/utils';
import 'es6-promise';
import 'whatwg-fetch';

function callApi (endpoint, authenticated, body, method = 'GET', headers, baseUrl, removeHeaders, timeout = 30000) {
  const BASE_URL = (!baseUrl) ? MICROSERVICE.BASE_URL : baseUrl;
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };

  let config = {
    method
  };

  if (!removeHeaders) {
    const defaultHeaders = {
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json'
    };
    config.headers = Object.assign({}, defaultHeaders, headers);
    if (authenticated) {
      if (token) {
        config.headers['X-Auth-Token'] = token;
      } else {
        return Promise.reject(new UserException('Not logged in.', { status: 401 }));
      }
    }
  }

  if (body) {
    config.body = body;
  }

  return new Promise((resolve, reject) => {
    const timeoutObj = setTimeout(() => {
      // console.warn && console.warn(`Request to ${BASE_URL + endpoint} timed out.`);
      reject(new Error('The request to the server has timed out.'));
    }, timeout);

    fetch(BASE_URL + endpoint, config)
    .then(response =>
      response.json().then(json => ({ json, response })).catch(err => ({ json: err, response }))
    )
    .then(({ json, response }) => {
      clearTimeout(timeoutObj);
      if (response.ok) {
        return {response, json};
      } else if (response.status === 401) {
        return reject(new UserException('Not logged in.', { status: 401 }));
      } else if (response.status === 403) {
        return reject(new UserException('You\'re not authorized to perform this action.',
          { status: 403 }));
      } else {
        return reject(json);
      }
    })
    .then(({ json, response }) => {
      if (json.Envelope && json.Envelope.Header.Body.PaymentProcessingResponse) {
        const res = json.Envelope.Header.Body.PaymentProcessingResponse;
        if (res.statusCode === '1') {
          return resolve(json);
        } else {
          return reject(new UserException(res.responseDesc, res));
        }
      } else if (json.PaymentProcessingResponse) {
        let res = json.PaymentProcessingResponse;
        if (res.statusCode === '1') {
          return resolve(json);
        } else {
          return reject(new UserException(res.responseDesc));
        }
      } else if (json.RefundResponse || json.VoidResponse) {
        return resolve(json);
      } else if (response.url.indexOf('reports') !== -1) {
        return resolve(response.text());
      } else {
        return resolve(json);
      }
    })
    .catch((err) => {
      return reject(err);
    });
  })
  .then((json) => {
    return json;
  })
  .catch((err) => {
    return Promise.reject(err);
  });
}

export const CALL_API = Symbol('Call API');

export default store => next => action => {
  const callAPI = action[CALL_API];

  // So the middleware doesn't get applied to every single action
  if (typeof callAPI === 'undefined') {
    return next(action);
  }

  let { endpoint, types, authenticated, body, method, headers, base, removeHeaders, timeout } = callAPI;
  const [ successType, errorType ] = types;

  return callApi(endpoint, authenticated, body, method, headers, base, removeHeaders, timeout).then(
    response =>
      next({
        payload: response,
        authenticated,
        type: successType
      }),
    error => next({
      error,
      type: errorType
    })
  );
};
