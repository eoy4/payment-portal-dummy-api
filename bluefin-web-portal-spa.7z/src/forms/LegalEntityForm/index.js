import LegalEntityForm from './LegalEntityForm';
export default LegalEntityForm;
