import React from 'react';
import { reduxForm } from 'redux-form';

export const fields = ['legalEntityAppId', 'legalEntityAppName'];

const validate = (values) => {
  const errors = {};

  if (!values.legalEntityAppName) {
    errors.legalEntityAppName = 'Required';
  }

  return errors;
};

type Props = {
  handleSubmit: Function,
  /* resetForm: Function,*/
  submitting: boolean,
  invalid: boolean,
  fields: Object
}

export class LegalEntity extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  render () {
    const {
      fields: {
        legalEntityAppId,
        legalEntityAppName
      },
      handleSubmit,
      /* resetForm,*/
      submitting,
      invalid
    } = this.props;

    return (
      <form onSubmit={handleSubmit}>
        <input type='hidden' {...legalEntityAppId} />
        <div className='row'>
          <div className='col-xs-12'>
            <div className='form-group'>
              <label className='control-label'>Legal Entity Name</label>
              <input className='form-control' type='text' placeholder='Legal Entity Name' {...legalEntityAppName} />
            </div>
          </div>
        </div>
        <div className='form-group'>
          <div className='row'>
            <div className='col-xs-12'>
              <div className='form-group'>
                <button className='btn btn-primary' disabled={submitting || invalid} type='submit'>
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'LegalEntity',
  fields,
  validate
})(LegalEntity);
