import React from 'react';
import { reduxForm } from 'redux-form';

export const fields = ['username', 'password'];

const validate = (values) => {
  const errors = {};
  if (!values.username) {
    errors.username = 'Required';
  }
  if (!values.password) {
    errors.password = 'Required';
  }
  return errors;
};

type Props = {
  handleSubmit: Function,
  fields: Object,
  submitting: boolean,
  invalid: boolean
}
export class Login extends React.Component {
  props: Props;

  defaultProps = {
  }

  render () {
    const { fields: { username, password }, handleSubmit, submitting, invalid } = this.props;

    return (
      <form className='form-signin form-horizontal' onSubmit={handleSubmit} noValidate>
        <div className='form-group'>
          <input type='text' id='inputEmail' className='form-control'
            placeholder='Username' {...username} autoFocus />
        </div>
        <div className='form-group'>
          <input type='password' id='inputPassword' className='form-control'
            placeholder='Password' {...password} />
        </div>
        <div className='form-group'>
          <button className='btn btn-lg btn-primary btn-block btn-signin'
            disabled={submitting || invalid} type='submit'>Sign in</button>
        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'Login',
  fields,
  validate
})(Login);
