import React from 'react';
import { reduxForm } from 'redux-form';
import { default as CreditCard } from 'credit-card';
import { CreditCardInput } from '../../components/CreditCard/CreditCard';
import { ExpirationDateInput } from '../../components/ExpirationDate/ExpirationDate';
import { PrefixedNumeralInput } from '../../components/PrefixedNumeral/PrefixedNumeral';
import { PostalCodeInput } from '../../components/PostalCode/PostalCode';
import { NumeralInput } from '../../components/Numeral/Numeral';
import { RegexValidatedInput } from '../../components/RegexValidatedInput/RegexValidatedInput';
import { default as moment } from 'moment';

export const fields = ['firstName', 'lastName', 'email', 'emailConfirmation', 'legalEntityApp',
  'merchantId', 'address', 'city', 'state', 'country', 'postalCode', 'origin', 'accountNumber',
  'card', 'expirationDate', 'amount', 'currency', 'cvv', 'invoiceNumber', 'accountPeriod', 'desk',
  'processUser'];

function isValidEXpirationDate (value) {
  try {
    if (value.length === 5) {
      let currentDate = moment();
      let expirationDate = moment(value, 'MM/YY');

      return currentDate.diff(expirationDate, 'months') <= 0;
    } else {
      return false;
    }
  } catch (e) {
    return false;
  }
}

const validate = (values) => {
  const errors = {};

  if (values.email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = 'Invalid';
  }
  if (values.emailConfirmation && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.emailConfirmation)) {
    errors.emailConfirmation = 'Invalid';
  }
  if (values.email && values.emailConfirmation && values.email !== values.emailConfirmation) {
    errors.emailConfirmation = 'Emails must match';
  }
  if (!values.card) {
    errors.card = 'Required';
  }
  if (values.card && !CreditCard.luhn(values.card.replace(/ /g, ''))) {
    errors.card = 'Invalid';
  }
  // if (!values.firstName) {
  //   errors.firstName = 'Required';
  // }
  // if (!values.lastName) {
  //   errors.lastName = 'Required';
  // }
  if (!values.accountNumber) {
    errors.accountNumber = 'Required';
  }
  if (!values.legalEntityApp) {
    errors.legalEntityApp = 'Required';
  }
  if (!values.expirationDate) {
    errors.expirationDate = 'Required';
  }
  if (!isValidEXpirationDate(values.expirationDate)) {
    errors.expirationDate = 'Invalid';
  }
  if (!values.amount || values.amount === '$') {
    errors.amount = 'Required';
  }

  return errors;
};

type Props = {
  handleSubmit: Function,
  customSubmitHandler: Function,
  /* resetForm: Function,*/
  submitting: boolean,
  invalid: boolean,
  fields: Object,
  availableLegalEntities: Array,
  getLocation: Function,
  cleanLocation: Function,
  locationInfo: Object,
  changeFieldValue: Function
}

export class SaleTransaction extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  constructor (props) {
    super(props);

    this.handleLocation = this.handleLocation.bind(this);
    this.preventEvent = this.preventEvent.bind(this);
    this.submit = this.submit.bind(this);
  }

  submit (values) {
    if (!this.props.invalid) {
      this.props.customSubmitHandler(values);
    }
  }

  handleLocation (postalCode) {
    this.props.getLocation('us', postalCode).then((payload) => {
      const { state, city } = this.props.fields;
      if (payload.error) {
        city.onChange('');
        state.onChange('');
        this.props.cleanLocation();
      } else {
        city.onChange(this.props.locationInfo.city);
        state.onChange(this.props.locationInfo.state);
      }
    });
  }

  componentWillReceiveProps (props) {
    const { state, city } = props.fields;
    const infoAvailable = !!Object.keys(props.locationInfo).length;

    state.disabled = infoAvailable;
    city.disabled = infoAvailable;
  }

  preventEvent (e) {
    e.preventDefault();
  }

  render () {
    const {
      fields: {
        firstName, lastName, email, emailConfirmation, address, city, state, country, postalCode,
        accountNumber, legalEntityApp, merchantId, origin, card, expirationDate, amount, currency,
        cvv, accountPeriod, desk
      },
      handleSubmit,
      /* resetForm,*/
      submitting
    } = this.props;

    const latitudeDeskInput =
      <div className='col-md-3'>
        <div className='form-group'>
          <label className='control-label'>Latitude Desk</label>
          <RegexValidatedInput className='form-control' type='text' placeholder='Latitude Desk'
            {...desk} regex={/\w[\w|\s|\.|'|\-]*/g} maxLength={60} />
        </div>
      </div>;
    const accountingPeriod =
      <div className='col-md-3'>
        <div className='form-group'>
          <label className='control-label'>Accounting&nbsp;Period</label>
          <RegexValidatedInput className='form-control' type='text' placeholder='Accounting Period'
            {...accountPeriod} regex={/\w[\w|\s|\.|'|\-]*/g} maxLength={60} />
        </div>
      </div>;

    return (
      <div className='tab-content'>
        <div className='tab-pane active'>
          <form onSubmit={handleSubmit(this.submit)}>

            <h2 className='sub-header'><i className='glyphicon glyphicon-transfer'></i> Transaction Information</h2>

            <input type='hidden' {...merchantId} id='merchant-id-hidden-input' />

            <div className='form-group'>
              <div className='row'>
                <div className='col-lg-3 col-md-4 selectContainer'>
                  <div className='form-group'>
                    <label className='control-label'>Legal Entity*</label>
                    {
                      legalEntityApp.touched && legalEntityApp.error &&
                        <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                          id='legal-entity-error-span'>
                          {legalEntityApp.error}
                        </span>
                    }
                    <select className='form-control' {...legalEntityApp} id='legal-entity-select'>
                      <option value=''>Choose an option</option>
                      {
                        this.props.availableLegalEntities.map(({legalEntityAppName, legalEntityAppId}) => {
                          return <option key={legalEntityAppName} value={legalEntityAppName}>
                            {legalEntityAppName}
                          </option>;
                        })
                      }
                    </select>
                  </div>
                </div>
                <div>
                  <input type='hidden' className='form-control' {...origin} id='origin-hidden-input' />
                </div>
              </div>
              <div className='row'>
                <div className='col-lg-3 col-md-4'>
                  <div className='form-group'>
                    <label className='control-label'>Account Number*</label>
                    {
                      accountNumber.touched && accountNumber.error &&
                        <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                          id='account-number-error-span'>
                          {accountNumber.error}
                        </span>
                    }
                    <RegexValidatedInput type='text' maxLength='64'
                      className='form-control' placeholder='Account Number' {...accountNumber}
                      regex={/\w[\w|\s|\.|'|\-]*/g} id='account-number-input' />
                  </div>
                </div>
              </div>
              <div className='row'>
                {(this.props.fields.legalEntityApp.value === 'MCM-LATITUDE') ? latitudeDeskInput : null}
                {(this.props.fields.legalEntityApp.value === 'MCM-LATITUDE') ? accountingPeriod : null}
              </div>
            </div>

            <h2 className='sub-header'><i className='fa fa-home'></i> Billing Address</h2>

            <div className='form-group'>
              <div className='row'>
                <div className='col-md-6'>
                  <div className='form-group'>
                    <label className='control-label'>First Name</label>
                    {firstName.touched && firstName.error &&
                      <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                        id='first-name-error-span'>{firstName.error}</span>}
                    <RegexValidatedInput className='form-control' type='text' placeholder='First Name' {...firstName}
                      regex={/\w[\w|\s|\.|'|\-]*/g} id='first-name-input' />
                  </div>
                </div>
                <div className='col-md-6'>
                  <div className='form-group'>
                    <label className='control-label'>Last Name</label>
                    {lastName.touched && lastName.error &&
                      <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                        id='last-name-error-span'>{lastName.error}</span>}
                    <RegexValidatedInput className='form-control' type='text' placeholder='Last Name' {...lastName}
                      regex={/\w[\w|\s|\.|'|\-]*/g} id='last-name-input' />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-md-6'>
                  <div className='form-group'>
                    <label className='control-label'>Email</label>
                    {email.touched && email.error &&
                      <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                        id='email-error-span'>{email.error}</span>}
                    <input className='form-control' type='email' placeholder='Email' {...email} id='email-input' />
                  </div>
                </div>
                <div className='col-md-6'>
                  <div className='form-group'>
                    <label className='control-label'>Re-enter Email</label>
                    {emailConfirmation.touched && emailConfirmation.error &&
                      <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                        id='email-confirmation-error-span'>
                        {emailConfirmation.error}</span>}
                    <input className='form-control' type='email' placeholder='Re-enter Email'
                      onPaste={this.preventEvent} onCopy={this.preventEvent} {...emailConfirmation}
                      id='email-confirmation-input' />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-md-12'>
                  <div className='form-group'>
                    <label className='control-label'>Address</label>
                    <input className='form-control' type='test' placeholder='Address' {...address} id='address-input' />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-md-3'>
                  <div className='form-group'>
                    <label className='control-label'>City</label>
                    <input className='form-control' type='text' placeholder='City' {...city} id='city-input' />
                  </div>
                </div>
                <div className='col-md-3 selectContainer'>
                  <div className='form-group'>
                    <label className='control-label'>State/Province</label>
                    <input className='form-control' type='text' placeholder='State/Province' {...state}
                      id='state-input' />
                  </div>
                </div>
                <div className='col-md-3'>
                  <div className='form-group'>
                    <label className='control-label'>ZIP/Postal Code</label>
                    <PostalCodeInput handleLocation={this.handleLocation} {...postalCode} id='zip-input' />
                  </div>
                </div>
                <div className='col-md-3 selectContainer'>
                  <div className='form-group'>
                    <label className='control-label'>Country</label>
                    <select className='form-control' disabled {...country} id='country-select'>
                      <option value=''>Choose an option</option>
                      <option value='US'>United States</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <h2 className='sub-header'>
              <i className='glyphicon glyphicon-credit-card'></i> Credit/Debit Card Information
            </h2>

            <div className='form-group'>
              <div className='row'>
                <div className='col-md-5'>
                  <div className='form-group'>
                    <label className='control-label'>Card Number*</label>
                    {card.touched && card.error &&
                      <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                        id='card-number-error-span'>{card.error}</span>}
                    <CreditCardInput {...card} onPaste={this.preventEvent} onCopy={this.preventEvent}
                      id='card-number-input' />
                  </div>
                </div>
                <div className='col-md-4'>
                  <div className='form-group'>
                    <div style={{paddingLeft: 0, whiteSpace: 'nowrap'}}>
                      <label className='control-label'>Expiration Date*</label>
                      {expirationDate.touched && expirationDate.error &&
                        <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                          id='expiration-date-error-span'>
                          {expirationDate.error}</span>}
                    </div>
                    <div style={{paddingLeft: 0}}>
                      <ExpirationDateInput {...expirationDate}
                        onPaste={this.preventEvent}
                        onCopy={this.preventEvent} id='expiration-date-input' />
                    </div>
                  </div>
                </div>
                <div className='col-md-3'>
                  <div className='form-group'>
                    <label className='control-label'>CVV2</label>
                    <NumeralInput className='form-control' placeholder='CVV2' maxLength={3}
                      onPaste={this.preventEvent} onCopy={this.preventEvent} {...cvv} id='cvv2-input' />
                  </div>
                </div>
                <div>
                  <input type='hidden' className='form-control' {...currency} />
                </div>
              </div>
              <div className='row'>
                <div className='col-md-3'>
                  <div className='form-group'>
                    <label className='control-label'>Amount*</label>
                    {amount.touched && amount.error &&
                      <span style={{ 'marginLeft': '10px' }} className='label label-danger'
                        id='amount-error-span'>{amount.error}</span>}
                    <PrefixedNumeralInput placeholder='Amount' prefix='$'
                      onPaste={this.preventEvent} onCopy={this.preventEvent} {...amount} id='amount-input' />
                  </div>
                </div>
              </div>
              <div className='row'>
                <div className='col-md-3'>
                  <div className='form-group'>
                    <button className='btn btn-primary' disabled={submitting} type='submit' id='submit-sale-button'>
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default reduxForm({
  form: 'SaleTransaction',
  fields,
  validate
})(SaleTransaction);
