import SaleTransactionForm from './SaleTransactionForm';
export default SaleTransactionForm;
