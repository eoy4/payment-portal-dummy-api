import React from 'react';
import { reduxForm } from 'redux-form';
import { PrefixedNumeralInput } from '../../components/PrefixedNumeral/PrefixedNumeral';
import { DatePickerInput } from '../../components/DatePicker/DatePicker';
import { RegexValidatedInput } from '../../components/RegexValidatedInput/RegexValidatedInput';
import { default as ReactSelect } from 'react-select';
import { jqueryAccordions } from '../../utils/utils';
import TimeZoneSelect from 'components/TimeZoneSelect/TimeZoneSelect';

export const fields = ['applicationTransactionId', 'accountNumber', 'maxamount', 'minamount',
'firstName', 'lastName', 'maxtransactionDateTime', 'mintransactionDateTime', 'legalEntity', 'merchantId',
'transactionType', 'cardType', 'internalStatusCode', 'processorName', 'invoiceNumber', 'accountPeriod', 'desk',
'batchUploadId', 'processUser', 'application', 'paymentFrequency', 'reconciliationStatusId', 'remittanceCreationDate',
'timeZone'];

const validate = (values) => {
  const errors = {};
  return errors;
};

type Props = {
  handleSubmit: Function,
  customSubmitHandler: Function,
  processing: boolean,
  /* resetForm: Function,*/
  submitting: boolean,
  invalid: boolean,
  reportsEnabled: boolean,
  reportsTooLarge: boolean,
  fields: Object,
  values: Object,
  type: string,
  availableLegalEntities: Array,
  processorNames: Array,
  transactionTypes: Array,
  internalStatusCodes: Array,
  applications: Array,
  paymentFrequencies: Array,
  getSpecificStatusCodes: Function,
  reconciliationStatus: Array,
  timeZone: String
}

export class GlobalSearch extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  constructor () {
    super();

    this.submitSearch = this.submit.bind(this, false);
    this.submitReport = this.submit.bind(this, true);
    this.onTransactionTypeChange = this.onTransactionTypeChange.bind(this);
  }

  componentDidMount () {
    jqueryAccordions({singleOpen: false});
  }

  onTransactionTypeChange (event) {
    const value = (event.target.value === '') ? 'ALL' : event.target.value;
    this.props.getSpecificStatusCodes(value);
    this.props.fields.transactionType.onChange(event.target.value);
  }

  submit (isReport, values, dispatch) {
    this.props.customSubmitHandler(values, isReport);
  }

  onTzBlur (e) {
    e.preventDefault();
  }

  render () {
    const {
      fields: {
        applicationTransactionId, accountNumber, maxamount, minamount, firstName, lastName, maxtransactionDateTime,
        mintransactionDateTime, legalEntity, merchantId, transactionType, cardType, internalStatusCode, processorName,
        invoiceNumber, accountPeriod, desk, batchUploadId, processUser, application, paymentFrequency,
        reconciliationStatusId, remittanceCreationDate, timeZone
      },
      availableLegalEntities,
      handleSubmit,
      /* resetForm,
      submitting,
      filterObject,*/
      type
    } = this.props;

    let searchForm = null;

    // Get all the unique payment frequencies
    const uniquePaymentFrequencies = [];
    this.props.paymentFrequencies &&
    this.props.paymentFrequencies.forEach((freq, index) => {
      if (!uniquePaymentFrequencies.includes(freq.paymentFrequency)) {
        uniquePaymentFrequencies.push(freq.paymentFrequency);
      }
    });

    // Get all the available legal entities
    // const leOptions = [];
    // this.props.availableLegalEntities &&
    // this.props.availableLegalEntities.forEach((le) => {
    //   leOptions.push({
    //     value: le.legalEntityAppId,
    //     label: le.legalEntityAppName
    //   });
    // });
    const leOptions = availableLegalEntities && availableLegalEntities.reduce((prev, curr) => {
      return prev.concat({
        value: curr.legalEntityAppName,
        label: curr.legalEntityAppName
      });
    }, []);

    // Get all the distinct Merchant IDs, according on Payment Processor selected
    const selectedProcessor = this.props.values.processorName;
    const uniqueMIds = this.props.processorNames &&
    this.props.processorNames.reduce((prev, curr) => {
      if (selectedProcessor && (curr.processorName !== selectedProcessor)) {
        return prev;
      }
      const newArr = [];
      curr.paymentProcessorMerchants.forEach((mId) => {
        if (!newArr.includes(mId.merchantId) && !prev.includes(mId.merchantId)) {
          newArr.push(mId.merchantId);
        }
      });
      return prev.concat(newArr);
    }, []);
    const mIdOptions = uniqueMIds && uniqueMIds.reduce((prev, curr) => {
      return prev.concat({
        value: curr,
        label: curr
      });
    }, []);

    switch (type) {
      case 'advanced':
        searchForm = <div className='global-search-form accordion-container'>
          <div className='form-group'>
            <div className='row'>
              <a href='#' className='section-toggle expanded'
                id='general-transaction-info-a'>General Transaction Info</a>
              <div style={{display: 'block'}}>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Transaction ID</label>
                    <RegexValidatedInput className='form-control' type='text' placeholder='Transaction ID'
                      {...applicationTransactionId} regex={/\w[\w|\s|\.|'|\-]*/g} id='transaction-id-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Legal Entity</label>
                    <ReactSelect
                      multi
                      options={leOptions}
                      {...legalEntity}
                      onBlur={this.onBlur}
                    />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Transaction Type</label>
                    <select className='form-control' {...transactionType} onChange={this.onTransactionTypeChange}
                      id='transaction-type-select'>
                      <option value=''>Choose an option</option>
                      {
                        this.props.transactionTypes.map(({transactionTypeName, transactionTypeId}) => {
                          return <option key={transactionTypeId}
                            value={transactionTypeName}>{transactionTypeName}</option>;
                        })
                      }
                    </select>
                  </div>
                </div>
                <br style={{clear: 'both'}} className='visible-lg-block' />
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Transaction Status Code</label>
                    <select className='form-control' {...internalStatusCode} id='transaction-status-code-select'>
                      <option value=''>Choose an option</option>
                      {
                        this.props.internalStatusCodes.map(
                          ({internalStatusCodeDescription, internalStatusCode}, index) => {
                            return <option key={internalStatusCodeDescription}
                              value={`${index}$$${internalStatusCode}`}>{internalStatusCodeDescription}</option>;
                          }
                        )
                      }
                    </select>
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Payment Frequency</label>
                    <select className='form-control' {...paymentFrequency} id='payment-frecuency-select'>
                      <option value=''>Choose an option</option>
                      {
                        uniquePaymentFrequencies.map((freq, index) => {
                          return <option key={index} value={freq}>{freq}</option>;
                        })
                      }
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className='row'>
              <a href='#' className='section-toggle' id='transaction-details-a'>Transaction Details</a>
              <div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Latitude Desk</label>
                    <RegexValidatedInput className='form-control' type='text' placeholder='Latitude Desk'
                      {...desk} regex={/\w[\w|\s|\.|'|\-]*/g} maxLength={60} id='latitude-desk-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Accounting Period</label>
                    <RegexValidatedInput className='form-control' type='text' placeholder='Accounting Period'
                      {...accountPeriod} regex={/\w[\w|\s|\.|'|\-]*/g} maxLength={60} id='accounting-period-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Invoice Number</label>
                    <RegexValidatedInput className='form-control' type='text' placeholder='Invoice Number'
                      {...invoiceNumber} regex={/\w[\w|\s|\.|'|\-]*/g} maxLength={60} id='invoice-number-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>User</label>
                    <RegexValidatedInput className='form-control' type='text' placeholder='User'
                      {...processUser} regex={/\w[\w|\s|\.|'|\-]*/g} maxLength={60} id='user-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Application</label>
                    <select className='form-control' {...application} id='application-select'>
                      <option value=''>Choose an option</option>
                      {
                        this.props.applications.map((app, index) => {
                          return <option key={index} value={app.applicationName}>{app.applicationName}</option>;
                        })
                      }
                    </select>
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Latitude Batch Upload ID</label>
                    <RegexValidatedInput type='text' maxLength='64'
                      className='form-control' placeholder='Latitude Batch Upload ID' {...batchUploadId}
                      regex={/\w[\w|\s|\.|'|\-]*/g} id='latitude-batch-upload-id-input' />
                  </div>
                </div>
              </div>
            </div>
            <div className='row'>
              <a href='#' className='section-toggle' a='account-details-a'>Account Details</a>
              <div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Account Number</label>
                    <RegexValidatedInput type='text' maxLength='64'
                      className='form-control' placeholder='Account Number' {...accountNumber}
                      regex={/\w[\w|\s|\.|'|\-]*/g} id='account-number-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Customer</label>
                    <div className='row'>
                      <div className='col-xs-6'>
                        <RegexValidatedInput className='form-control' type='text' placeholder='First Name'
                          {...firstName} regex={/\w[\w|\s|\.|'|\-]*/g} id='customer-first-name-input' />
                      </div>
                      <div className='col-xs-6'>
                        <RegexValidatedInput className='form-control' type='text' placeholder='Last Name'
                          {...lastName} regex={/\w[\w|\s|\.|'|\-]*/g} id='customer-last-name-input' />
                      </div>
                    </div>
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Card Type</label>
                    <select className='form-control' {...cardType} id='card-type-select'>
                      <option value=''>Choose an option</option>
                      <option value='DEBIT'>Debit</option>
                      <option value='CREDIT'>Credit</option>
                    </select>
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Processor Name</label>
                    <select className='form-control' {...processorName} id='processor-name-select'>
                      <option value=''>Choose an option</option>
                      {
                        this.props.processorNames.map(({processorName, paymentProcessorId}) => {
                          return <option key={paymentProcessorId} value={processorName}>{processorName}</option>;
                        })
                      }
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className='row'>
              <a href='#' className='section-toggle' id='amount-date-a'>Amount & Date</a>
              <div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Time Zone</label>
                    <TimeZoneSelect {...timeZone} onBlur={this.onTzBlur} id='time-zone' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Start Date</label>
                    <DatePickerInput {...mintransactionDateTime} id='start-date' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>End Date</label>
                    <DatePickerInput {...maxtransactionDateTime} id='end-date' />
                  </div>
                </div>
                <br style={{clear: 'both'}} className='visible-lg-block' />
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Min Amount</label>
                    <PrefixedNumeralInput placeholder='Min Amount' prefix='$' {...minamount} id='min-amount-input' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Max Amount</label>
                    <PrefixedNumeralInput placeholder='Max Amount' prefix='$' {...maxamount} id='max-amount-input' />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='form-group'>
              <button className='btn btn-primary' style={{margin: '0 15px 10px 0'}}
                onClick={this.props.handleSubmit(this.submitSearch)} id='submit-search-button'>
                <i className='glyphicon glyphicon-search'></i></button>
              {
                this.props.reportsEnabled
                  ? <button className='btn btn-primary transactions-report-button'
                    disabled={this.props.processing || this.props.reportsTooLarge}
                    onClick={this.props.handleSubmit(this.submitReport)}
                    style={{margin: '0 0 10px 0'}}
                    id='transactions-report-button'>
                      {(this.props.processing)
                        ? 'Processing'
                        : <span>
                          <i className='glyphicon glyphicon-circle-arrow-down'></i> Download as CSV file
                        </span>}
                  </button>
                  : null
              }
              {
                this.props.reportsTooLarge
                ? <span className='reports-warning'>
                  <i className='glyphicon glyphicon-warning-sign'></i>
                  &nbsp;
                  <span id='download-error-span'>Download is only available for
                  30,000 transactions or less.  Please refine your search criteria.</span>
                </span>
                : null
              }
            </div>
          </div>
        </div>;
        break;

      case 'remittance':

        searchForm = <div className='global-search-form accordion-container'>
          <div className='form-group'>
            <div className='row'>
              <a href='#' className='section-toggle expanded' id='reconciliation-a'>Reconciliation</a>
              <div style={{display: 'block'}}>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Time Zone</label>
                    <TimeZoneSelect {...timeZone} onBlur={this.onTzBlur} id='remittance-time-zone' />
                  </div>
                </div>
                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group date-picker-no-clock'>
                    <label className='control-label'>Remittance File Date</label>
                    <DatePickerInput dateFormat='YYYY-MM-DD' {...remittanceCreationDate} />
                  </div>
                </div>

                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Processor Name</label>
                    <select className='form-control'
                      {...processorName}
                      onChange={function (value) {
                        processorName.onChange(value);
                        merchantId.onChange('');
                      }}
                      id='processor-name-select'
                    >
                      <option value=''>Choose an option</option>
                      {
                        this.props.processorNames &&
                        this.props.processorNames.map(({processorName, paymentProcessorId}) => {
                          return <option key={paymentProcessorId} value={processorName}>{processorName}</option>;
                        })
                      }
                    </select>
                  </div>
                </div>

                <br style={{clear: 'both'}} className='visible-lg-block' />

                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Merchant ID</label>
                    <ReactSelect
                      multi
                      options={mIdOptions}
                      {...merchantId}
                      onBlur={this.onBlur}
                    />
                  </div>
                </div>

                <div className='col-sm-6 col-lg-4'>
                  <div className='form-group'>
                    <label className='control-label'>Reconciliation Status</label>
                    <select className='form-control' {...reconciliationStatusId} id='reconciliation-status-select'>
                      <option value=''>All</option>
                      <option value='notReconciled'>Not Reconciled</option>
                      {
                        this.props.reconciliationStatus.map(
                          ({reconciliationStatusId, reconciliationStatus, description}) => {
                            return <option key={reconciliationStatusId} value={reconciliationStatusId}>
                              {reconciliationStatus}
                            </option>;
                          }
                        )
                      }
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className='row'>
            <div className='form-group'>
              <button className='btn btn-primary' style={{margin: '0 15px 10px 0'}}
                onClick={this.props.handleSubmit(this.submitSearch)} id='submit-remittance-search'>
                <i className='glyphicon glyphicon-search'></i></button>
              {
                this.props.reportsEnabled &&
                  <button className='btn btn-primary'
                    disabled={this.props.processing}
                    onClick={this.props.handleSubmit(this.submitReport)}
                    style={{margin: '0 0 10px 0'}}
                    id='download-remittance-csv-button'>
                      {(this.props.processing)
                        ? 'Processing'
                        : <span>
                          <i className='glyphicon glyphicon-circle-arrow-down'></i> Download as CSV file
                        </span>}
                  </button>
              }
            </div>
          </div>
        </div>;
        break;

      default:
        searchForm = <div className='form-group'>
          <div className='row'>
            <div className='col-lg-3 col-sm-6 col-lg-4 col-sm-10'>
              <div className='form-group'>
                <label className='control-label'>Transaction ID*</label>
                <RegexValidatedInput className='form-control' type='text' placeholder='Transaction ID'
                  {...applicationTransactionId} regex={/\w[\w|\s|\.|'|\-]*/g} id='transaction-id-input' />
              </div>
            </div>
            <div className='col-md-3 col-sm-2'>
              <div className='form-group'>
                <button className='btn btn-primary'
                  disabled={!this.props.fields.applicationTransactionId.value}
                  style={{'marginTop': '24px'}} onClick={this.props.handleSubmit(this.submitSearch)}
                  id='submit-button'>
                  <i className='glyphicon glyphicon-search'></i>
                </button>
              </div>
            </div>
          </div>
        </div>;
        break;
    }

    return (
      <form onSubmit={handleSubmit(this.submit)}>
        {searchForm}
      </form>
    );
  }
}

export default reduxForm({
  form: 'GlobalSearch',
  fields,
  validate
})(GlobalSearch);
