import GlobalSearchForm from './GlobalSearchForm';
export default GlobalSearchForm;
