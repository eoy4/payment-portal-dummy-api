import ConfigurationRulesForm from './ConfigurationRulesForm';
export default ConfigurationRulesForm;
