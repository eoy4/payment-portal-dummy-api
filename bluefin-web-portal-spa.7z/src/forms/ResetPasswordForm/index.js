import ResetPasswordForm from './ResetPasswordForm';
export default ResetPasswordForm;
