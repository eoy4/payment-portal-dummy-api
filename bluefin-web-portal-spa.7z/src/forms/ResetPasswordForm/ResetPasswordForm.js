import React from 'react';
import { reduxForm } from 'redux-form';

export const fields = ['username'];

const validate = (values) => {
  const errors = {};
  if (!values.username) {
    errors.username = 'Required';
  }
  return errors;
};

type Props = {
  handleSubmit: Function,
  fields: Object,
  submitting: boolean,
  invalid: boolean
}
export class ResetPassword extends React.Component {
  props: Props;

  defaultProps = {
  }

  render () {
    const { fields: { username }, handleSubmit, submitting, invalid } = this.props;

    return (
      <form className='form-signin form-horizontal' onSubmit={handleSubmit} noValidate>
        <div className='form-group'>
          {username.touched && username.error &&
            <span style={{'marginLeft': '10px'}} className='label label-danger'>{username.error}</span>}
          <input type='username' id='inputUsername' ref='inputUsername' className='form-control'
            placeholder='Username' {...username} />
        </div>
        <div className='form-group'>
          <button className='btn btn-lg btn-primary btn-block btn-signin'
            disabled={submitting || invalid} type='submit'>Request password reset</button>
        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'ResetPassword',
  fields,
  validate
})(ResetPassword);
