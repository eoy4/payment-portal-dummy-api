import React from 'react';
import { reduxForm } from 'redux-form';

export const fields = [
  'paymentProcessorId',
  'selectedMerchants[].legalEntityAppId',
  'selectedMerchants[].merchantId',
  'selectedMerchants[].testOrProd'
];

const validate = (values) => {
  const errors = {};

  if (!values.paymentProcessorId) {
    // errors.paymentProcessorId = 'Required';
  }

  return errors;
};

type Props = {
  handleSubmit: Function,
  handleProcessorChange: Function,
  /* resetForm: Function,*/
  submitting: boolean,
  invalid: boolean,
  fields: Object,
  paymentProcessors: Array,
  selectedProcessorId: Number,
  legalEntities: Array
}

export class ProcessorToMerchantsForm extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  constructor (props) {
    super(props);

    this.selectedProcessorId = 0;
  }

  componentDidMount () {
    this.processors = this.parseProcessors();
    this.legalEntities = this.parseLegalEntities();
    this.updateMerchantFields();
  }

  componentWillUpdate () {
    const { selectedProcessorId } = this.props;

    if (selectedProcessorId !== this.selectedProcessorId) {
      this.selectedProcessorId = selectedProcessorId;
      this.updateMerchantFields();
    }
  }

  updateMerchantFields () {
    const { legalEntities } = this.props;

    const {
      fields: {
        selectedMerchants
      }
    } = this.props;

    legalEntities &&
    legalEntities.forEach((entity, index) => {
      if (selectedMerchants) {
        selectedMerchants.removeField(index);
        selectedMerchants.addField(this.getMerchantField(entity), index);
      }
    });
  }

  getMerchantField (entity) {
    const { selectedProcessorId } = this.props;
    let merchantId = '';
    let testOrProd = 0;

    this.processors[selectedProcessorId] &&
    this.processors[selectedProcessorId].paymentProcessorMerchants.forEach((merchant, index) => {
      if (merchant.legalEntityAppId === entity.legalEntityAppId) {
        merchantId = merchant.merchantId || '';
        testOrProd = merchant.testOrProd;
      }
    });
    return {
      legalEntityAppId: entity.legalEntityAppId,
      merchantId,
      testOrProd
    };
  }

  parseProcessors () {
    const { paymentProcessors } = this.props;
    let parsedProcessors = {};
    paymentProcessors.forEach((processor) => {
      parsedProcessors[processor.paymentProcessorId] = processor;
    });
    return parsedProcessors;
  }

  parseLegalEntities () {
    const { legalEntities } = this.props;
    let parsedLegalEntities = {};
    legalEntities.forEach((le) => {
      parsedLegalEntities[le.legalEntityAppId] = le;
    });
    return parsedLegalEntities;
  }

  render () {
    const {
      fields: {
        paymentProcessorId,
        selectedMerchants
      },
      handleSubmit,
      handleProcessorChange,
      selectedProcessorId,
      paymentProcessors,
      /* resetForm,*/
      submitting,
      invalid
    } = this.props;

    return (
      <form onSubmit={handleSubmit} key={this.selectedProcessorId}>
        <h2 className='sub-header'><span className='circled-number'>1</span> Select a Processor</h2>
        <div className='row'>
          <div className='col-lg-4 col-md-6 col-xs-12'>
            <div className='form-group'>
              <label className='control-label'>Payment Processor</label>
              <select {...paymentProcessorId}
                onChange={handleProcessorChange}
                className='form-control'
                id='payment-processor-select'
              >
                <option value='0'>Select one</option>
                {
                  paymentProcessors && paymentProcessors.map((processor, index) => {
                    return <option value={processor.paymentProcessorId}
                      key={index}
                    >
                      {processor.processorName}
                    </option>;
                  })
                }
              </select>
            </div>
          </div>
        </div>
        {
          (selectedProcessorId && (selectedProcessorId !== '0'))
            ? <div style={{display: ((selectedProcessorId && (selectedProcessorId !== '0')) ? 'block' : 'none')}}>
              <h2 className='sub-header'>
                <span className='circled-number'>2</span> Assign Merchant IDs to Legal Entities
              </h2>
              <div className='row'>
                <div className='col-md-6 col-xs-12'>
                  <table className='table table-bordered table-zebra'>
                    <thead>
                      <tr>
                        <th>Legal Entity</th>
                        <th>Merchant ID</th>
                      </tr>
                    </thead>
                    <tbody>
                      {
                        selectedMerchants &&
                        selectedMerchants.map((merchant, index) => {
                          return (
                            <tr key={'' + selectedProcessorId + index}>
                              <td>
                                {
                                  this.legalEntities[merchant.legalEntityAppId.value] &&
                                  this.legalEntities[merchant.legalEntityAppId.value].legalEntityAppName
                                }
                              </td>
                              <td>
                                <input type='text'
                                  className='form-control'
                                  {...merchant.merchantId }
                                />
                              </td>
                            </tr>
                          );
                        })
                      }
                    </tbody>
                  </table>
                  <div className='form-group'>
                    <button className='btn btn-primary' disabled={submitting || invalid} type='submit'
                      id='submit-button'>
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          : <div className='text-center text-grayed'><i className='glyphicon glyphicon-option-horizontal'></i></div>
        }
      </form>
    );
  }
}

export default reduxForm({
  form: 'ProcessorToMerchantsForm',
  fields,
  validate
})(ProcessorToMerchantsForm);
