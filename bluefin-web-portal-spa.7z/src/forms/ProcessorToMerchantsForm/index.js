import ProcessorToMerchantsForm from './ProcessorToMerchantsForm';
export default ProcessorToMerchantsForm;
