import React from 'react';
import { reduxForm } from 'redux-form';
import { default as ReactSelect } from 'react-select';

export const fields = [
  'selectedProcessors'
];

const validate = (values) => {
  const errors = {};

  return errors;
};

type Props = {
  fields: Object,
  paymentProcessors: Array
}

class SelectProcessorsForm extends React.Component {
  props: Props;

  defaultProps = {
    fields: {
      selectedProcessors: []
    }
  }

  onBlur (event) {
    event.preventDefault();
    event.stopPropagation();
    return false;
  }

  render () {
    const {
      fields: {
        selectedProcessors
      },
      paymentProcessors
    } = this.props;

    let options = [];

    paymentProcessors &&
    paymentProcessors.forEach((processor) => {
      options.push({
        value: processor.paymentProcessorId,
        label: processor.processorName
      });
    });

    return (
      <form className='select-processors-form'>
        <div className='form-group'>
          <ReactSelect
            multi
            options={options}
            {...selectedProcessors}
            onBlur={this.onBlur}
          />
        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'SelectProcessorsForm',
  fields,
  validate
})(SelectProcessorsForm);
