module.exports = {
  description () {
    return 'generates a redux duck';
  }
};
