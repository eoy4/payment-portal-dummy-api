import <%= pascalEntityName %>Form from './<%= pascalEntityName %>Form'
export default <%= pascalEntityName %>Form
