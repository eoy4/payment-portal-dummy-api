import React from 'react'

describe('(View) Processors', () => {
  it('should exist', () => {

  })
})
