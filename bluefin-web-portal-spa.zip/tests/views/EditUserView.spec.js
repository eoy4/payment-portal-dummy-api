import React from 'react'

describe('(View) EditUser', () => {
  it('should exist', () => {

  })
})
