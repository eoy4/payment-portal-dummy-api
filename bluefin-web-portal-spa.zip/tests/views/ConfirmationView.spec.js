import React from 'react'

describe('(View) Confirmation', () => {
  it('should exist', () => {

  })
})
