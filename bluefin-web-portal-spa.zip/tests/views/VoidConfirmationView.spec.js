import React from 'react'

describe('(View) VoidConfirmation', () => {
  it('should exist', () => {

  })
})
