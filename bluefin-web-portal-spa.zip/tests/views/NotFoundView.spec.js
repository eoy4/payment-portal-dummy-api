import React from 'react'

describe('(View) NotFound', () => {
  it('should exist', () => {

  })
})
