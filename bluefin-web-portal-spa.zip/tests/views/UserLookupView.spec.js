import React from 'react'

describe('(View) UserSearch', () => {
  it('should exist', () => {

  })
})
