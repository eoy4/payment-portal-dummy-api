describe('(Form) SaleTransaction', () => {
  it('exists', () => {

  })
})
