describe('(Form) ConfigurationRules', () => {
  it('exists', () => {

  })
})
