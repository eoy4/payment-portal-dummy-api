import reducer, { initialState } from 'redux/modules/Transaction'

describe('(Redux) Transaction', () => {
  describe('(Reducer)', () => {
    it('sets up initial state', () => {
      expect(reducer(undefined, {})).to.eql(initialState)
    })
  })
})
