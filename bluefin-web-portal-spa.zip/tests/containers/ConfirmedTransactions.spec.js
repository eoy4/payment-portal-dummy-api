describe('(Component) ConfirmedTransactions', () => {
  it('exists', () => {

  })
})
