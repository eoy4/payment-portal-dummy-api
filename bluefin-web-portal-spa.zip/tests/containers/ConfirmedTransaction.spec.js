describe('(Component) ConfirmedTransaction', () => {
  it('exists', () => {

  })
})
