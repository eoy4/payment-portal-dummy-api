describe('(Component) ProcessorRules', () => {
  it('exists', () => {

  })
})
