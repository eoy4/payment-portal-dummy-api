describe('(Component) SaleTransaction', () => {
  it('exists', () => {

  })
})
