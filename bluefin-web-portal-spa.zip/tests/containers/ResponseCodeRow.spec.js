describe('(Component) ResponseCodeRow', () => {
  it('exists', () => {

  })
})
