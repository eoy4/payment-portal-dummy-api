describe('(Component) RecurringPayments', () => {
  it('exists', () => {

  })
})
