describe('(Component) ProcessorDetails', () => {
  it('exists', () => {

  })
})
