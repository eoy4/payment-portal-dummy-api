describe('(Component) ConfigurationRules', () => {
  it('exists', () => {

  })
})
