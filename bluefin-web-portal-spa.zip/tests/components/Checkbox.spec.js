import React from 'react'
import Checkbox from 'components/Checkbox/Checkbox'

describe('(Component) Checkbox', () => {
  it('should exist', () => {

  })
})
