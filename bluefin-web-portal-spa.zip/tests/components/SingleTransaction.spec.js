import React from 'react'
import SingleTransaction from 'components/SingleTransaction/SingleTransaction'

describe('(Component) SingleTransaction', () => {
  it('should exist', () => {

  })
})
