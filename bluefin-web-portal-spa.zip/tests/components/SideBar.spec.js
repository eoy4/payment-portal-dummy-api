import React from 'react'
import SideBar from 'components/SideBar/SideBar'

describe('(Component) SideBar', () => {
  it('should exist', () => {

  })
})
