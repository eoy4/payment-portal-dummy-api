import React from 'react'
import MultipleRemittances from 'components/MultipleRemittances/MultipleRemittances'

describe('(Component) MultipleRemittances', () => {
  it('should exist', () => {

  })
})
