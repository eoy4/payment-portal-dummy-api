import React from 'react'
import ConvertibleNumeralInput from 'components/ConvertibleNumeralInput/ConvertibleNumeralInput'

describe('(Component) ConvertibleNumeralInput', () => {
  it('should exist', () => {

  })
})
