import React from 'react'
import Modal from 'components/Modal/Modal'

describe('(Component) Modal', () => {
  it('should exist', () => {

  })
})
