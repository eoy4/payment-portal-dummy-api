import React from 'react'
import ExpirationDate from 'components/ExpirationDate/ExpirationDate'

describe('(Component) ExpirationDate', () => {
  it('should exist', () => {

  })
})
