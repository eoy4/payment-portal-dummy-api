import React from 'react'
import TimezoneSelect from 'components/TimezoneSelect/TimezoneSelect'

describe('(Component) TimezoneSelect', () => {
  it('should exist', () => {

  })
})
