import React from 'react'
import CreditCard from 'components/CreditCard/CreditCard'

describe('(Component) CreditCard', () => {
  it('should exist', () => {

  })
})
