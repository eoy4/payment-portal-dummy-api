import React from 'react';
import Numeral from 'components/Numeral/Numeral';

describe('(Component) Numeral', () => {
  it('should exist', () => {

  })
})
