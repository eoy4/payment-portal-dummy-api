import React from 'react'
import UnformattedNumber from 'components/UnformattedNumber/UnformattedNumber'

describe('(Component) UnformattedNumber', () => {
  it('should exist', () => {

  })
})
