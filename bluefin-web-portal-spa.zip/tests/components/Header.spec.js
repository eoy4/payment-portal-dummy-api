import React from 'react'
import Header from 'components/Header/Header'

describe('(Component) Header', () => {
  it('should exist', () => {

  })
})
