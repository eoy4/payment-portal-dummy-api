import React from 'react'
import ResponseCodeRow from 'components/ResponseCodeRow/ResponseCodeRow'

describe('(Component) ResponseCodeRow', () => {
  it('should exist', () => {

  })
})
