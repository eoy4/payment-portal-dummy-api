import React from 'react'
import BlockingOverlay from 'components/BlockingOverlay/BlockingOverlay'

describe('(Component) BlockingOverlay', () => {
  it('should exist', () => {

  })
})
