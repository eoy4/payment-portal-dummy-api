import React from 'react'
import RegexValidatedInput from 'components/RegexValidatedInput/RegexValidatedInput'

describe('(Component) RegexValidatedInput', () => {
  it('should exist', () => {

  })
})
