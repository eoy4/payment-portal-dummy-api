import React from 'react'
import MultipleBatchFiles from 'components/MultipleBatchFiles/MultipleBatchFiles'

describe('(Component) MultipleBatchFiles', () => {
  it('should exist', () => {

  })
})
