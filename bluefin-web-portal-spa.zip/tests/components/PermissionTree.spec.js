import React from 'react'
import PermissionTree from 'components/PermissionTree/PermissionTree'

describe('(Component) PermissionTree', () => {
  it('should exist', () => {

  })
})
