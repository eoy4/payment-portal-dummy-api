import React from 'react'
import MultipleConfigurationRules from 'components/MultipleConfigurationRules/MultipleConfigurationRules'

describe('(Component) MultipleConfigurationRules', () => {
  it('should exist', () => {

  })
})
