import { combineReducers } from 'redux';
import { routerReducer as router } from 'react-router-redux';
import { reducer as form } from 'redux-form';
import { reducer as idle } from '../components/ReduxIdleMonitor';
import { default as transaction } from './modules/Transaction';
import { default as batchFile } from './modules/BatchFile';
import { default as processor } from './modules/Processor';
import { default as processorRule } from './modules/ProcessorRule';
import { default as responseCodes } from './modules/ResponseCodes';
import { default as statusCodes } from './modules/StatusCodes';
import { default as transactionType } from './modules/TransactionType';
import { default as legalEntity } from './modules/LegalEntity';
import { default as auth } from './modules/Authentication';
import { default as user } from './modules/User';
import { default as misc } from './modules/Misc';

export default combineReducers({
  router,
  idle,
  transaction,
  batchFile,
  processor,
  processorRule,
  responseCodes,
  statusCodes,
  transactionType,
  legalEntity,
  auth,
  user,
  misc,
  form
});
