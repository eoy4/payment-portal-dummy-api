import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

// Constants
export const constants = {
  GOT_TRANSACTION_TYPES: 'GOT_TRANSACTION_TYPES',
  GOT_TRANSACTION_TYPES_ERROR: 'GOT_TRANSACTION_TYPES_ERROR'
};

// Action Creators

function _getTransactionTypes () {
  return {
    [CALL_API]: {
      types: [constants.GOT_TRANSACTION_TYPES, constants.GOT_TRANSACTION_TYPES_ERROR],
      endpoint: MICROSERVICE.TRANSACTION_TYPES.CRUD,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getTransactionTypes () {
  return (dispatch) => {
    return dispatch(_getTransactionTypes());
  };
}

// Reducer
export const initialState = {
  transactionTypes: []
};
export default function (state = initialState, action) {
  switch (action.type) {
    case constants.GOT_TRANSACTION_TYPES:
      return Object.assign({}, state, {
        transactionTypes: action.payload
      });
    default:
      return state;
  }
}
