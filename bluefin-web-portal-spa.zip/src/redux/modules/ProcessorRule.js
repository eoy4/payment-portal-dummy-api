import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

// Constants
export const constants = {
  CREATE_PROCESSOR_RULE: 'CREATE_PROCESSOR_RULE',
  CREATED_PROCESSOR_RULE: 'CREATED_PROCESSOR_RULE',
  CREATE_PROCESSOR_RULE_FAILED: 'CREATE_PROCESSOR_RULE_FAILED',
  GET_PROCESSOR_RULE: 'GET_PROCESSOR_RULE',
  GOT_PROCESSOR_RULE: 'GOT_PROCESSOR_RULE',
  GOT_PROCESSOR_RULE_FAILED: 'GOT_PROCESSOR_RULE_FAILED',
  GET_PROCESSOR_RULES: 'GET_PROCESSOR_RULES',
  GOT_PROCESSOR_RULES: 'GOT_PROCESSOR_RULES',
  GOT_PROCESSOR_RULES_FAILED: 'GOT_PROCESSOR_RULES_FAILED',
  DELETE_PROCESSOR_RULE: 'DELETE_PROCESSOR_RULE',
  DELETED_PROCESSOR_RULE: 'DELETED_PROCESSOR_RULE',
  DELETED_PROCESSOR_RULE_FAILED: 'DELETED_PROCESSOR_RULE_FAILED',
  UPDATE_PROCESSOR_RULE: 'UPDATE_PROCESSOR_RULE',
  UPDATED_PROCESSOR_RULE: 'UPDATED_PROCESSOR_RULE',
  UPDATE_PROCESSOR_RULE_FAILED: 'UPDATE_PROCESSOR_RULE_FAILED',
  CLEAN_PROCESSOR_RULE: 'CLEAN_PROCESSOR_RULE'
};

// Action Creators

export function cleanProcessorRule (): Action {
  return {
    type: constants.CLEAN_PROCESSOR_RULE,
    payload: {
      cardType: 'CREDIT',
      maximumMonthlyAmount: 0,
      monthToDateCumulativeAmount: 0,
      noMaximumMonthlyAmountFlag: 0,
      paymentProcessorRuleId: '',
      priority: 0
    }
  };
}

function _createProcessorRule (processorRule) {
  return {
    [CALL_API]: {
      types: [constants.CREATED_PROCESSOR_RULE, constants.CREATE_PROCESSOR_RULE_FAILED],
      endpoint: MICROSERVICE.PROCESSOR_RULES.CRUD,
      authenticated: true,
      body: JSON.stringify(processorRule),
      method: 'POST'
    }
  };
}

export function createProcessorRule (processorRule) {
  return (dispatch) => {
    return dispatch(_createProcessorRule(processorRule));
  };
}

function _getProcessorRule (paymentProcessorRuleId) {
  return {
    [CALL_API]: {
      types: [constants.GOT_PROCESSOR_RULE, constants.GOT_PROCESSOR_RULE_FAILED],
      endpoint: MICROSERVICE.PROCESSOR_RULES.CRUD + paymentProcessorRuleId,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getProcessorRule (paymentProcessorRuleId) {
  return (dispatch) => {
    return dispatch(_getProcessorRule(paymentProcessorRuleId));
  };
}

function _getProcessorRules () {
  return {
    [CALL_API]: {
      types: [constants.GOT_PROCESSOR_RULES, constants.GOT_PROCESSOR_RULES_FAILED],
      endpoint: MICROSERVICE.PROCESSOR_RULES.CRUD,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getProcessorRules () {
  return (dispatch) => {
    return dispatch(_getProcessorRules());
  };
}

function _deleteProcessorRule (paymentProcessorRuleId) {
  return {
    [CALL_API]: {
      types: [constants.DELETED_PROCESSOR_RULE, constants.DELETED_PROCESSOR_RULE_FAILED],
      endpoint: MICROSERVICE.PROCESSOR_RULES.CRUD + paymentProcessorRuleId,
      authenticated: true,
      method: 'DELETE'
    }
  };
}

export function deleteProcessorRule (paymentProcessorRuleId) {
  return (dispatch) => {
    return dispatch(_deleteProcessorRule(paymentProcessorRuleId));
  };
}

function _updateProcessorRule (paymentProcessorRuleId, processorRule) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_PROCESSOR_RULE, constants.UPDATE_PROCESSOR_RULE_FAILED],
      endpoint: MICROSERVICE.PROCESSOR_RULES.CRUD + paymentProcessorRuleId,
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(processorRule)
    }
  };
}

export function updateProcessorRule (paymentProcessorRuleId, processorRule) {
  return (dispatch) => {
    return dispatch(_updateProcessorRule(paymentProcessorRuleId, processorRule));
  };
}

// Reducer
export const initialState = {
  currentProcessorRule: {
    cardType: 'CREDIT',
    maximumMonthlyAmount: 0,
    monthToDateCumulativeAmount: 0,
    noMaximumMonthlyAmountFlag: 0,
    paymentProcessorRuleId: '',
    priority: 0
  },
  processorRules: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.UPDATED_PROCESSOR:
      return Object.assign({}, state, {
        currentProcessorRule: action.payload
      });
    case constants.ASSIGNED_MERCHANTS:
      return Object.assign({}, state, {
        currentProcessorRule: action.payload
      });
    case constants.CREATED_PROCESSOR_RULE:
      return Object.assign({}, state, {
        currentProcessorRule: action.payload
      });
    case constants.GOT_PROCESSOR_RULE:
      return Object.assign({}, state, {
        currentProcessorRule: action.payload
      });
    case constants.GOT_PROCESSOR_RULES:
      return Object.assign({}, state, {
        processorRules: action.payload
      });
    case constants.DELETED_PROCESSOR:
      return Object.assign({});
    case constants.CLEAN_PROCESSOR:
      return Object.assign({}, state, {
        currentProcessorRule: action.payload
      });
    default:
      return state;
  }
}
