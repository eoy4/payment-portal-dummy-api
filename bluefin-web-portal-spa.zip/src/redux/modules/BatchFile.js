import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

const momenttz = require('moment-timezone');

// Constants
export const constants = {
  GET_BATCH_FILE: 'GET_BATCH_FILE',
  GET_BATCH_FILE_FAILED: 'GET_BATCH_FILE_FAILED',
  GET_BATCH_FILES: 'GET_BATCH_FILES',
  GET_BATCH_FILES_FAILED: 'GET_BATCH_FILES_FAILED',
  RECEIVED_BATCH_FILE: 'RECEIVED_BATCH_FILE',
  RECEIVED_BATCH_FILES: 'RECEIVED_BATCH_FILES',
  STORE_FILTER: 'STORE_FILTER',
  CLEAN_BATCH_FILE: 'CLEAN_BATCH_FILE',
  CLEAN_FILTERED_BATCH_FILES: 'CLEAN_FILTERED_BATCH_FILES',
  CACHE_BATCH_FILE: 'CACHE_BATCH_FILE',
  UPLOADED_FILE: 'UPLOADED_FILE',
  UPDATE_PERCENTAGE: 'UPDATE_PERCENTAGE',
  CLEAN_UPLOADED_FILE: 'CLEAN_UPLOADED_FILE',
  SET_ERROR: 'SET_ERROR',
  GOT_REPORT: 'GOT_REPORT',
  GOT_REPORT_FAILED: 'GOT_REPORT_FAILED',
  GOT_TRANSACTIONS_REPORT: 'GOT_TRANSACTIONS_REPORT',
  GOT_TRANSACTIONS_REPORT_FAILED: 'GOT_TRANSACTIONS_REPORT_FAILED',
  CLEAN_REPORT: 'CLEAN_REPORT',
  CLEAN_TRANSACTIONS_REPORT: 'CLEAN_TRANSACTIONS_REPORT'
};

export function cleanBatchFile (): Action {
  return {
    type: constants.CLEAN_FILTERED_BATCH_FILES
  };
}

export function cleanFilter (): Action {
  return {
    type: constants.CLEAN_FILTER
  };
}

export function cleanFilteredBatchFiles (): Action {
  return {
    type: constants.CLEAN_BATCH_FILE,
    payload: {
    }
  };
}

export function cacheBatchFile (value): Action {
  return {
    type: constants.CACHE_BATCH_FILE,
    payload: value
  };
}

export function storeFilter (value): Action {
  return {
    type: constants.STORE_FILTER,
    payload: value
  };
}

export function getBatchFile (id) {
  return {
    [CALL_API]: {
      types: [constants.RECEIVED_BATCH_FILE, constants.GET_BATCH_FILE_FAILED],
      endpoint: MICROSERVICE.BATCH_FILES.GET + id,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getBatchFiles ({noofdays = 0, page = 0, size = 4} = {}) {
  let query = '';
  if (noofdays) {
    query = `?noofdays=${noofdays}`;
  }
  if (!query) {
    query = `?page=${page}&size=${size}`;
  }
  return {
    [CALL_API]: {
      types: [constants.RECEIVED_BATCH_FILES, constants.GET_BATCH_FILES_FAILED],
      endpoint: MICROSERVICE.BATCH_FILES.SEARCH + query,
      authenticated: true,
      method: 'GET'
    }
  };
}

/* export function uploadBatchFile2 (files) {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };

  const formData = new FormData();
  formData.append('batch_file', files);
  let config = {
    method: 'post',
    mode: 'cors',
    headers: {
      'X-Auth-Token': token
    },
    'body': formData
  };

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.BATCH_FILES.POST, config)
      .then(response =>
        response.text().then((file) => ({file, response}))
      )
      .then(({file, response}) => {
        if (response.ok) {
          dispatch(uploadedFile(response));
        } else {
          return Promise.reject({});
        }
      })
      .catch(err => {
        return Promise.reject(err);
      });
  };
}

function uploadedFile (value) {
  return {
    type: constants.UPLOADED_FILE,
    payload: value
  };
} */

function updatePercentage (percentage) {
  return {
    type: constants.UPDATE_PERCENTAGE,
    payload: percentage
  };
}

export function uploadBatchFile (files) {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };

  const formData = new FormData();
  formData.append('batch_file', files);

  return dispatch => {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      // xhr.addEventListener('progress', (e) => {
      //   const done = e.position || e.loaded;
      //   const total = e.totalSize || e.total;
      //   const percent = total ? (Math.floor(done/total*1000)/10) : -1;
      //   dispatch(updatePercentage(percent));
      //   console.log('xhr progress: ' + percent + '%');
      // }, false);
      if (xhr.upload) {
        xhr.upload.onprogress = (e) => {
          const done = e.position || e.loaded;
          const total = e.totalSize || e.total;
          const percent = total ? (Math.floor(done / total * 1000) / 10) : -1;
          dispatch(updatePercentage(percent));
          // console.log('upload progress: ' + percent + '%');
          if (percent === 100) {
            return resolve('Success');
          }
        };
      }
      xhr.onreadystatechange = (e) => {
        if (xhr.readyState === 4) {
          // console.log('File finished processing.');
          if (xhr.status !== 201) {
            try {
              const error = JSON.parse(xhr.response);
              dispatch(setError(error.message));
            } catch (e) {
              dispatch(setError(e));
            }
          }
        }
      };
      xhr.open('post', MICROSERVICE.BASE_URL + MICROSERVICE.BATCH_FILES.POST, true);
      xhr.setRequestHeader('X-Auth-Token', token);
      xhr.send(formData);
    });
  };
}

function setError (message) {
  return {
    type: constants.SET_ERROR,
    payload: message
  };
}

export function cleanUploadedFile () {
  return {
    type: constants.CLEAN_UPLOADED_FILE
  };
}

export function downloadReport (noofdays = 7, tz) {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };
  let config = {
    method: 'GET',
    mode: 'cors',
    headers: {
      'X-Auth-Token': token
    }
  };

  const query = (tz) ? `?noofdays=${noofdays}&timeZone=${tz}` : `?noofdays=${noofdays}&timeZone=${momenttz.tz.guess()}`;

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.BATCH_FILES.REPORT + query, config)
      .then(response =>
        response.text().then((report) => ({report, response}))
      ).then(({report, response}) => {
        if (response.ok) {
          dispatch(receivedReport({report}));
        } else {
          try {
            const error = JSON.parse(report);
            return Promise.reject(error);
          } catch (e) {
            return Promise.reject(e);
          }
        }
      });
  };
}

function receivedReport (value) {
  return {
    type: constants.GOT_REPORT,
    payload: value
  };
}

export function cleanReport (): Action {
  return {
    type: constants.CLEAN_REPORT
  };
}

export function downloadTransactionsReport (batchUploadId, tz) {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };
  let config = {
    method: 'GET',
    mode: 'cors',
    headers: {
      'X-Auth-Token': token
    }
  };

  const query = (tz) ? `?batchUploadId=${batchUploadId}&timeZone=${tz}`
  : `?batchUploadId=${batchUploadId}&timeZone=${momenttz.tz.guess()}`;

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.BATCH_FILES.TRANSACTIONS_REPORT + query, config)
      .then(response =>
        response.text().then((report) => ({report, response}))
      ).then(({report, response}) => {
        if (response.ok) {
          dispatch(receivedTransactionsReport({report}));
        } else {
          try {
            const error = JSON.parse(report);
            return Promise.reject(error);
          } catch (e) {
            return Promise.reject(e);
          }
        }
      });
  };
}

function receivedTransactionsReport (value) {
  return {
    type: constants.GOT_TRANSACTIONS_REPORT,
    payload: value
  };
}

export function cleanTransactionsReport (): Action {
  return {
    type: constants.CLEAN_TRANSACTIONS_REPORT
  };
}

// Reducer
export const initialState = {
  currentBatchFile: {
  },
  currentBatchFiles: {
  },
  filteredBatchFiles: [],
  currentFilter: '',
  currentPage: 0,
  uploadedFile: {},
  uploadedPercentage: 0,
  error: '',
  report: '',
  transactionsReport: ''
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.RECEIVED_BATCH_FILES:
      return Object.assign({}, state, {
        filteredBatchFiles: action.payload
      });
    case constants.RECEIVED_BATCH_FILE:
      return Object.assign({}, state, {
        currentBatchFile: action.payload
      });
    case constants.STORE_FILTER:
      return Object.assign({}, state, {
        currentFilter: action.payload.filter,
        currentPage: action.payload.page
      });
    case constants.CACHE_BATCH_FILE:
      return Object.assign({}, state, {
        currentBatchFile: action.payload
      });
    case constants.CLEAN_BATCH_FILE:
      return Object.assign({}, state, {
        currentBatchFile: action.payload
      });
    case constants.CLEAN_FILTERED_BATCH_FILES:
      return Object.assign({}, state, {
        filteredBatchFiles: {},
        currentBatchFiles: []
      });
    case constants.UPLOADED_FILE:
      return Object.assign({}, state, {
        uploadedFile: action.payload
      });
    case constants.UPDATE_PERCENTAGE:
      return Object.assign({}, state, {
        uploadedPercentage: action.payload
      });
    case constants.SET_ERROR:
      return Object.assign({}, state, {
        error: action.payload
      });
    case constants.CLEAN_UPLOADED_FILE:
      return Object.assign({}, state, {
        uploadedPercentage: 0,
        error: ''
      });
    case constants.CLEAN_FILTER:
      return Object.assign({}, state, {
        currentFilter: ''
      });
    case constants.GOT_REPORT:
      return Object.assign({}, state, {
        report: action.payload.report
      });
    case constants.GOT_TRANSACTIONS_REPORT:
      return Object.assign({}, state, {
        transactionsReport: action.payload.report
      });
    case constants.CLEAN_REPORT:
      return Object.assign({}, state, {
        report: ''
      });
    case constants.CLEAN_TRANSACTIONS_REPORT:
      return Object.assign({}, state, {
        report: ''
      });
    default:
      return state;
  }
}
