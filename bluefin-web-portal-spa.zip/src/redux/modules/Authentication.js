import { MICROSERVICE } from '../../../config/api';
import { UserException, getAccessObject } from '../../utils/utils';
import 'es6-promise';
import 'whatwg-fetch';

// Constants
export const constants = {
  LOGIN_REQUEST: 'LOGIN_REQUEST',
  LOGIN_SUCCESS: 'LOGIN_SUCCESS',
  LOGIN_FAILURE: 'LOGIN_FAILURE',
  LOGOUT_REQUEST: 'LOGOUT_REQUEST',
  LOGOUT_SUCCESS: 'LOGOUT_SUCCESS',
  LOGOUT_FAILURE: 'LOGOUT_FAILURE',
  REQUEST_PASSWORD_SUCCESS: 'REQUEST_PASSWORD_SUCCESS',
  CHANGE_PASSWORD_SUCCESS: 'CHANGE_PASSWORD_SUCCESS',
  MANUAL_LOGOUT: 'MANUAL_LOGOUT'
};

// Action Creators
export function manualLogout () {
  return {
    type: constants.MANUAL_LOGOUT
  };
}

function requestLogin (creds) {
  return {
    type: constants.LOGIN_REQUEST,
    isFetching: true,
    isAuthenticated: false,
    creds
  };
}

function receiveLogin (user) {
  return {
    type: constants.LOGIN_SUCCESS,
    isFetching: false,
    isAuthenticated: true,
    bf_user: user
  };
}

function loginError (message) {
  return {
    type: constants.LOGIN_FAILURE,
    isFetching: false,
    isAuthenticated: false,
    message
  };
}

function requestLogout () {
  return {
    type: constants.LOGOUT_REQUEST,
    isFetching: true,
    isAuthenticated: true
  };
}

function receiveLogout () {
  return {
    type: constants.LOGOUT_SUCCESS,
    isFetching: false,
    isAuthenticated: false
  };
}

function requestedNewPassword () {
  return {
    type: constants.REQUEST_PASSWORD_SUCCESS
  };
}

function changedPassword () {
  return {
    type: constants.CHANGE_PASSWORD_SUCCESS
  };
}

// Calls the API to get a token and
// dispatches actions along the way
export function loginUser (creds) {
  let config = {
    method: 'POST',
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json'
    },
    body: JSON.stringify(creds)
  };

  return dispatch => {
    dispatch(requestLogin(creds));
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.USERS.LOGIN, config)
      .then(response =>
        response.json().then((user) => ({user, response}))
      ).then(({user, response}) => {
        if (response.ok) {
          localStorage.setItem('bf_user', JSON.stringify(user));
          // Dispatch the success action
          dispatch(receiveLogin(user));
        } else {
          if (response.status === 401) {
            return Promise.reject(new UserException('Login failed, invalid credentials.', { status: 401 }));
          } else if (response.status === 403) {
            return Promise.reject(new UserException('You\'re not authorized to perform this action.',
              { status: 403, message: user.message }));
          }
          dispatch(loginError(user.message));
          return Promise.reject(user);
        }
      });
  };
}

export function logoutUser () {
  let token = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) { };
  let config = {
    method: 'DELETE',
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json',
      'X-Auth-Token': token
    }
  };

  return dispatch => {
    dispatch(requestLogout());
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.USERS.LOGIN, config)
      .then(response => {
        if (response.ok) {
          localStorage.removeItem('bf_user');
          localStorage.removeItem('bf_access_roles');
          // Dispatch the success action
          dispatch(receiveLogout());
        } else {
          if (response.status === 401) {
            localStorage.removeItem('bf_user');
            localStorage.removeItem('bf_access_roles');
            return Promise.reject(new UserException('Not logged in.', { status: 401 }));
          } else if (response.status === 403) {
            return Promise.reject(new UserException('You\'re not authorized to perform this action.', { status: 403 }));
          }
          return Promise.reject({});
        }
      });
  };
}

export function requestNewPassword (username) {
  let config = {
    method: 'POST',
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json'
    },
    body: JSON.stringify({ username })
  };

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.USERS.RECOVER_PASSWORD, config)
      .then((response) => {
        if (response.ok) {
          dispatch(requestedNewPassword());
        } else {
          if (response.status === 401) {
            localStorage.removeItem('bf_user');
            localStorage.removeItem('bf_access_roles');
            return Promise.reject(new UserException('Not logged in.', { status: 401 }));
          } else if (response.status === 403) {
            return Promise.reject(new UserException('You\'re not authorized to perform this action.', { status: 403 }));
          } else if (response.status === 404) {
            return Promise.reject(new UserException('The provided username doesn\'t exist.', { status: 404 }));
          } else {
            return Promise.reject({});
          }
        }
      });
  };
}

export function changePassword (data, token) {
  let existingToken = null;
  try {
    token = JSON.parse(localStorage.getItem('bf_user')).token;
  } catch (e) {
    existingToken = token;
  };
  let config = {
    method: 'PUT',
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8',
      'Accept': 'application/json',
      'X-Auth-Token': existingToken
    },
    body: JSON.stringify({ oldPassword: data.password, newPassword: data.password })
  };

  return dispatch => {
    return fetch(MICROSERVICE.BASE_URL + MICROSERVICE.USERS.CRUD + 'me/password', config)
      .then((response) => {
        if (response.ok) {
          dispatch(changedPassword());
        } else if (response.status === 401) {
          return Promise.reject(
            new UserException('The provided token is invalid, please request a new password reset and try again.',
            { status: 401 }));
        } else if (response.status === 403) {
          return Promise.reject(new UserException('You\'re not authorized to perform this action.', { status: 403 }));
        } else {
          return Promise.reject({});
        }
      });
  };
}

// Reducer
let user = {};
let roles = {};
try {
  user = JSON.parse(localStorage.getItem('bf_user'));
  roles = JSON.parse(localStorage.getItem('bf_access_roles'));
} catch (e) { };
export const initialState = {
  isAuthenticated: !!localStorage.getItem('bf_user'),
  user: {},
  profile: user || {},
  accessRoles: roles || {}
};
export default function (state = initialState, action) {
  switch (action.type) {
    case constants.LOGIN_REQUEST:
      return Object.assign({}, state, {
        isAuthenticated: false,
        user: action.creds
      });
    case constants.LOGIN_SUCCESS:
      const accessRoles = getAccessObject(action.bf_user.roles,
        action.bf_user.permissions);
      localStorage.setItem('bf_access_roles', JSON.stringify(accessRoles));
      return Object.assign({}, state, {
        isAuthenticated: true,
        errorMessage: '',
        profile: action.bf_user,
        accessRoles
      });
    case constants.LOGIN_FAILURE:
      return Object.assign({}, state, {
        isAuthenticated: false,
        errorMessage: action.message
      });
    case constants.LOGOUT_SUCCESS:
      return Object.assign({}, state, {
        isAuthenticated: false
      });
    case constants.CHANGE_PASSWORD_SUCCESS:
      return Object.assign({}, state, {
        isAuthenticated: false
      });
    case constants.REQUEST_PASSWORD_SUCCESS:
      return Object.assign({}, state, {
        isAuthenticated: false
      });
    case constants.MANUAL_LOGOUT:
      localStorage.removeItem('bf_user');
      localStorage.removeItem('bf_access_roles');
      return Object.assign({}, state, {
        isAuthenticated: false
      });
    default:
      return state;
  }
}
