import { CALL_API } from '../../middleware/api';
import { MICROSERVICE } from '../../../config/api';

// Constants
export const constants = {
  CREATE_LEGAL_ENTITY: 'CREATE_LEGAL_ENTITY',
  CREATED_LEGAL_ENTITY: 'CREATED_LEGAL_ENTITY',
  CREATE_LEGAL_ENTITY_FAILED: 'CREATE_LEGAL_ENTITY_FAILED',
  GET_LEGAL_ENTITY: 'GET_LEGAL_ENTITY',
  GOT_LEGAL_ENTITY: 'GOT_LEGAL_ENTITY',
  GOT_LEGAL_ENTITY_FAILED: 'GOT_LEGAL_ENTITY_FAILED',
  GET_LEGAL_ENTITIES: 'GET_LEGAL_ENTITIES',
  GOT_LEGAL_ENTITIES: 'GOT_LEGAL_ENTITIES',
  GOT_LEGAL_ENTITIES_FAILED: 'GOT_LEGAL_ENTITIES_FAILED',
  DELETE_LEGAL_ENTITY: 'DELETE_LEGAL_ENTITY',
  DELETED_LEGAL_ENTITY: 'DELETED_LEGAL_ENTITY',
  DELETED_LEGAL_ENTITY_FAILED: 'DELETED_LEGAL_ENTITY_FAILED',
  UPDATE_LEGAL_ENTITY: 'UPDATE_LEGAL_ENTITY',
  UPDATED_LEGAL_ENTITY: 'UPDATED_LEGAL_ENTITY',
  UPDATE_LEGAL_ENTITY_FAILED: 'UPDATE_LEGAL_ENTITY_FAILED',
  CLEAN_LEGAL_ENTITY: 'CLEAN_LEGAL_ENTITY'
};

// Action Creators

export function cleanLegalEntity (): Action {
  return {
    type: constants.CLEAN_LEGAL_ENTITY,
    payload: {
      legalEntityAppId: '',
      legalEntityAppName: '',
      paymentProcessorMerchants: {}
    }
  };
}

function _createLegalEntity (legalEntity) {
  return {
    [CALL_API]: {
      types: [constants.CREATED_LEGAL_ENTITY, constants.CREATE_LEGAL_ENTITY_FAILED],
      endpoint: MICROSERVICE.LEGAL_ENTITIES.CRUD,
      authenticated: true,
      body: JSON.stringify(legalEntity),
      method: 'POST'
    }
  };
}

export function createLegalEntity (legalEntity) {
  return (dispatch) => {
    return dispatch(_createLegalEntity(legalEntity));
  };
}

function _getLegalEntity (legalEntityAppId) {
  return {
    [CALL_API]: {
      types: [constants.GOT_LEGAL_ENTITY, constants.GOT_LEGAL_ENTITY_FAILED],
      endpoint: MICROSERVICE.LEGAL_ENTITIES.CRUD + legalEntityAppId,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getLegalEntity (legalEntityAppId) {
  return (dispatch) => {
    return dispatch(_getLegalEntity(legalEntityAppId));
  };
}

function _getLegalEntities () {
  return {
    [CALL_API]: {
      types: [constants.GOT_LEGAL_ENTITIES, constants.GOT_LEGAL_ENTITIES_FAILED],
      endpoint: MICROSERVICE.LEGAL_ENTITIES.CRUD,
      authenticated: true,
      method: 'GET'
    }
  };
}

export function getLegalEntities () {
  return (dispatch) => {
    return dispatch(_getLegalEntities());
  };
}

function _deleteLegalEntity (legalEntityAppId) {
  return {
    [CALL_API]: {
      types: [constants.DELETED_LEGAL_ENTITY, constants.DELETED_LEGAL_ENTITY_FAILED],
      endpoint: MICROSERVICE.LEGAL_ENTITIES.CRUD + legalEntityAppId,
      authenticated: true,
      method: 'DELETE'
    }
  };
}

export function deleteLegalEntity (legalEntity) {
  return (dispatch) => {
    return dispatch(_deleteLegalEntity(legalEntity));
  };
}

function _updateLegalEntity (legalEntityAppId, legalEntity) {
  return {
    [CALL_API]: {
      types: [constants.UPDATED_LEGAL_ENTITY, constants.UPDATE_LEGAL_ENTITY_FAILED],
      endpoint: MICROSERVICE.LEGAL_ENTITIES.CRUD + legalEntityAppId,
      authenticated: true,
      method: 'PUT',
      body: JSON.stringify(legalEntity)
    }
  };
}

export function updateLegalEntity (legalEntityAppId, legalEntity) {
  return (dispatch) => {
    return dispatch(_updateLegalEntity(legalEntityAppId, legalEntity));
  };
}

// Reducer
export const initialState = {
  currentLegalEntity: {
    legalEntityAppId: '',
    legalEntityAppName: ''
  },
  legalEntities: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case constants.UPDATED_LEGAL_ENTITY:
      return Object.assign({}, state, {
        currentLegalEntity: action.payload
      });
    case constants.CREATED_LEGAL_ENTITY:
      return Object.assign({}, state, {
        currentLegalEntity: action.payload
      });
    case constants.GOT_LEGAL_ENTITY:
      return Object.assign({}, state, {
        currentLegalEntity: action.payload
      });
    case constants.GOT_LEGAL_ENTITIES:
      return Object.assign({}, state, {
        legalEntities: action.payload
      });
    case constants.DELETED_LEGAL_ENTITY:
      return Object.assign({});
    case constants.CLEAN_LEGAL_ENTITY:
      return Object.assign({}, state, {
        currentLegalEntity: action.payload
      });
    default:
      return state;
  }
}
