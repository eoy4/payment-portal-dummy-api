import { applyMiddleware, compose, createStore } from 'redux';
import { routerMiddleware } from 'react-router-redux';
import thunk from 'redux-thunk';
import rootReducer from './rootReducer';
import api from '../middleware/api';
import authCheck from '../middleware/authCheck';
import { middleware as idleMiddleware, actions as idleActions } from '../components/ReduxIdleMonitor';

export default function configureStore (initialState = {}, history) {
  // Compose final middleware and use devtools in debug environment
  let middleware = applyMiddleware(thunk, api, idleMiddleware, routerMiddleware(history), authCheck);
  if (__DEBUG__) {
    const devTools = window.devToolsExtension
      ? window.devToolsExtension()
      : require('containers/DevTools').default.instrument();
    middleware = compose(middleware, devTools);
  }

  // Create final store and subscribe router in debug env ie. for devtools
  const store = middleware(createStore)(rootReducer, initialState);

  if (module.hot) {
    module.hot.accept('./rootReducer', () => {
      const nextRootReducer = require('./rootReducer').default;

      store.replaceReducer(nextRootReducer);
    });
  }
  const { isAuthenticated } = store.getState().auth;
  if (isAuthenticated) {
    store.dispatch(idleActions.start());
  }

  return store;
}
