import { push } from 'react-router-redux';
import { manualLogout } from '../redux/modules/Authentication';

const authCheck = ({ dispatch }) => {
  return (next) => (action) => {
    const { error } = action;
    if (error && error.details && (error.details.status === 401 || error.details.status === 403)) {
      dispatch(manualLogout());
      dispatch(push('/login'));
    }
    return next(action);
  };
};

export default authCheck;
