import ForgotPasswordForm from './ForgotPasswordForm';
export default ForgotPasswordForm;
