import React from 'react';
import { reduxForm } from 'redux-form';

export const fields = ['password', 'confirmation'];

const validate = (values) => {
  const errors = {};
  if (!values.password) {
    errors.password = 'Required';
  }
  if (!/^.*(?=.*\d)(?=.*[A-Z]).{8,16}/g.test(values.password)) {
    errors.password = 'Password not strong enough';
  }
  if (!values.confirmation) {
    errors.confirmation = 'Required';
  }
  if (!/^.*(?=.*\d)(?=.*[A-Z]).{8,16}/g.test(values.confirmation)) {
    errors.confirmation = 'Password not strong enough';
  }
  if (values.confirmation !== values.password) {
    errors.confirmation = 'Both passwords should match.';
  }
  return errors;
};

type Props = {
  handleSubmit: Function,
  fields: Object,
  submitting: boolean,
  invalid: boolean,
  username: String,
}
export class ForgotPassword extends React.Component {
  props: Props;

  defaultProps = {
  }

  render () {
    const { fields: { password, confirmation }, handleSubmit, submitting, invalid } = this.props;

    return (
      <form className='form-signin form-horizontal' onSubmit={handleSubmit} noValidate>

        {
          this.props.username
          ? <div className='form-group'>
            <input type='text' className='form-control' disabled value={this.props.username} />
          </div>
          : null
        }
        <div className='form-group'>
          {password.touched && password.error &&
            <span style={{'marginLeft': '10px'}} className='label label-danger'>{password.error}</span>}
          <input type='password' id='inputPassword' className='form-control'
            placeholder='Password' {...password} />
        </div>
        <div className='form-group'>
          {confirmation.touched && confirmation.error &&
            <span style={{'marginLeft': '10px'}} className='label label-danger'>{confirmation.error}</span>}
          <input type='password' id='inputConfirmPassword' className='form-control'
            placeholder='Confirm Password' {...confirmation} />
        </div>
        <p>
          <i className='glyphicon glyphicon-info-sign'></i>
          &nbsp;
          Your password must be between 8 and 16 characters long, and contain uppercase
          letters, lowercase letters, and numbers.
        </p>
        <div className='form-group'>
          <button className='btn btn-lg btn-primary btn-block btn-signin'
            disabled={submitting || invalid} type='submit'>Update password</button>
        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'ForgotPassword',
  fields,
  validate
})(ForgotPassword);
