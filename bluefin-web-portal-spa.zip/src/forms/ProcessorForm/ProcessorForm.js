import React from 'react';
import { reduxForm } from 'redux-form';
import { Checkbox } from '../../components/Checkbox/Checkbox';
import { RegexValidatedInput } from '../../components/RegexValidatedInput/RegexValidatedInput';

export const fields = ['paymentProcessorId', 'processorName', 'isActive'];

const validate = (values) => {
  const errors = {};

  if (!values.processorName) {
    errors.processorName = 'Required';
  }

  return errors;
};

type Props = {
  handleSubmit: Function,
  /* resetForm: Function,*/
  submitting: boolean,
  invalid: boolean,
  fields: Object
}

export class Processor extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  render () {
    const {
      fields: {
        paymentProcessorId,
        processorName,
        isActive
      },
      handleSubmit,
      /* resetForm,*/
      submitting,
      invalid
    } = this.props;

    return (
      <form onSubmit={handleSubmit} key={isActive.value}>
        <input type='hidden' {...paymentProcessorId} />
        <div className='row'>
          <div className='col-xs-12'>
            <div className='form-group'>
              <label className='control-label'>Processor Name</label>
              <RegexValidatedInput className='form-control' type='text' placeholder='Processor Name'
                {...processorName} regex={/\w[\w|\s|\.|'|\-]*/g} />
            </div>
            <div className='form-group'>
              <Checkbox {...isActive} />
              &nbsp;
              <label className='control-label'>Is Active</label>
            </div>
          </div>
        </div>
        <div className='row'>
          <div className='col-xs-12'>
            <div className='form-group'>
              <button className='btn btn-primary' disabled={submitting || invalid} type='submit'>
                Submit
              </button>
            </div>
          </div>
        </div>
      </form>
    );
  }
}

export default reduxForm({
  form: 'Processor',
  fields,
  validate
})(Processor);
