import React from 'react';
import { reduxForm } from 'redux-form';
import { PermissionTree } from '../../components/PermissionTree/PermissionTree';
import { RegexValidatedInput } from '../../components/RegexValidatedInput/RegexValidatedInput';

export const fields = ['firstName', 'lastName', 'email', 'username', 'roles', 'legalEntityApps'];

const validate = (values) => {
  const errors = {};
  return errors;
};

type Props = {
  handleSubmit: Function,
  /* resetForm: Function,*/
  submitting: boolean,
  invalid: boolean,
  fields: Object,
  availableRoles: Array,
  availableLegalEntities: Array,
  mode: string
}
export class UserInformation extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  constructor (props) {
    super(props);

    this.handleRoleSelection = this.handleRoleSelection.bind(this);
  }

  componentWillReceiveProps (props) {
    if (props.fields.roles.value) {
      this.selectLegalEntities(props.fields.roles.value, '6');
    }
  }

  handleRoleSelection (selection) {
    this.selectLegalEntities(selection, '6');
  }

  selectLegalEntities (selection, roleId) {
    for (let index in selection) {
      const id = selection[index];
      if (id === roleId) {
        const elements = this.props.availableLegalEntities.map((leaf) => {
          return leaf.legalEntityAppId.toString();
        });
        this.setState({
          disableLE: true,
          elements
        });
        return;
      }
    }
    this.setState({ disableLE: false, elements: [] });
  }

  render () {
    const {
      fields: {
        firstName, lastName, email, username, roles, legalEntityApps
      },
      /* resetForm,*/
      handleSubmit,
      submitting,
      invalid
    } = this.props;

    const disableLE = this.state && this.state.disableLE;
    const LEIds = this.state && this.state.elements;

    return (
      <form onSubmit={handleSubmit}>
        <div className='form-group'>
          <div className='row'>
            <div className='col-md-3'>
              <label className='control-label'>First Name</label>
              <RegexValidatedInput className='form-control' type='text' placeholder='First Name'
                {...firstName} regex={/\w[\w|\s|\.|'|\-]*/g} id='first-name-input' />
            </div>
            <div className='col-md-3'>
              <label className='control-label'>Last Name</label>
              <RegexValidatedInput className='form-control' type='text' placeholder='Last Name'
                {...lastName} regex={/\w[\w|\s|\.|'|\-]*/g} id='last-name-input' />
            </div>
            <div className='col-md-3'>
              <label className='control-label'>Username</label>
              <RegexValidatedInput className='form-control' type='text'
                disabled={this.props.mode === 'edit' || this.props.mode === 'self'}
                placeholder='Username' {...username} regex={/\w[\w|\s|\.|'|\-]*/g} id='username-input' />
            </div>
            <div className='col-md-3'>
              <label className='control-label'>Email</label>
              <input className='form-control' type='email' placeholder='Email' {...email} id='email-input' />
            </div>
          </div>
        </div>

        <div className='form-group'>
          <div className='row'>
            <div className='col-md-6'>
              <label className='control-label'>Roles</label>
              <PermissionTree {...roles} mode={this.props.mode} notifySelection={this.handleRoleSelection}
                leaves={this.props.availableRoles} title={'Available Roles'} />
            </div>
            <div className='col-md-6'>
              <label className='control-label'>Legal Entities</label>
              <PermissionTree {...legalEntityApps} mode={this.props.mode} disabled={disableLE} selectAll={disableLE}
                leaves={this.props.availableLegalEntities} selectedItems={LEIds} title={'Available Entities'} />
            </div>
          </div>
        </div>

        <button className='btn btn-primary' disabled={submitting || invalid} type='submit' id='update-user-button'>
          {(this.props.mode === 'self' || this.props.mode === 'edit') ? 'Update' : 'Create'}</button>
      </form>
    );
  }
}

export default reduxForm({
  form: 'UserInformation',
  fields,
  validate
})(UserInformation);
