import UserInformationForm from './UserInformationForm';
export default UserInformationForm;
