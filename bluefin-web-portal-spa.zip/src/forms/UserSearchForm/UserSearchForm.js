import React from 'react';
import { reduxForm } from 'redux-form';
import { RegexValidatedInput } from '../../components/RegexValidatedInput/RegexValidatedInput';

export const fields = ['username', 'firstName', 'lastName', 'email', 'legalEntities', 'roles', 'status'];

const validate = (values) => {
  const errors = {};
  return errors;
};

type Props = {
  handleSubmit: Function,
  fields: Object,
  type: string,
  availableRoles: Array,
  availableLegalEntities: Array,
}
export class UserSearch extends React.Component {
  props: Props;

  defaultProps = {
    fields: {}
  }

  render () {
    const {
      fields: {
        username, firstName, lastName, email, legalEntities, roles, status
      },
      handleSubmit,
      /* resetForm,
      submitting,
      filterObject,*/
      type
    } = this.props;

    const advanced = (type === 'advanced')
      ? <div className='form-group'>
        <div className='row'>
          <div className='col-md-3'>
            <div className='form-group'>
              <label className='control-label'>First Name</label>
              <RegexValidatedInput className='form-control' type='text' placeholder='First Name'
                {...firstName} regex={/\w[\w|\s|\.|'|\-]*/g} id='first-name-input' />
            </div>
          </div>
          <div className='col-md-3'>
            <div className='form-group'>
              <label className='control-label'>Last Name</label>
              <RegexValidatedInput className='form-control' type='text' placeholder='Last Name'
                {...lastName} regex={/\w[\w|\s|\.|'|\-]*/g} id='last-name-input' />
            </div>
          </div>
          <div className='col-md-3'>
            <div className='form-group'>
              <label className='control-label'>Username</label>
              <RegexValidatedInput className='form-control' type='text' placeholder='Username'
                {...username} regex={/\w[\w|\s|\.|'|\-]*/g} id='username-input' />
            </div>
          </div>
          <div className='col-md-3'>
            <div className='form-group'>
              <label className='control-label'>Email</label>
              <input className='form-control' type='email' placeholder='Email' {...email} id='email-input' />
            </div>
          </div>
        </div>
        <div className='row'>
          <div className='col-md-3 selectContainer'>
            <div className='form-group'>
              <label className='control-label'>Legal Entities</label>
              <select className='form-control' {...legalEntities} id='legal-entities-select'>
                <option value=''>Choose an option</option>
                {
                  this.props.availableLegalEntities.map(({legalEntityAppName, legalEntityAppId}) => {
                    return <option key={legalEntityAppId} value={legalEntityAppId}>{legalEntityAppName}</option>;
                  })
                }
              </select>
            </div>
          </div>
          <div className='col-md-3 selectContainer'>
            <div className='form-group'>
              <label className='control-label'>Roles</label>
              <select className='form-control' {...roles} id='roles-select'>
                <option value=''>Choose an option</option>
                {
                  this.props.availableRoles.map(({description, roleId}) => {
                    return <option key={roleId} value={roleId}>{description}</option>;
                  })
                }
              </select>
            </div>
          </div>
          <div className='col-md-3 selectContainer'>
            <div className='form-group'>
              <label className='control-label'>Status</label>
              <select className='form-control' {...status} id='roles-select'>
                <option value=''>Choose an option</option>
                <option value='ACTIVE'>Active</option>
                <option value='INACTIVE'>Inactive</option>
                <option value='NEW'>New</option>
              </select>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='form-group'>
              <label className='control-label'>Search</label>
              <div>
                <button className='btn btn-primary' type='submit' id='search-users-button'>
                  <i className='glyphicon glyphicon-search'></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      : <div className='form-group'>
        <div className='row'>
          <div className='col-md-6'>
            <label className='control-label'>Username</label>
            <input className='form-control' type='text' placeholder='Username' id='username-input'
              {...username} />
          </div>
          <div className='col-md-6'>
            <button className='btn btn-primary' style={{'marginTop': '24px'}} type='submit' id='search-users-button'>
              <i className='glyphicon glyphicon-search'></i>
            </button>
          </div>
        </div>
      </div>;

    return (
      <form onSubmit={handleSubmit}>
        {advanced}
      </form>
    );
  }
}

export default reduxForm({
  form: 'UserSearch',
  fields,
  validate
})(UserSearch);
