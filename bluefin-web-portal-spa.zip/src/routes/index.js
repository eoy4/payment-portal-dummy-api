import React from 'react';
import { Route, IndexRoute } from 'react-router';
import CoreLayout from 'layouts/CoreLayout/CoreLayout';
import VoidView from 'views/VoidView/VoidView';
import RefundView from 'views/RefundView/RefundView';
import SalesView from 'views/SalesView/SalesView';
import {default as ReportsView} from 'views/ReportsView/ReportsView';
import TransactionDetailsView from 'views/TransactionDetailsView/TransactionDetailsView';
import { RecurringPaymentsView } from 'views/RecurringPaymentsView/RecurringPaymentsView';
import { BatchFileDetailsView } from 'views/BatchFileDetailsView/BatchFileDetailsView';
import ConfirmationView from 'views/ConfirmationView/ConfirmationView';
import RefundConfirmationView from 'views/RefundConfirmationView/RefundConfirmationView';
import VoidConfirmationView from 'views/VoidConfirmationView/VoidConfirmationView';
import LoginView from 'views/LoginView/LoginView';
import AccountView from 'views/AccountView/AccountView';
import UsersView from 'views/UsersView/UsersView';
import EditUserView from 'views/EditUserView/EditUserView';
import UserLookupView from 'views/UserLookupView/UserLookupView';
import PasswordRecoveryView from 'views/PasswordRecoveryView/PasswordRecoveryView';
import ResponseCodesView from 'views/ResponseCodesView/ResponseCodesView';
import StatusCodesView from 'views/StatusCodesView/StatusCodesView';
import NotFoundView from 'views/NotFoundView/NotFoundView';
import ProcessorRulesView from 'views/ProcessorRulesView/ProcessorRulesView';
import { default as ProcessorsView } from 'views/ProcessorsView';
import ProcessorDetailsView from 'views/ProcessorDetailsView/ProcessorDetailsView';
import { ProcessorToMerchantsView } from 'views/ProcessorToMerchantsView/ProcessorToMerchantsView';
import { default as RemittanceView } from 'views/RemittanceView/RemittanceView';
import { RemittanceInformationView } from 'views/RemittanceInformationView/RemittanceInformationView';
import { default as LegalEntitiesView } from 'views/LegalEntitiesView';
import AboutView from 'views/AboutView/AboutView';
import { checkAllowedPath } from 'utils/utils';
import toastr from 'toastr';

function clearNotifications () {
  toastr.clear();
}

function requireAuth (store, nextState, replace) {
  const { isAuthenticated, accessRoles } = store.getState().auth;
  const pathName = '/' + nextState.location.pathname.split('/')[1];
  if (!isAuthenticated) {
    replace({
      pathname: '/login',
      state: { nextPathname: pathName }
    });
  }
  if (!checkAllowedPath(nextState.location.pathname, accessRoles)) {
    if (checkAllowedPath('/search', accessRoles)) {
      replace('/search/transactions');
    } else if (checkAllowedPath('/sales', accessRoles)) {
      replace('/sales');
    } else {
      replace('/about');
    }
  }
}

export default (store) => {
  const auth = requireAuth.bind(this, store);
  return (<div>
    <Route path='login' component={CoreLayout}>
      <IndexRoute component={LoginView} />
      <Route path='recover' component={PasswordRecoveryView} />
      <Route path='reset' component={PasswordRecoveryView} />
    </Route>
    <Route path='/' component={CoreLayout}>
      <IndexRoute component={SalesView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='void(/:id)' component={VoidView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='refund(/:id)' component={RefundView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='sales' component={SalesView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='search'>
        <IndexRoute component={ReportsView} onEnter={auth} onLeave={clearNotifications} />
        <Route path='transactions'>
          <IndexRoute component={ReportsView} onEnter={auth} onLeave={clearNotifications} />
          <Route path='details/:transactionId' component={TransactionDetailsView}
            onEnter={auth} onLeave={clearNotifications} />
          <Route path='details/:transactionId/:transactionType(/:timeZone)' component={TransactionDetailsView}
            onEnter={auth} onLeave={clearNotifications} />
        </Route>
        <Route path='remittance'>
          <IndexRoute component={RemittanceView} onEnter={auth} onLeave={clearNotifications} />
          <Route path='details/:remittanceId' component={RemittanceInformationView}
            onEnter={auth} onLeave={clearNotifications} />
          <Route path='details/:remittanceId/:transactionType/:processorTransactionType'
            component={RemittanceInformationView}
            onEnter={auth}
            onLeave={clearNotifications} />
        </Route>
      </Route>
      <Route path='batch-transactions'>
        <IndexRoute component={RecurringPaymentsView} onEnter={auth} onLeave={clearNotifications} />
        <Route path='details/:batchUploadId(/:timeZone)' component={BatchFileDetailsView}
          onEnter={auth} onLeave={clearNotifications} />
      </Route>
      <Route path='confirmed/sale/:id' component={ConfirmationView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='summary/void' component={VoidConfirmationView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='summary/refund' component={RefundConfirmationView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='account' component={AccountView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='users/edit/:username' component={EditUserView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='users/create' component={UsersView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='users' component={UserLookupView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='response-codes'>
        <IndexRoute component={ResponseCodesView} onEnter={auth} onLeave={clearNotifications} />
        <Route path=':paymentProcessorId' component={ResponseCodesView}
          onEnter={auth} onLeave={clearNotifications} />
      </Route>
      <Route path='status-codes'>
        <IndexRoute component={StatusCodesView} onEnter={auth} onLeave={clearNotifications} />
        <Route path=':paymentProcessorId' component={StatusCodesView}
          onEnter={auth} onLeave={clearNotifications} />
      </Route>
      <Route path='rules' component={ProcessorRulesView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='processors'>
        <IndexRoute component={ProcessorsView} onEnter={auth} onLeave={clearNotifications} />
        <Route path=':paymentProcessorId' component={ProcessorDetailsView}
          onEnter={auth} onLeave={clearNotifications} />
      </Route>
      <Route path='processor-merchants' component={ProcessorToMerchantsView}
        onEnter={auth} onLeave={clearNotifications} />
      <Route path='processor-merchants/:paymentProcessorId' component={ProcessorToMerchantsView}
        onEnter={auth} onLeave={clearNotifications} />
      <Route path='legal-entities' component={LegalEntitiesView} onEnter={auth} onLeave={clearNotifications} />
      <Route path='about' component={AboutView} onEnter={auth} onLeave={clearNotifications} />
      <Route path="*" component={NotFoundView} onEnter={auth} onLeave={clearNotifications} />
    </Route>
  </div>);
};
