import uuid from 'uuid';
import { default as CreditCard } from 'credit-card';
import toastr from 'toastr';
import { default as moment } from 'moment';
import { MIDDLEWARE } from '../../config/api';

// const momenttz = require('moment-timezone');

export function createFilter (data, page = 0, size = 15) {
  let filter = '';
  if (data) {
    const minAmount = (data.minamount) ? data.minamount.replace('$', '').replace(/,/g, '') : null;
    const maxAmount = (data.maxamount) ? data.maxamount.replace('$', '').replace(/,/g, '') : null;

    const entitiesStr = (data.legalEntity && data.legalEntity.map)
      ? data.legalEntity.map(entity => entity.label || entity).join(',')
      : '';
    const mIdsStr = (data.merchantId && data.merchantId.map)
      ? data.merchantId.map(mId => mId.label || mId).join(',')
      : '';

    filter = ((data.mintransactionDateTime)
      ? `transactionDateTime>${moment(data.mintransactionDateTime).utc().format('YYYY-MM-DD HH:mm:ss')}$$`
      : '') +
    ((data.maxtransactionDateTime)
      ? `transactionDateTime<${moment(data.maxtransactionDateTime).utc().format('YYYY-MM-DD HH:mm:ss')}$$`
      : '') +
    ((minAmount) ? `amount>${minAmount}$$` : '') +
    ((maxAmount) ? `amount<${maxAmount}$$` : '') +
    ((entitiesStr) ? `legalEntity:[${entitiesStr}]$$` : '') +
    ((mIdsStr) ? `merchantId:[${mIdsStr}]$$` : '') +
    ((data.accountNumber) ? `accountNumber:${data.accountNumber}$$` : '') +
    ((data.applicationTransactionId) ? `transactionId:${data.applicationTransactionId}$$` : '') +
    ((data.firstName) ? `firstName:${data.firstName}$$` : '') +
    ((data.lastName) ? `lastName:${data.lastName}$$` : '') +
    ((data.transactionType) ? `transactionType:${data.transactionType}$$` : '') +
    ((data.cardType) ? `cardType:${data.cardType}$$` : '') +
    ((data.internalStatusCode) ? `internalStatusCode:${data.internalStatusCode}$$` : '') +
    ((data.invoiceNumber) ? `invoiceNumber:${data.invoiceNumber}$$` : '') +
    ((data.accountPeriod) ? `accountPeriod:${data.accountPeriod}$$` : '') +
    ((data.desk) ? `desk:${data.desk}$$` : '') +
    ((data.batchUploadId) ? `batchUploadId:${data.batchUploadId}$$` : '') +
    ((data.processUser) ? `processUser:${data.processUser}$$` : '') +
    ((data.application) ? `application:${data.application}$$` : '') +
    ((data.processorName) ? `processorName:${data.processorName}$$` : '') +
    // Uncomment following line to enable filtering by Reconciliation Status
    ((data.reconciliationStatusId) ? `reconciliationStatusId:${data.reconciliationStatusId}$$` : '') +
    ((data.paymentFrequency) ? `paymentFrequency:${data.paymentFrequency}$$` : '') +
    ((data.remittanceCreationDate)
      ? `remittanceCreationDate>${moment(data.remittanceCreationDate)
        .startOf('day').format('YYYY-MM-DD HH:mm:ss')}$$`
      : '') +
    ((data.remittanceCreationDate)
      ? `remittanceCreationDate<${moment(data.remittanceCreationDate)
        .endOf('day').format('YYYY-MM-DD HH:mm:ss')}`
      : '');
  }

  if (filter.lastIndexOf('$$') === filter.length - 2) {
    filter = filter.slice(0, (filter.length - 2));
  }

  filter += `&page=${page}&size=${size}`;
  if (data.mintransactionDateTime) {
    filter += '&sort=transactionDateTime:desc,amount:asc';
  }
  if (data.remittanceCreationDate) {
    filter += '&sort=remittanceCreationDate:desc';
  }
  /*
  if (data.timeDifference) {
    filter += `&timeDifference=${data.timeDifference}`;
  } else {
    filter += `&timeDifference=${moment().utcOffset()}`;
  }
  */
  if (data.timeZone) {
    filter += `&timeZone=${data.timeZone}`;
  } else {
    filter += `&timeZone=${moment.tz.guess()}`;
  }

  return filter;
}

function extractParameterFromFilter (name, filter) {
  if (!filter) {
    filter = window.location.href;
  }
  name = name.replace(/[\[\]]/g, '\\$&');
  var regex, results;
  regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
  results = regex.exec(filter);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

export function getDataFromFilter (filter) {
  const index = filter.indexOf('&');
  let params = filter;
  if (index > -1) {
    params = filter.slice(0, index);
  }
  const retObj = {};

  params && params.split('$$').forEach((item) => {
    if (item.indexOf('>') !== -1) {
      const key = item.split('>')[0];
      const value = item.split('>')[1];
      retObj['min' + key] = value;
    } else if (item.indexOf('<') !== -1) {
      const key = item.split('<')[0];
      const value = item.split('<')[1];
      retObj['max' + key] = value;
    } else if (item.indexOf(':') !== -1) {
      const key = item.split(':')[0];
      let value = item.split(':')[1];
      if (value.indexOf('[') !== -1) {
        value = value.replace(/\[/g, '').replace(/\]/g, '');
        value = value.split(',');
      }
      retObj[key] = value;
    }
  });
  const tz = extractParameterFromFilter('timeZone', filter);
  retObj.timeZone = tz;
  return retObj;
}

export function createUserFilter (data) {
  let filter = '';
  if (data) {
    filter = ((data.username) ? `username:${data.username}$$` : '') +
    ((data.firstName) ? `firstName:${data.firstName}$$` : '') +
    ((data.lastName) ? `lastName:${data.lastName}$$` : '') +
    ((data.email) ? `email:${data.email}$$` : '') +
    ((data.roles) ? `roles:[${data.roles}]$$` : '') +
    ((data.status) ? `status:${data.status}$$` : '') +
    ((data.legalEntities) ? `legalEntities:[${data.legalEntities}]` : '');
  }

  if (filter.lastIndexOf('$$') === filter.length - 2) {
    filter = filter.slice(0, (filter.length - 2));
  }
  return filter;
}

export function updateFilter ({filter, regex, varName, value} = {}) {
  return filter.replace(regex, `${varName}=${value}`);
}

export function filterUpdatePage (filter, newPage) {
  return updateFilter({
    filter: filter,
    regex: /page=[\d]*/g,
    varName: 'page',
    value: newPage
  });
}

export function filterUpdateSize (filter, newSize, type) {
  pageSize(type, newSize);

  return updateFilter({
    filter: filter,
    regex: /size=[\d]*/g,
    varName: 'size',
    value: newSize
  });
}

export const defaultPageSize = 15;

export function pageSize (type, newSize = '') {
  const localStorage = window.localStorage || {};
  const pageSize = localStorage.pageSize ? JSON.parse(localStorage.pageSize) : {};
  if (type) {
    pageSize[type] = pageSize[type] || defaultPageSize;
    if (newSize) {
      pageSize[type] = newSize;
    }
  }
  localStorage.pageSize = JSON.stringify(pageSize);
  return type ? pageSize[type] : pageSize;
}

export function generateTransactionId () {
  const first = moment().format('x').slice(-4);
  const middle = uuid.v1().replace(/-/g, '').slice(0, 10);
  const last = ('0000' + (Math.random() * Math.pow(36, 4) << 0).toString(36)).slice(-4);
  return first + middle + last;
}

export function mergeTransactionInformation (cachedObj, newObj) {
  const cardType = CreditCard.determineCardType(cachedObj.cardNumberLast4Char);
  return Object.assign({}, cachedObj, {
    amount: newObj.amount,
    processorName: newObj.processor,
    internalStatusCode: newObj.responseDesc,
    transactionResponseCode: newObj.responseDesc,
    statusCode: newObj.statusCode,
    cardType
  });
}

export function getTransactionObject (remittance = {}) {
  if (!remittance) {
    return null;
  }
  const transactionObject = {saleTransaction: {}, paymentProcessorRemittance: {}};
  const keys = Object.keys(remittance);
  keys.forEach((key) => {
    const keyArr = key.split('.');
    if (keyArr.length < 2) {
      return false;
    }
    if (keyArr[0] === 'sale') {
      transactionObject.saleTransaction[keyArr[1]] = remittance[key];
    } else if (keyArr[0] === 'remittance') {
      transactionObject.paymentProcessorRemittance[keyArr[1]] = remittance[key];
    } else if (keyArr[0] === 'ReconDate') {
      transactionObject.saleTransaction[keyArr[1]] = remittance[key];
    }
  });

  return transactionObject;
}

export function getTransactionObjects (remittances) {
  const transactionObjects = [];

  remittances && remittances.forEach((remittance, index) => {
    transactionObjects.push(getTransactionObject(remittance));
  });

  return transactionObjects;
}

export function prepareSaleTransaction (data) {
  const sale = {};
  const tranid = generateTransactionId();
  const amount = data.amount.toString().replace('$', '').replace(/,/g, '');
  let chgAmount = 0.0;
  const testMode = MIDDLEWARE.TEST_MODE;

  try {
    chgAmount = parseFloat(amount) * 100;
  } catch (e) { }

  const transaction = {
    'PaymentProcessingRequest': {
      'creditCard': {
        'firstName': data.firstName || '',
        'lastName': data.lastName || '',
        'pUser': data.username,
        'actionType': 'SALE',
        'address1': data.address ? data.address : '',
        'address2': 'None',
        'city': data.city ? data.city : '',
        'state': data.state ? data.state : '',
        'postalCode': data.postalCode ? data.postalCode : '',
        'country': data.country ? data.country : '',
        'cardNum': { '@Tokenize': false, '#text': data.card.replace(/ /g, '') },
        'chgAmt': chgAmount,
        'legalEntityApp': data.legalEntityApp,
        'accountId': data.accountNumber,
        'expiryDate': data.expirationDate,
        'testMode': testMode,
        'tranId': tranid,
        'merchantId': data.merchantId,
        'processor': '',
        'token': { '@tokenized': false, '#text': '' },
        'application': { '@version': '1.01', '#text': 'GatewayPortal' },
        'Account_Period': data.accountPeriod,
        'Desk': data.desk,
        'Invoice_Number': data.invoiceNumber,
        'cvv2Code': data.cvv ? data.cvv : '',
        'origin': data.origin
      }
    }
  };

  sale.transaction = transaction;

  let customerName = '';
  customerName += (data.firstName ? data.firstName : '');
  customerName += (customerName ? ' ' : '');
  customerName += (data.lastName ? data.lastName : '');

  sale.cachedTransaction = {
    'applicationTransactionId': tranid,
    'transactionType': 'SALE',
    'internalStatusCode': null,
    'customer': customerName,
    'legalEntity': data.legalEntityApp,
    'accountNumber': data.accountNumber,
    'amount': data.amount,
    'cardType': null,
    'cardNumberLast4Char': data.card,
    'processorName': null,
    'transactionDateTime': null
  };

  return sale;
}

export function sleep (ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function stringArrayToInt (array) {
  return array.map((str) => {
    try {
      let n = parseInt(str);
      return (isNaN(n)) ? -1 : n;
    } catch (e) {
      return -1;
    }
  }).filter((val) => {
    return val !== -1;
  });
}

export function intArrayToString (array) {
  return array.map((n) => {
    return n.toString();
  });
}

export function objectArrayToString (array) {
  return array.map((n) => {
    try {
      let s = (n.roleId || n.legalEntityAppId).toString();
      return s;
    } catch (e) {
      return -1;
    }
  }).filter((val) => {
    return val !== -1;
  });
}

export function saveFile (fileName, fileContents) {
  const myBlob = new Blob([fileContents]);

  if (navigator.msSaveOrOpenBlob) {
    // Good old IE
    navigator.msSaveOrOpenBlob(myBlob, fileName);
  } else {
    // Chrome and others
    const createNewFile = (fs) => {
      fs.root.getFile(fileName, {create: true}, (fileEntry) => {
        fileEntry.createWriter((fileWriter) => {
          fileWriter.addEventListener('writeend', () => {
            const fileUrl = fileEntry.toURL();
            const link = document.createElement('a');
            link.href = fileUrl;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }, false);
          fileWriter.write(myBlob);
        }, () => {});
      }, () => {});
    };
    const rfs = window.requestFileSystem || window.webkitRequestFileSystem;
    rfs && rfs(window.TEMPORARY, 1024 * 1024 * 15, (fs) => {
      fs.root.getFile(fileName, {create: false}, (fileEntry) => {
        fileEntry.remove(() => {
          createNewFile(fs);
        }, () => { createNewFile(fs); });
      }, () => { createNewFile(fs); });
    }, () => {});
  }
}

export function isObject (item) {
  return (item && typeof item === 'object' && !Array.isArray(item) && item !== null);
}

export function mergeDeep (target, source) {
  let output = Object.assign({}, target);
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) {
          Object.assign(output, { [key]: source[key] });
        } else {
          output[key] = mergeDeep(target[key], source[key]);
        }
      } else {
        Object.assign(output, { [key]: source[key] });
      }
    });
  }
  return output;
}

// function getKeyPermissions (permissionList) {
//   // look for specific permissions that drive UI
//   let retObj = {};
//   for (let i in permissionList) {
//     let permission = permissionList[i];
//     if (permission.permissionId === 7) {
//       retObj.responseCodes = true;
//       break;
//     }
//   };
//   return retObj;
// }

// function getKeyLegalEntities (legalEntities) {
//   // look for specific permissions that drive UI
//   let retObj = {};
//   for (let i in legalEntities) {
//     let entity = legalEntities[i];
//     if (entity.legalEntityAppId === 7) {
//       retObj.latitude = true;
//       break;
//     }
//   };
//   return retObj;
// }

// export function getAccessObject (userRoles, permissionList) {
//   let accessRoles = {};
//   if (permissions.responseCodes) {
//     accessRoles.responseCodes = true;
//   }
//   userRoles.sort((a, b) => {
//     if (a.roleId < b.roleId) {
//       return -1;
//     }
//     if (a.roleId > b.roleId) {
//       return 1;
//     }
//     return 0;
//   });
//   for (let i in userRoles) {
//     let role = userRoles[i];

//     if (role.roleName === 'ROLE_ACCOUNT_MANAGER' ||
//       role.roleName === 'ROLE_GROUP_MANAGER' ||
//       role.roleName === 'ROLE_DIVISION_MANAGER' ||
//       role.roleName === 'ROLE_ACCOUNTING_MANAGER_CLERKS')
//     {
//       // account manager, accounting manager clerk, group manager or division manager
//       accessRoles.void = true;
//       accessRoles.refund = true;
//       accessRoles.reports = true;
//       accessRoles.admin = false;
//     }
//     if (role.roleName === 'ROLE_BUSINESS_OVERSIGHT' ||
//       role.roleName === 'ROLE_ADMIN') {
//       // admin or business oversight
//       accessRoles.void = true;
//       accessRoles.refund = true;
//       accessRoles.reports = true;
//       accessRoles.remittance = true;
//       accessRoles.admin = true;
//       accessRoles.batchProcessing = true;
//     }
//     if (role.roleName === 'ROLE_ANALYST' ||
//         role.roleName === 'ROLE_REMITTANCE')
//     {
//       // analyst, remittance
//       accessRoles.reports = true;
//     }
//     if (role.roleName === 'ROLE_BATCH_PROCESSING') {
//       // Batch Processing
//       accessRoles.batchProcessing = true;
//     }
//     if (role.roleId === 7) {
//       // sales
//       accessRoles.sales = true;
//     }
//   };
//   return accessRoles;
// }

const permissionsMapping = {
  sale: 'SALE',
  currentUser: 'MANAGE_CURRENT_USER',
  users: 'MANAGE_ALL_USERS',
  void: 'VOID',
  refund: 'REFUND',
  admin: 'ADMINISTRATIVE',
  responseCodes: 'MANAGE_RESPONSE_CODES',
  remittance: 'SEARCH_RECONCILIATION',
  batchReporting: 'BATCH_REPORTING',
  batchProcessing: 'BATCH_UPLOAD',
  reports: 'SEARCH_REPORTING'
};

function getPermissionNames (permissionList = []) {
  return permissionList.map(({ permissionName }) => permissionName);
}

export function getAccessObject (userRoles, permissionList = []) {
  let accessRoles = {};
  const permissionNames = getPermissionNames(permissionList);

  let permissionKeys = Object.keys(permissionsMapping);
  permissionKeys.forEach((key) => {
    if (permissionNames.includes(permissionsMapping[key])) {
      accessRoles[key] = true;
    }
  });

  return accessRoles;
}

const routeAccessMapping = {
  '/users': ['admin', 'users'],
  '/legal-entities': ['admin'],
  '/processors': ['admin'],
  '/rules': ['admin'],
  '/processor-merchants': ['admin'],
  '/search': ['reports', 'remittance'],
  '/sales': ['sale'],
  '/refund': ['refund'],
  '/void': ['void'],
  '/response-codes': ['responseCodes'],
  '/status-codes': ['responseCodes'],
  '/batch-transactions': ['batchProcessing', 'batchReporting']
};

// Receives a path or array of paths, and an accessRoles object. Returns an array of allowed paths.
export function checkAllowedPath (path = '/', accessRoles) {
  let pathArr = [];
  if (typeof path === 'string') {
    pathArr.push(path);
  } else {
    pathArr = path;
  }
  const matchesArr = [];

  pathArr.forEach((eachPath) => {
    // get the first part of the path. So, "/foo/bar" becomes just "/foo"
    const pathName = '/' + eachPath.split('/')[1];
    const requiredPermissions = routeAccessMapping[pathName];
    if (pathName === '/' || requiredPermissions === undefined) {
      // Always allow access to '/' and to URLs that are not in the access mapping
      matchesArr.push(eachPath);
    } else {
      requiredPermissions.forEach(permission => {
        if (accessRoles[permission]) {
          matchesArr.push(eachPath);
        }
      });
    }
  });
  return matchesArr.length ? matchesArr : false;
}

UserException.prototype.toString = function () {
  return this.name + ': "' + this.message + '"';
};

export function UserException (message, details) {
  this.message = message;
  this.name = 'UserException';
  this.details = details || {};
}

// base options
const options = {
  'closeButton': true,
  'debug': false,
  'newestOnTop': false,
  'progressBar': false,
  'positionClass': 'toastr-wrapper toast-top-right',
  'preventDuplicates': false,
  'onclick': null,
  'showDuration': '300',
  'hideDuration': '300',
  'timeOut': '6000',
  'extendedTimeOut': '6000',
  'showMethod': 'fadeIn',
  'hideMethod': 'fadeOut'
};

export function handleErrorToastr (error) {
  toastr.options = options;
  toastr.error(error && error.message, 'Error');
}

export function handleSuccessToastr (message) {
  toastr.options = options;
  toastr.success(message, 'Success');
}

export function clearToastr () {
  toastr.clear();
}

// Initializes accordions inside all .accordion-container elements.
export function jqueryAccordions ({singleOpen = false} = {}) {
  const $ = window.$ || {};
  const $accordions = $('.accordion-container');

  if ($accordions.length) {
    $accordions.each((index, element) => {
      const $element = $(element);
      if (!$element.data('accordionInitialized')) {
        $($element.data('accordionInitialized', true));

        $element.on('click', '.section-toggle', (e) => {
          e.preventDefault();
          const $target = $(e.target);
          singleOpen && $element
            .find('.section-toggle')
            .not(e.target)
            .removeClass('expanded')
            .next()
            .slideUp('fast');
          $target
            .toggleClass('expanded')
            .next()
            .slideToggle('fast');
        });
      }
    });
  }
}
