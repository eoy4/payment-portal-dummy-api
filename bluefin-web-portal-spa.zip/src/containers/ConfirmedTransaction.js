import React from 'react';
import { connect } from 'react-redux';
import SingleTransaction from '../components/SingleTransaction/SingleTransaction';
import { cleanTransaction } from '../redux/modules/Transaction';

type Props = {
  params: Object,
  transaction: Object,
}
export class ConfirmedTransaction extends React.Component {
  props: Props;

  // componentDidMount () {
  //   const { store } = this.context;

  //   store.dispatch(getTransaction(this.props.params.id));
  // }

  componentWillUnmount () {
    const { store } = this.context;
    store.dispatch(cleanTransaction());
  }

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles}>
        <h1 className={'page-header' + ((this.props.transaction.statusCode === '1') ? '' : ' error-title')}
          id='transaction-result-h1'>
          {(this.props.transaction.statusCode === '1') ? 'Transaction Approved' : 'Transaction Denied'}
        </h1>
        <SingleTransaction transaction={this.props.transaction} />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    transaction: state.transaction.currentTransaction
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

ConfirmedTransaction.contextTypes = {
  store: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConfirmedTransaction);
