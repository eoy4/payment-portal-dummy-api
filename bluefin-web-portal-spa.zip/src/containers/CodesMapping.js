import React from 'react';
import SelectProcessorsForm from '../forms/SelectProcessorsForm';
import { getProcessors } from '../redux/modules/Processor';
import { getTransactionTypes } from '../redux/modules/TransactionType';
import { handleErrorToastr, handleSuccessToastr, clearToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  params: Object,
  paymentProcessors: Array,
  transactionTypes: Array,
  selectProcessorsForm: Object
}

export class CodesMapping extends React.Component {
  props: Props;

  codeTitle = 'Code';
  baseURL = '/codes'

  constructor (props) {
    super(props);

    this.state = {dirtyRows: [], selectedTransactionType: false};

    // bind 'this' to all callback methods
    this.handleTransactionTypeChange = this.handleTransactionTypeChange.bind(this);
    this.notifyChanges = this.notifyChanges.bind(this);
    this.getInputHandler = this.getInputHandler.bind(this);
    this.getSaveHandler = this.getSaveHandler.bind(this);
    this.getDeleteHandler = this.getDeleteHandler.bind(this);
    this.getDataRetriever = this.getDataRetriever.bind(this);
    this.confirmDiscardChanges = this.confirmDiscardChanges.bind(this);
  }

  componentDidMount () {
    return this.reloadData();
  }

  reloadData (mode = 'full', successMessage = false) {
    const { store } = this.context;
    const getCodesAction = this.getGetCodesAction();
    let selectedTransactionType = this.state.selectedTransactionType || false;

    if (!selectedTransactionType) { mode = 'full'; }

    store.dispatch(blockUI());

    switch (mode) {
      case 'full':
        store.dispatch(getTransactionTypes())
        .then((payload) => {
          if (payload.error) {
            handleErrorToastr(payload.error);
            store.dispatch(unblockUI());
          } else {
            if (payload.payload[0]) { selectedTransactionType = payload.payload[0].transactionTypeName; }
            Promise.all([
              store.dispatch(getProcessors()),
              store.dispatch(getCodesAction(selectedTransactionType, true))
            ])
            .then((payload) => {
              if (payload.error) {
                handleErrorToastr(payload.error);
                store.dispatch(unblockUI());
              }
              this.setState({
                processorsMap: this.getProcessorsMap(),
                selectedTransactionType,
                dirtyRows: []
              }, () => { store.dispatch(unblockUI()); });
            });
          }
        });
        break;
      case 'codes':
        store.dispatch(getCodesAction(selectedTransactionType, true))
        .then((payload) => {
          if (payload.error) {
            handleErrorToastr(payload.error);
          };
          this.setState({dirtyRows: []}, () => {
            store.dispatch(unblockUI());
          });
        });
        break;
      case 'clear':
        const clearAction = this.getClearCodesAction();

        store.dispatch(clearAction());
        this.setState({reloading: true, dirtyRows: []}, () => {
          this.setState({reloading: false}, () => {
            store.dispatch(unblockUI());
          });
        });
        break;
    }
    if (successMessage) {
      handleSuccessToastr(successMessage);
    }
  }

  // These return the redux action creators for the specific api calls. Implemented in the child classes.
  getGetCodesAction () { return () => {}; }
  getInsertCodeAction () { return () => {}; }
  getUpdateCodeAction () { return () => {}; }
  getDeleteCodeAction () { return () => {}; }
  getModifyCodeAction () { return () => {}; }
  getClearCodesAction () { return () => {}; }

  // Arrange the Payment Processors array into a Map
  getProcessorsMap () {
    const { paymentProcessors } = this.props;

    let processorsMap = new Map();

    paymentProcessors &&
    paymentProcessors.forEach((processor) => {
      processorsMap.set(processor.paymentProcessorId, processor);
    });

    return processorsMap;
  }

  notifyChanges (codeId) {
    this.addDirtyRow(codeId);
  }

  handleTransactionTypeChange (event) {
    event.preventDefault();

    const transactionTypeName = event.target.value;

    this.setState({selectedTransactionType: transactionTypeName},
      () => {
        this.reloadData('codes');
      }
    );
  }

  addDirtyRow (rowId) {
    let dirtyRows = Array.concat([], this.state.dirtyRows);
    if (!dirtyRows.includes(rowId)) {
      dirtyRows.push(rowId);
      this.setState({dirtyRows});
    }
  }

  removeDirtyRow (rowId) {
    let dirtyRows = Array.concat([], this.state.dirtyRows);
    const index = dirtyRows.indexOf(rowId);
    if (index > -1) {
      dirtyRows.splice(index, 1);
      this.setState({dirtyRows});
    }
  }

  validateData (data) {
    // To be implemented
    return true;
  }

  // Creates a new function that retrieves a specific code's data, to be used at save time. It's
  // implemented in the child classes.
  getDataRetriever (codeId) {
    return () => {};
  }

  // returns function that handles data input and dispatches action to the reducer.
  getInputHandler (codeId, processorCodeId, processorId, fieldName) {
    const modifyCodeAction = this.getModifyCodeAction();

    return (event) => {
      const { store } = this.context;
      const { selectedTransactionType } = this.state;

      store.dispatch(modifyCodeAction(codeId, processorCodeId,
        processorId, fieldName, event.target.value, selectedTransactionType));
      setTimeout(() => { this.forceUpdate(); }); // ugly but necessary because of reasons
    };
  }

  // calls getConfirmationHandler() and returns a callback function to handle save actions
  getSaveHandler (codeId, existingCodeId = false) {
    const { codeTitle } = this;
    const insertCodeAction = this.getInsertCodeAction();
    const updateCodeAction = this.getUpdateCodeAction();

    if (codeId) {
      return this.getConfirmationHandler(updateCodeAction,
        this.getDataRetriever(codeId), // returns function that gets the data for the specific row.
        `Are you sure you want to save changes for this ${codeTitle}?`,
        `Successfully updated the ${codeTitle}`,
        codeId);
    } else {
      return this.getConfirmationHandler(existingCodeId ? updateCodeAction : insertCodeAction,
        this.getDataRetriever(false, existingCodeId), // returns function that gets the data for the 'new code' row.
        `Do you want to create this new ${codeTitle}?`,
        `Successfully created the ${codeTitle}`,
        codeId);
    }
  }

  // calls getConfirmationHandler() and returns a callback function to handle delete actions
  getDeleteHandler (codeId) {
    const { codeTitle } = this;
    const deleteCodeAction = this.getDeleteCodeAction();

    return this.getConfirmationHandler(deleteCodeAction,
      this.getDataRetriever(codeId), // returns function that gets the data for the specific row.
      `Are you sure you want to delete this ${codeTitle}?`,
      `Successfully deleted the ${codeTitle}`,
      codeId);
  }

  // returns a callback function that displays a confirmation dialog and then handles the requested action
  getConfirmationHandler (actionCreator, dataRetriever, confirmationMessage, successMessage, rowId) {
    return (event) => {
      event.preventDefault();

      const { store } = this.context;

      store.dispatch(blockUI(false, confirmationMessage,
        () => {
          this.handleAction(actionCreator, dataRetriever, successMessage, rowId);
        },
        () => {
          store.dispatch(unblockUI());
        }));
    };
  }

  // dispatches the appropriate action to handle api calls
  handleAction (actionCreator, dataRetriever, successMessage, rowId) {
    const { store } = this.context;

    clearToastr();
    store.dispatch(blockUI());

    store.dispatch(actionCreator(dataRetriever()))
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
        store.dispatch(unblockUI());
      } else {
        this.removeDirtyRow(rowId);
        handleSuccessToastr(successMessage);
        this.reloadData('codes');
      }
    });
  }

  confirmDiscardChanges (event) {
    event.preventDefault && event.preventDefault();

    const {store} = this.context;

    store.dispatch(blockUI(false, 'Are you sure you want to discard your changes?',
      () => {
        this.reloadData('clear', 'Changes were discarded.');
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  renderRows () {
    // implemented in child classes
    return null;
  }

  renderRowEmpty () {
    // implemented in child classes
    return null;
  }

  // Gets the selected processor IDs from the Redux state
  getProcessorIds () {
    const { selectProcessorsForm } = this.props;

    let processorIds = [];

    if (
      selectProcessorsForm &&
      selectProcessorsForm.selectedProcessors &&
      selectProcessorsForm.selectedProcessors.value
    ) {
      selectProcessorsForm.selectedProcessors.value.forEach((selectedProcessor, index) => {
        if (selectedProcessor.value) {
          processorIds.push(selectedProcessor.value);
        } else {
          processorIds.push(selectedProcessor);
        }
      });
    }

    return processorIds;
  }

  render () {
    const {
      codeTitle,
      props: {
        paymentProcessors,
        transactionTypes,
        params: {
          paymentProcessorId
        }
      },
      state: {
        processorsMap,
        dirtyRows,
        selectedTransactionType,
        reloading
      }
    } = this;

    let initialSelectedProcessors = {selectedProcessors: []};

    paymentProcessorId && initialSelectedProcessors.selectedProcessors.push(parseInt(paymentProcessorId));

    /* if (paymentProcessors && paymentProcessors.length) {
      for (let i = 0; (i < 2 && i < paymentProcessors.length); i++) {
        initialSelectedProcessors.selectedProcessors.push(
          paymentProcessors[i] &&
          paymentProcessors[i].paymentProcessorId
        );
      }
    }*/

    const selectProcessorsForm = <SelectProcessorsForm
      paymentProcessors={paymentProcessors}
      initialValues={initialSelectedProcessors}
    />;

    let processorIds = this.getProcessorIds();

    const typeSelect = (
      <select
        className='form-control'
        onChange={this.handleTransactionTypeChange}
        defaultValue={selectedTransactionType}
        id='transaction-type-select'
      >
        {
          transactionTypes &&
          transactionTypes.map((transactionType, index) => {
            return (
              <option key={index} value={transactionType.transactionTypeName}>
                {transactionType.transactionTypeName}
              </option>
            );
          })
        }

      </select>
    );

    const headings = processorsMap
    ? (
      <thead>
        <tr>
          <th colSpan='2' className='text-center'>
            BLUEFIN
          </th>
          {
            processorIds.map((processorId, index) => {
              return (
                <th key={'processor-heading-' + index} colSpan='2' className='processor-code-heading text-center'>
                  {processorsMap.get(processorId) && processorsMap.get(processorId).processorName}
                </th>
              );
            })
          }
          <th className='text-center' rowSpan='2' colSpan='2'>Actions</th>
        </tr>
        <tr>
          <th className='text-center'>BLUEFIN<br />Code</th>
          <th className='text-center'>Description</th>
          {
            processorIds.map((processorId, index) => {
              return ([
                <th key={'code-' + index} className='processor-code-heading text-center'>
                  {processorsMap.get(processorId) && processorsMap.get(processorId).processorName}
                  <br />
                  Code
                </th>,
                <th key={'desc-' + index} className='processor-code-heading text-center'>
                  Description
                </th>
              ]);
            })
          }
        </tr>
      </thead>
    )
    : null;

    return (
      <div className={`${codeTitle}s-wrapper tab-content`}>
        <div className='tab-pane active'>
          <h2 className='sub-header'>
            <i className='glyphicon glyphicon-filter'></i> Available Filters
          </h2>
          <div className='row'>
            <div className='col-xs-12'>
              <div className='col-md-5 col-sm-12'>
                <label className='control-label'>Transaction Type</label>
                <div className='form-group'>
                  {typeSelect}
                </div>
              </div>
              <div className='col-md-7 col-sm-12'>
                <label className='control-label'>Payment Processors</label>
                {selectProcessorsForm}
              </div>
            </div>
          </div>
          <hr />
          {
            !reloading
            ? (
              <div>
                <h2 className='sub-header'>
                  <i className='fa fa-table'></i> {selectedTransactionType} Transaction {codeTitle}s
                </h2>

                <div className='table-responsive'>
                  <table className='table table-bordered editable-table'>
                    {headings}
                    {this.renderRows()}
                  </table>
                </div>

                <hr />

                <a name={`add-${codeTitle}`}></a>
                <h2 className='sub-header'>
                  <i className='glyphicon glyphicon-plus-sign'></i> Create a new {codeTitle}
                </h2>

                <div className='table-responsive'>
                  <table className='table table-bordered editable-table'>
                    {headings}
                    {this.renderRowEmpty()}
                  </table>
                </div>
                {
                  dirtyRows.length
                    ? <div className='unsaved-changes-notice'>
                      <p className='unsaved-changes-text'>
                        You have unsaved changes. Click  Save in each {codeTitle} row that you modified.
                      </p>
                      <div className='text-center'>
                        <button className='btn btn-default discard-changes'
                          onClick={this.confirmDiscardChanges}
                        >
                          <i className='glyphicon glyphicon-remove-sign'></i>
                          &nbsp;
                          Discard Changes
                        </button>
                      </div>
                    </div>
                    : null
                }
              </div>
            )
            : null
          }
        </div>
      </div>
    );
  }
}

CodesMapping.contextTypes = {
  store: React.PropTypes.object
};
