import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router';
import { loginUser } from '../redux/modules/Authentication';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import { handleErrorToastr } from '../utils/utils';
import LoginForm from '../forms/LoginForm';
import { actions as idleActions } from '../components/ReduxIdleMonitor';

type Props = {
  isAuthenticated: boolean
}
export class Login extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.handleLogin = this.handleLogin.bind(this);
  }

  componentDidMount () {
    const { router } = this.context;
    if (this.props.isAuthenticated) {
      router.push('/sales');
    }
  }

  handleLogin (data) {
    const { store, router } = this.context;
    const creds = {};

    if (!data.username || !data.password) {
      return;
    }

    store.dispatch(blockUI());

    creds['username'] = data.username;
    creds['password'] = data.password;

    store.dispatch(loginUser(creds))
    .then(() => {
      store.dispatch(unblockUI());
      store.dispatch(idleActions.start());
      router.push('/sales');
    })
    .catch(err => {
      store.dispatch(unblockUI());
      if (err.details && err.details.status === 403) {
        handleErrorToastr({
          message:
            data.username + ' is not an active account. ' +
            err.details.message
        });
      } else {
        handleErrorToastr(err);
      }
    });
  }

  render () {
    return (
      <div>
        <div className='content-header'>
          <h1>Bluefin Portal</h1>
        </div>
        <div className='col-sm-6 col-sm-offset-3'>
          <div className='tab-content'>
            <div className='tab-pane active'>
              <h2 className='sub-header'><i className='glyphicon glyphicon-lock'></i> Login</h2>
              <LoginForm onSubmit={this.handleLogin} />
              <Link to={'/login/recover'} className='forgot-password'>
                Forgot the password?
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  const { isAuthenticated } = state.auth;
  return {
    isAuthenticated
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

Login.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Login);
