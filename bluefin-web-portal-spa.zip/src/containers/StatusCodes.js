import React from 'react';
import { connect } from 'react-redux';
import { StatusCodeRow } from '../components/StatusCodeRow/StatusCodeRow';
import {
  getStatusCodes,
  insertStatusCode,
  updateStatusCode,
  deleteStatusCode,
  modifyStatusCode,
  clearStatusCodes
} from '../redux/modules/StatusCodes';
import { mergeDeep } from '../utils/utils';
import { CodesMapping } from './CodesMapping';

type Props = {
  params: Object,
  statusCodesRows: Object,
  paymentProcessors: Array,
  transactionTypes: Array,
  selectProcessorsForm: Object
}

export class StatusCodes extends CodesMapping {
  props: Props;

  codeTitle = 'Status Code';
  baseURL = '/status-codes';

  getGetCodesAction () { return getStatusCodes; }
  getInsertCodeAction () { return insertStatusCode; }
  getUpdateCodeAction () { return updateStatusCode; }
  getDeleteCodeAction () { return deleteStatusCode; }
  getModifyCodeAction () { return modifyStatusCode; }
  getClearCodesAction () { return clearStatusCodes; }

  validateData (data) {
    // ToDo
    return true;
  }

  // Creates a new function that retrieves a specific code's data, to be used at save time.
  getDataRetriever (codeId, existingCodeId = false) {
    return () => {
      const { statusCodesRows } = this.props;
      const row = statusCodesRows && statusCodesRows[codeId];
      if (!row) {
        return {};
      }

      let statusCode = {};
      statusCode.code = row.internalStatusCode;
      statusCode.description = row.internalStatusCodeDescription;
      statusCode.internalCodeId = codeId;
      statusCode.transactionTypeName = row.transactionTypeName;
      statusCode.paymentProcessorCodes = [];

      if (existingCodeId) {
        const existingCodeRow = statusCodesRows && statusCodesRows[existingCodeId];
        if (row.processorStatusCodes) {
          row.processorStatusCodes = mergeDeep(row.processorStatusCodes, existingCodeRow.processorStatusCodes);
        }
        statusCode.internalCodeId = existingCodeId;
        statusCode.code = existingCodeRow.internalStatusCode;
        statusCode.description = existingCodeRow.internalStatusCodeDescription;
      }
      row.processorStatusCodes &&
      Object.keys(row.processorStatusCodes).forEach((key) => {
        const processorCodes = row.processorStatusCodes[key];
        processorCodes && Object.keys(processorCodes).forEach((key) => {
          const processorCode = processorCodes[key];
          let newProcessorCode = {};
          newProcessorCode.code =
            processorCode.paymentProcessorStatusCode.paymentProcessorStatusCode;
          newProcessorCode.description =
            processorCode.paymentProcessorStatusCode.paymentProcessorStatusCodeDescription;
          newProcessorCode.paymentProcessorCodeId =
            processorCode.paymentProcessorStatusCode.paymentProcessorStatusCodeId;
          newProcessorCode.paymentProcessorId =
            processorCode.paymentProcessorStatusCode.processorId;
          statusCode.paymentProcessorCodes.push(newProcessorCode);
        });
      });
      return statusCode;
    };
  }

  renderRows (empty = false) {
    const {
      props: {
        statusCodesRows
      },
      state: { dirtyRows }
    } = this;

    const processorIds = this.getProcessorIds();

    if (!statusCodesRows) {
      return null;
    }

    if (empty) {
      let existingCodeInfo = {};
      if (statusCodesRows[false] && statusCodesRows[false].internalStatusCode) {
        let matchingCode = null;
        Object.keys(statusCodesRows).forEach((key) => {
          if (!key || key === 'false') {
            return false;
          }
          const statusCodesRow = statusCodesRows[key];
          if (statusCodesRow.internalStatusCode === statusCodesRows[false].internalStatusCode) {
            matchingCode = statusCodesRow;
            matchingCode.internalStatusCodeId = key;
          }
        });
        if (matchingCode) {
          existingCodeInfo = {
            internalStatusCodeId: matchingCode.internalStatusCodeId,
            internalStatusCode: matchingCode.internalStatusCode,
            internalStatusCodeDescription: matchingCode.internalStatusCodeDescription
          };
        }
      }
      return (
        <StatusCodeRow
          codeId={false}
          codes={statusCodesRows[false]}
          existingCodeInfo={existingCodeInfo}
          paymentProcessorIds={processorIds}
          getInputHandler={this.getInputHandler}
          getSaveHandler={this.getSaveHandler}
          notifyChanges={this.notifyChanges}
          dirty={dirtyRows.includes(false)}
        />
      );
    } else {
      var rowsArray = [];
      Object.keys(statusCodesRows).forEach((key) => {
        key && (key !== 'false') && rowsArray.push(
          <StatusCodeRow key={'row-' + key}
            codeId={key}
            codes={statusCodesRows[key]}
            paymentProcessorIds={processorIds}
            getInputHandler={this.getInputHandler}
            getSaveHandler={this.getSaveHandler}
            getDeleteHandler={this.getDeleteHandler}
            notifyChanges={this.notifyChanges}
            dirty={dirtyRows.includes(key)}
          />
        );
      });

      return rowsArray;
    }
  }

  renderRowEmpty () {
    return this.renderRows(true);
  }
}

const mapStateToProps = (state) => {
  return {
    paymentProcessors: state.processor.paymentProcessors,
    transactionTypes: state.transactionType.transactionTypes,
    selectProcessorsForm: state.form.SelectProcessorsForm,
    statusCodesRows: state.statusCodes.statusCodesRows
  };
};

StatusCodes.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(StatusCodes);
