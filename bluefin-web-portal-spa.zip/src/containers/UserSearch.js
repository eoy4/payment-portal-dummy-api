
import React from 'react';
import { connect } from 'react-redux';
import UserSearchForm from '../forms/UserSearchForm';
import MultipleUsers from '../components/MultipleUsers/MultipleUsers';
import Pagination from '../components/Pagination/Pagination';
import {
  getUsers,
  cleanUsers,
  storeFilter,
  selectUser,
  clearSelectedUsers,
  updateUserActivation
} from '../redux/modules/User';
import {
  createUserFilter,
  getDataFromFilter,
  handleErrorToastr,
  handleSuccessToastr,
  pageSize
} from '../utils/utils';
import { getRoles, getEntities, blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  location: Object,
  currentUserFilter: string,
  filteredUsers: Array,
  currentPage: number,
  selectedUsers: Array,
  availableLegalEntities: Array,
  availableRoles: Array
}

/**
 * Container that renders the User Search screen and handles actions for search,
 * activate, and deactivate.
 *
 * @export
 * @class UserSearch
 * @extends {React.Component}
 */
export class UserSearch extends React.Component {
  props: Props;
  context: Context;

  constructor () {
    super();

    this.handleNewPage = this.handleNewPage.bind(this);
    this.handlePageSizeChange = this.handlePageSizeChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleNewUser = this.handleNewUser.bind(this);
    this.handleSelectUser = this.handleSelectUser.bind(this);
    this.handleClearSelectedUsers = this.handleClearSelectedUsers.bind(this);
    this.handleAction = this.handleAction.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;

    store.dispatch(blockUI());

    Promise.all([
      store.dispatch(getEntities()),
      store.dispatch(getRoles())
    ])
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      store.dispatch(unblockUI());
      this.reloadResults();
    });
  }

  /**
   * Reloads the User search results based on the URL
   *
   * @memberOf UserSearch
   */
  reloadResults () {
    const { query } = this.props.location;
    const { store } = this.context;

    store.dispatch(clearSelectedUsers());

    const params = {};
    let newState = {};

    if (query.filter) {
      params.filter = decodeURIComponent(query.filter);
      store.dispatch(storeFilter(params.filter));
      const filterObject = getDataFromFilter(params.filter);
      Object.assign(newState, {filterObject});
    }
    params.page = 0;
    if (query.page) {
      params.page = parseInt(query.page);
    }
    Object.assign(newState, {page: params.page});
    if (query.size) {
      pageSize('users', query.size);
    }

    this.setState(newState, () => {
      this.dispatchSearchAction(params);
    });
  }

  /**
   * Handles the search form submission
   *
   * @param {object} data
   *
   * @memberOf UserSearch
   */
  handleSubmit (data) {
    const filter = createUserFilter(data);

    this.handleNewFilter(filter, 0);
  }

  /**
   * Sets the state to a new page and calls handleNewFilter
   *
   * @param {any} page
   *
   * @memberOf UserSearch
   */
  handleNewPage (page) {
    const filter = this.props.currentUserFilter;
    this.setState({page}, () => {
      this.handleNewFilter(filter, page);
    });
  }

  /**
   * Sets the page size to a given value, calls handleNewFilter with
   * a page number 0
   *
   * @param {number} size
   *
   * @memberOf UserSearch
   */
  handlePageSizeChange (size) {
    pageSize('users', size);
    const filter = this.props.currentUserFilter;

    this.handleNewFilter(filter, 0);
  }

  /**
   * Calls dispatchSearchAction with a new filter object and an optional
   * page number.
   *
   * @param {any} filter
   * @param {any} [page=this.state.page]
   *
   * @memberOf UserSearch
   */
  handleNewFilter (filter, page = this.state.page) {
    const { router, store } = this.context;
    store.dispatch(storeFilter(filter));
    const filterObject = getDataFromFilter(filter);
    this.setState({filterObject}, () => {
      router.replace({
        pathname: '/users',
        query: { filter, page, size: pageSize('users') }
      });
      this.dispatchSearchAction({filter, page});
    });
  }

  /**
   * Dispatches a new search action and handles the response.
   *
   * @param {any} [{filter, page = 0}={}]
   *
   * @memberOf UserSearch
   */
  dispatchSearchAction ({filter, page = 0} = {}) {
    const { store } = this.context;
    this.setState({loading: true});
    store.dispatch(cleanUsers());
    store.dispatch(getUsers({filter, page, size: pageSize('users')}))
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      this.setState({loading: false});
    });
  }

  /**
   * onClick handler, redirects to /user/create
   *
   * @memberOf UserSearch
   */
  handleNewUser () {
    const { router } = this.context;
    router.replace({
      pathname: '/users/create'
    });
  }

  /**
   * Receives a user object and dispatches an action to add it to the selected users.
   *
   * @param {object} user
   *
   * @memberOf UserSearch
   */
  handleSelectUser (user) {
    const { store } = this.context;

    store.dispatch(selectUser(user));
  }

  /**
   * Dispatches an action to clear the selected users list.
   *
   * @memberOf UserSearch
   */
  handleClearSelectedUsers () {
    const { store } = this.context;

    store.dispatch(clearSelectedUsers());
  }

  /**
   * Handles user activation actions. Blocks UI and dispatches the actions that make the
   * API calls, and handles the response.
   *
   * @param {boolean} activate
   * @param {Array} usernames
   *
   * @memberOf UserSearch
   */
  userActivation (activate, usernames) {
    const { store } = this.context;

    store.dispatch(blockUI());

    store.dispatch(updateUserActivation(activate, usernames))
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      } else {
        handleSuccessToastr('Users updated successfully.');
        this.reloadResults();
      }
      store.dispatch(unblockUI());
    });
  }

  /**
   * Handles any action applied to a usernames array.
   *
   * @param {string} action
   * @param {Array} [usernames=[]]
   *
   * @memberOf UserSearch
   */
  handleAction (action, usernames = []) {
    const { store } = this.context;
    const usersString = usernames.reduce((a, b) => (a + (a ? ', ' : '') + b), '');
    const prompt = `Do you want to ${action} ` +
      (usernames.length === 1 ? (`the user "${usersString}"?`)
        : `the following ${usernames.length} users? ${usersString}`);
    switch (action) {
      case 'activate':
        return store.dispatch(blockUI(false, prompt, () => {
          this.userActivation(true, usernames);
        },
        () => {
          store.dispatch(unblockUI());
        }));
      case 'deactivate':
        return store.dispatch(blockUI(false, prompt, () => {
          this.userActivation(false, usernames);
        },
        () => {
          store.dispatch(unblockUI());
        }));
      default:
        break;
    }
  }

  render () {
    return (
      <div className='global-search other'>
        <div className='tab-content'>
          <div className='tab-pane active'>
            <h2 className='sub-header'><i className='glyphicon glyphicon-search'></i> Search for a User</h2>
            <UserSearchForm type={'advanced'} onSubmit={this.handleSubmit}
              initialValues={(this.state && this.state.filterObject) ? this.state.filterObject : {}}
              availableRoles={this.props.availableRoles}
              availableLegalEntities={this.props.availableLegalEntities}
            />
            <br />
            <div className='form-group'>
              <button className='btn btn-primary' onClick={this.handleNewUser} id='create-new-user-button'>
                <i className='glyphicon glyphicon-plus-sign'></i> Create a New User
              </button>
            </div>
            {
              this.props.filteredUsers.content && this.state && !this.state.loading &&
                <Pagination elements={this.props.filteredUsers}
                  onPagination={this.handleNewPage}
                  onPageSizeChange={this.handlePageSizeChange}
                  currentPage={this.state.page}
                  numbersOnly
                  maxPagesLinks={10}
                  elementName={'users'} />
            }
            {
              this.props.filteredUsers.content && this.state && !this.state.loading &&
                <MultipleUsers handleSelectUser={this.handleSelectUser} removeSelectedUser={this.removeSelectedUser}
                  handleClearSelectedUsers={this.handleClearSelectedUsers} handleAction={this.handleAction}
                  selectedUsers={this.props.selectedUsers} users={this.props.filteredUsers} />}
            {
              this.state && this.state.loading &&
                <img src='/img/loader.gif' className='loader' alt='Loader' />
            }
            {
              this.props.filteredUsers.content && this.state && !this.state.loading &&
                <Pagination elements={this.props.filteredUsers}
                  onPagination={this.handleNewPage}
                  onPageSizeChange={this.handlePageSizeChange}
                  currentPage={this.state.page}
                  maxPagesLinks={10}
                  elementName={'users'} />
            }
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    filteredUsers: state.user.filteredUsers,
    currentUserFilter: state.user.currentUserFilter,
    currentPage: state.user.currentPage,
    selectedUsers: state.user.selectedUsers,
    availableRoles: state.misc.roles,
    availableLegalEntities: state.misc.legalEntities
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

UserSearch.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserSearch);
