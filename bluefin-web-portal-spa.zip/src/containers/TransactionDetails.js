import React from 'react';
import { connect } from 'react-redux';
import { getTransaction } from '../redux/modules/Transaction';
import { blockUI, unblockUI, getReconciliationStatus, getTimeZone } from '../redux/modules/Misc';
import { handleErrorToastr } from '../utils/utils';
import numeral from 'numeral';
import { default as moment } from 'moment';

type Props = {
  currentTransaction: Object,
  reconciliationStatusMap: Object,
  params: Object,
  userTimeZone: string
}

class TransactionDetails extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.goBack = this.goBack.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    const { transactionId, transactionType } = this.props.params;

    store.dispatch(blockUI());

    Promise.all([
      store.dispatch(getTransaction(transactionId, transactionType)),
      store.dispatch(getReconciliationStatus()),
      store.dispatch(getTimeZone())
    ])
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      store.dispatch(unblockUI());
    });
  }

  goBack () {
    const { router } = this.context;

    router.goBack();
  }

  render () {
    const styles = {width: '30%'};
    const tz = (this.props.params.timeZone) ? this.props.params.timeZone
    : ((this.props.userTimeZone) ? this.props.userTimeZone : moment.tz.guess());

    const { currentTransaction } = this.props;
    let saleTransaction = currentTransaction.saleTransaction || currentTransaction;

    const title1 = currentTransaction.transactionType === 'SALE'
      ? null
      : <h2 className='sub-header'>
        <i className='glyphicon glyphicon-list'></i> {currentTransaction.transactionType} Transaction Info
      </h2>;

    const title2 = currentTransaction.transactionType === 'SALE'
      ? <h2 className='sub-header'><i className='glyphicon glyphicon-list'></i> Transaction Info</h2>
      : <h2 className='sub-header'><i className='glyphicon glyphicon-list'></i> Original Transaction Info</h2>;

    const isSale = (currentTransaction.transactionType === 'SALE');

    const voidOrRefundTable = isSale
      ? null
      : (<table className='table table-bordered editable-table'>
        <thead>
          <tr>
            <th colSpan='2'>Transaction Details</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={styles}>Bluefin Transaction ID</td>
            <td>{currentTransaction.applicationTransactionId}</td>
          </tr>
          <tr>
            <td style={styles}>Transaction Date (Local Time)</td>
            <td>{moment.utc(currentTransaction.transactionDateTime).tz(tz).format('MMMM Do YYYY, h:mm:ss a')}</td>
          </tr>
          <tr>
            <td style={styles}>Approval Code</td>
            <td>{currentTransaction.approvalCode}</td>
          </tr>
          <tr>
            <td style={styles}>Merchant ID</td>
            <td>{currentTransaction.merchantId}</td>
          </tr>
          <tr>
            <td style={styles}>Payment Processor</td>
            <td>{currentTransaction.processorName}</td>
          </tr>
          <tr>
            <td style={styles}>Processor Transaction ID</td>
            <td>{currentTransaction.processorTransactionId}</td>
          </tr>
          <tr>
            <td style={styles}>Processor Response Code</td>
            <td>{currentTransaction.processorResponseCode}</td>
          </tr>
          <tr>
            <td style={styles}>Processor Response Description</td>
            <td>{currentTransaction.processorResponseCodeDescription}</td>
          </tr>
          <tr>
            <td style={styles}>Bluefin Status</td>
            <td>{currentTransaction.internalStatusDescription}</td>
          </tr>
          <tr>
            <td style={styles}>Bluefin Response</td>
            <td>{currentTransaction.internalResponseDescription}</td>
          </tr>
          <tr>
            <td style={styles}>Reconciliation Status</td>
            <td>
              {
                this.props.reconciliationStatusMap &&
                this.props.reconciliationStatusMap.get(currentTransaction.reconciliationStatusID)
                ? this.props.reconciliationStatusMap
                  .get(currentTransaction.reconciliationStatusID).reconciliationStatus
                : null
              }
            </td>
          </tr>
          <tr>
            <td style={styles}>Reconciliation Date (Local time)</td>
            <td>{moment.utc(currentTransaction.reconciliationDate).tz(tz).format('MMMM Do YYYY, h:mm:ss a')}</td>
          </tr>
          <tr>
            <td style={styles}>Bluefin Response</td>
            <td>{currentTransaction.internalResponseDescription}</td>
          </tr>
          <tr>
            <td style={styles}>Account Period</td>
            <td>{currentTransaction.accountPeriod}</td>
          </tr>
          <tr>
            <td style={styles}>User</td>
            <td>{currentTransaction.processUser}</td>
          </tr>
          <tr>
            <td style={styles}>Desk</td>
            <td>{currentTransaction.desk}</td>
          </tr>
          <tr>
            <td style={styles}>Invoice Number</td>
            <td>{currentTransaction.invoiceNumber}</td>
          </tr>
          <tr>
            <td style={styles}>User Defined Field 1</td>
            <td>{currentTransaction.userDefinedField1}</td>
          </tr>
          <tr>
            <td style={styles}>User Defined Field 2</td>
            <td>{currentTransaction.userDefinedField2}</td>
          </tr>
          <tr>
            <td style={styles}>User Defined Field 3</td>
            <td>{currentTransaction.userDefinedField3}</td>
          </tr>
          <tr>
            <td style={styles}>{currentTransaction.transactionType} Transaction ID</td>
            <td>
              {
                currentTransaction.transactionType &&
                currentTransaction[currentTransaction.transactionType.toLowerCase() + 'TransactionId']
              }
            </td>
          </tr>
        </tbody>
      </table>
    );

    let divStyles = isSale
    ? {}
    : {paddingLeft: '15px', borderLeft: '4px solid #0069AA'};

    return saleTransaction.applicationTransactionId
      ? <div className='transaction-details tab-content'>
        <div className='tab-pane active'>
          <div className='form-group'>
            <button className='btn btn-default' onClick={this.goBack} id='go-back-top-button' >&larr; Go Back</button>
          </div>
          {title1}
          <div className='row'>
            <div className='col-xs-12'>
              {voidOrRefundTable}
            </div>
          </div>
          {title2}
          <div className='row'>
            <div className='col-xs-12'>
              <div style={divStyles}>
                <table className='table table-bordered editable-table'>
                  <thead>
                    <tr>
                      <th colSpan='2'>{(isSale ? '' : 'SALE ') + 'Transaction Details'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={styles}>Bluefin Transaction ID</td>
                      <td>{saleTransaction.applicationTransactionId}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Transaction Date (Local Time)</td>
                      <td>{moment(saleTransaction.transactionDateTime).tz(tz).format('MMMM Do YYYY, h:mm:ss a')}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Payment Frequency</td>
                      <td>{saleTransaction.paymentFrequency}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Batch Upload Id</td>
                      <td>{saleTransaction.batchUploadId}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Legal Entity</td>
                      <td>{saleTransaction.legalEntity}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Merchant ID</td>
                      <td>{saleTransaction.merchantId}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Account Number</td>
                      <td>{saleTransaction.accountNumber}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Payment Processor</td>
                      <td>{saleTransaction.processorName}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Processor Transaction ID</td>
                      <td>{saleTransaction.processorTransactionId}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Transaction Type</td>
                      <td>{saleTransaction.transactionType}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Bluefin Status</td>
                      <td>{saleTransaction.internalStatusDescription}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Bluefin Response</td>
                      <td>{saleTransaction.internalResponseDescription}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Reconciliation Status</td>
                      <td>
                        {
                          this.props.reconciliationStatusMap &&
                          this.props.reconciliationStatusMap.get(saleTransaction.reconciliationStatusId)
                          ? this.props.reconciliationStatusMap
                            .get(saleTransaction.reconciliationStatusId).reconciliationStatus
                          : null
                        }
                      </td>
                    </tr>
                    <tr>
                      <td style={styles}>Reconciliation Date (Local time)</td>
                      <td>
                        {
                          moment.utc(saleTransaction.reconciliationDate).tz(tz).format('MMMM Do YYYY, h:mm:ss a')
                        }
                      </td>
                    </tr>
                    <tr>
                      <td style={styles}>Account Period</td>
                      <td>{saleTransaction.accountPeriod}</td>
                    </tr>
                    <tr>
                      <td style={styles}>User</td>
                      <td>{saleTransaction.processUser}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Desk</td>
                      <td>{saleTransaction.desk}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Invoice Number</td>
                      <td>{saleTransaction.invoiceNumber}</td>
                    </tr>
                    <tr>
                      <td style={styles}>User Defined Field 1</td>
                      <td>{saleTransaction.userDefinedField1}</td>
                    </tr>
                    <tr>
                      <td style={styles}>User Defined Field 2</td>
                      <td>{saleTransaction.userDefinedField2}</td>
                    </tr>
                    <tr>
                      <td style={styles}>User Defined Field 3</td>
                      <td>{saleTransaction.userDefinedField3}</td>
                    </tr>
                  </tbody>
                </table>

                <table className='table table-bordered editable-table'>
                  <thead>
                    <tr>
                      <th colSpan='2'>Credit Card Information</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={styles}>Card Number</td>
                      <td>{saleTransaction.cardNumberLast4Char}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Expiration Date</td>
                      <td>{saleTransaction.expiryDate}</td>
                    </tr>
                    <tr>
                      <td style={styles}>CVV2</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td style={styles}>Amount</td>
                      <td>{numeral(saleTransaction.amount).format('$0,0.00')}</td>
                    </tr>
                  </tbody>
                </table>

                <table className='table table-bordered editable-table'>
                  <thead>
                    <tr>
                      <th colSpan='2'>Billing Address</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={styles}>First Name</td>
                      <td>{saleTransaction.firstName}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Last Name</td>
                      <td>{saleTransaction.lastName}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Email</td>
                      <td></td>
                    </tr>
                    <tr>
                      <td style={styles}>Street Address</td>
                      <td>
                        {
                          saleTransaction.address1 +
                          (
                            saleTransaction.address2
                            ? '. ' + saleTransaction.address2
                            : ''
                          )
                        }
                      </td>
                    </tr>
                    <tr>
                      <td style={styles}>City</td>
                      <td>{saleTransaction.city}</td>
                    </tr>
                    <tr>
                      <td style={styles}>State/Province</td>
                      <td>{saleTransaction.state}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Zip/Postal Code</td>
                      <td>{saleTransaction.postalCode}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Country</td>
                      <td>{saleTransaction.country}</td>
                    </tr>
                  </tbody>
                </table>

                <table className='table table-bordered editable-table'>
                  <thead>
                    <tr>
                      <th colSpan='2'>Other</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={styles}>Origin</td>
                      <td>{saleTransaction.origin}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Test Mode</td>
                      <td>{saleTransaction.testMode ? 'Yes' : 'No'}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Tokenized</td>
                      <td>{saleTransaction.tokenized ? 'Yes' : 'No'}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Approval Code</td>
                      <td>{saleTransaction.approvalCode}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Bluefin Status Code</td>
                      <td>{saleTransaction.internalStatusCode}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Bluefin Status Description</td>
                      <td>{saleTransaction.internalStatusDescription}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Processor Status Code</td>
                      <td>{saleTransaction.paymentProcessorStatusCode}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Processor Status Description</td>
                      <td>{saleTransaction.paymentProcessorStatusCodeDescription}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Bluefin Response Code</td>
                      <td>{saleTransaction.internalResponseCode}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Bluefin Response Description</td>
                      <td>{saleTransaction.internalResponseDescription}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Processor Response Code</td>
                      <td>{saleTransaction.processorResponseCode}</td>
                    </tr>
                    <tr>
                      <td style={styles}>Processor Response Description</td>
                      <td>{saleTransaction.processorResponseCodeDescription}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <br />
          <button className='btn btn-default' onClick={this.goBack} id='go-back-bottom-button' >&larr; Go Back</button>
        </div>
      </div>
      : null;
  }
}

const mapStateToProps = (state) => {
  return {
    reconciliationStatusMap: state.misc.reconciliationStatusMap,
    currentTransaction: state.transaction.currentTransaction,
    userTimeZone: state.misc.timeZone
  };
};

TransactionDetails.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
)(TransactionDetails);
