import React from 'react';
import { connect } from 'react-redux';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import { handleErrorToastr } from '../utils/utils';
import { getProcessors, getProcessorStatus } from '../redux/modules/Processor';
import { ConvertibleSelect } from '../components/ConvertibleSelect/ConvertibleSelect';
import { Link } from 'react-router';

type Props = {
  params: Object,
  paymentProcessors: Object,
  currentProcessorStatus: Object
}
export class ProcessorDetails extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = {
      paymentProcessorId: this.props.params.paymentProcessorId &&
        this.props.params.paymentProcessorId !== '0'
         ? this.props.params.paymentProcessorId
         : 0,
      reloading: false
    };

    this.handleProcessorChange = this.handleProcessorChange.bind(this);
  }

  componentDidMount () {
    this.reloadData();
  }

  reloadData (full = true) {
    const { store } = this.context;
    const { paymentProcessorId } = this.state;

    store.dispatch(blockUI());
    this.setState({reloading: true}, () => {
      const actions = [];
      paymentProcessorId && actions.push(getProcessorStatus(paymentProcessorId));
      if (full) {
        actions.push(getProcessors());
      }

      Promise.all(actions.map((action) => {
        return store.dispatch(action);
      }))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        }
        store.dispatch(unblockUI());
        this.setState({reloading: false});
      });
    });
  }

  handleProcessorChange (event) {
    const value = event.target.value !== '0' ? event.target.value : 0;
    if (value !== this.state.paymentProcessorId) {
      const { router } = this.context;

      router.replace({
        pathname: '/processors/' + value
      });

      this.setState({paymentProcessorId: value}, () => {
        this.reloadData(false);
      });
    }
  }

  render () {
    const {
      currentProcessorStatus,
      paymentProcessors
    } = this.props;

    const { paymentProcessorId, reloading } = this.state;

    let processorOptions = new Map();
    processorOptions.set(0, 'Choose one');

    paymentProcessors &&
    paymentProcessors.forEach((processor) => {
      processorOptions.set(processor.paymentProcessorId, processor.processorName);
    });

    const processorNameField = (
      <ConvertibleSelect id='paymentProcessorId'
        onChange={this.handleProcessorChange}
        value={paymentProcessorId}
        options={processorOptions}
        linkDisplay='inline-block'
        inputDisplay='inline-block'
      />
    );

    const statusKeys = Object.keys(currentProcessorStatus);
    const classOK = 'glyphicon glyphicon-ok-sign';
    const classX = 'glyphicon glyphicon-remove-sign';
    const iconOK = <i className={classOK}></i>;
    const iconX = <i className={classX}></i>;

    const taskLinks = {
      'hasMerchantsAssociated': '/processor-merchants/' + paymentProcessorId,
      'hasRulesAssociated': '/rules',
      'hasResponseCodesAssociated': '/response-codes/' + paymentProcessorId,
      'hasStatusCodesAssociated': '/status-codes/' + paymentProcessorId
    };

    const styles = {width: '90px'};

    return (<div>
      <br />
      {
        paymentProcessors.length
        ? <h2 className='sub-header'>
          <i className='fa fa-table'></i>
          &nbsp;
          Checklist for Payment Processor {processorNameField}
        </h2>
        : null
      }
      <div className='row'>
        <div className='col-lg-9 col-md-10 col-xs-12'>
          {
            paymentProcessorId &&
            statusKeys.length &&
            !reloading
            ? <table className='table table-bordered editable-table'>
              <thead>
                <tr>
                  <th className='text-center' style={styles}>#</th>
                  <th>Task</th>
                  <th className='text-center' style={styles}>Status</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                {
                  statusKeys.map((key, index) => {
                    const status = currentProcessorStatus[key];
                    return (
                      <tr key={key}>
                        <td className='text-center' style={styles}>{index + 1}</td>
                        <td>
                          {
                            taskLinks[key]
                            ? <Link to={taskLinks[key]}>
                              {status.task}&nbsp;<sup><i className='glyphicon glyphicon-link'></i></sup>
                            </Link>
                            : status.task
                          }
                        </td>
                        <td className='text-center' style={styles}>
                          {status.completed ? iconOK : iconX}
                        </td>
                        <td className='status-details'>
                          {
                            status.codeStatus &&
                            status.codeStatus.map((codeType, index) => {
                              return (
                                <span className='code-status' key={`code-type-${key}-${index}`}>
                                  <i className={codeType.completed ? classOK : classX}>
                                    <span>&nbsp;{codeType.transactionType}</span>
                                  </i>
                                </span>
                              );
                            })
                          }
                        </td>
                      </tr>
                    );
                  })
                }
              </tbody>
            </table>
            : null
          }
        </div>
      </div>
    </div>);
  }
}

const mapStateToProps = (state) => {
  return {
    currentProcessorStatus: state.processor.currentProcessorStatus,
    paymentProcessors: state.processor.paymentProcessors
  };
};

ProcessorDetails.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(ProcessorDetails);
