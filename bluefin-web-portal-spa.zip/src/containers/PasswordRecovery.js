import React from 'react';
import { connect } from 'react-redux';
import { requestNewPassword, changePassword, logoutUser } from '../redux/modules/Authentication';
import { handleErrorToastr, handleSuccessToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import ResetPasswordForm from '../forms/ResetPasswordForm';
import ForgotPasswordForm from '../forms/ForgotPasswordForm';

type Props = {
  type: string,
  location: Object,
  isAuthenticated: boolean,
}
export class PasswordRecovery extends React.Component {
  props: Props;
  token: string;

  constructor (props) {
    super(props);

    this.handleRequestPassword = this.handleRequestPassword.bind(this);
    this.handleUpdatePassword = this.handleUpdatePassword.bind(this);
  }

  componentDidMount () {
    const { router, store } = this.context;
    if (this.props.location && this.props.location.query.token) {
      const token = this.props.location.query.token;
      const user = this.props.location.query.user;
      this.setState({token, user});

      if (this.props.isAuthenticated) {
        store.dispatch(blockUI());

        store.dispatch(logoutUser())
        .then(() => {
          store.dispatch(unblockUI());
          router.push({
            pathname: '/login/reset',
            query: { token }
          });
        })
        .catch(err => {
          store.dispatch(unblockUI());
          router.push({
            pathname: '/login/reset',
            query: { token }
          });
          if (!err.details && !err.details.status === 401) {
            handleErrorToastr(err);
          }
        });
      }
    } else {
      router.push('/login/recover');
    }
  }

  handleRequestPassword (data) {
    const { store } = this.context;

    if (!data.username) {
      return;
    }

    store.dispatch(requestNewPassword(data.username))
    .then((payload) => {
      handleSuccessToastr('We\'ve sent an email with instructions to your registered address.');
    })
    .catch(err => {
      handleErrorToastr(err);
    });
  }

  handleUpdatePassword (data) {
    const { store, router } = this.context;

    if (!data.password || !data.confirmation) {
      return;
    }

    store.dispatch(changePassword(data, this.state.token))
    .then((payload) => {
      handleSuccessToastr('We\'ve successfully updated your password.');
      router.push('/login');
    })
    .catch(err => {
      handleErrorToastr(err);
      router.push('/login/recover');
    });
  }

  render () {
    const resetPassword = <div className='col-sm-6 col-sm-offset-3'>
      <div className='tab-content'>
        <div className='tab-pane active'>
          <h2 className='sub-header'><i className='glyphicon glyphicon-lock'></i> Password Recovery</h2>
          <ResetPasswordForm onSubmit={this.handleRequestPassword} />
        </div>
      </div>
    </div>;

    const requestResetPassword = <div className='col-sm-6 col-sm-offset-3'>
      <div className='tab-content'>
        <div className='tab-pane active'>
          <h2 className='sub-header'><i className='glyphicon glyphicon-lock'></i> New password</h2>
          <ForgotPasswordForm onSubmit={this.handleUpdatePassword} username={this.state && this.state.user} />
        </div>
      </div>
    </div>;

    return (
      <div>
        <div className='content-header'>
          <h1>Reset Password</h1>
        </div>
        {
          this.props.type === 'reset'
           ? resetPassword : requestResetPassword
        }
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  const { isAuthenticated } = state.auth;
  return {
    isAuthenticated
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

PasswordRecovery.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PasswordRecovery);
