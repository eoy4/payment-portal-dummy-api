import React from 'react';
import { connect } from 'react-redux';
import {
  getBatchFiles,
  uploadBatchFile,
  cleanUploadedFile,
  downloadReport,
  downloadTransactionsReport,
  cleanReport,
  cleanTransactionsReport
} from '../redux/modules/BatchFile';
import { blockUI, unblockUI, getTimeZone } from '../redux/modules/Misc';
import { handleErrorToastr, saveFile, pageSize } from '../utils/utils';
import { default as moment } from 'moment';
import { default as MultipleBatchFiles } from '../components/MultipleBatchFiles/MultipleBatchFiles';
import Pagination from '../components/Pagination/Pagination';
import Dropzone from 'react-dropzone';

type Props = {
  uploadedFile: Object,
  uploadedPercentage: Number,
  error: String,
  filteredBatchFiles: Array,
  location: Object,
  report: string,
  transactionsReport: string,
  timeZone: string
}

export class RecurringPayments extends React.Component {
  props: Props;

  constructor (props, defaultProps) {
    super(props, defaultProps);

    const { query } = this.props.location;
    const page = query.page ? query.page : 0;
    let size = query.size;
    if (size) {
      pageSize('batch files', size);
    } else {
      size = pageSize('batch files');
    }
    this.state = { page, size };

    this.interval = null;

    this.loadResults = this.loadResults.bind(this);
    this.onDrop = this.onDrop.bind(this);
    this.handleNewPage = this.handleNewPage.bind(this);
    this.handlePageSizeChange = this.handlePageSizeChange.bind(this);
    this.handleReport = this.handleReport.bind(this);
    this.handleTransactionsReport = this.handleTransactionsReport.bind(this);
    this.toggleAutoReload = this.toggleAutoReload.bind(this);
  }

  componentDidMount () {
    this.loadResults();
  }

  componentWillUnmount () {
    this.setAutoReload(false);
  }

  loadResults (timeout = 0) {
    const { store } = this.context;

    store.dispatch(blockUI());

    setTimeout(() => {
      Promise.all([
        store.dispatch(getTimeZone())
      ])
      .then((payload) => {
        this.silentLoad()
        .then((payload) => {
          store.dispatch(unblockUI());
        });
      });
    }, timeout);
  }

  silentLoad () {
    const { store } = this.context;
    const { page, size } = this.state;
    return store.dispatch(getBatchFiles({page, size}));
  }

  setAutoReload (autoReload) {
    if (autoReload) {
      this.interval =
      this.interval || setInterval(() => {
        this.silentLoad();
      }, 5000);
      this.silentLoad();
    } else {
      this.interval &&
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  toggleAutoReload (e) {
    this.setState({autoReload: e.target.checked}, () => {
      return this.setAutoReload(this.state.autoReload);
    });
  }

  onDrop (files = []) {
    const { store } = this.context;

    const promises = [];

    promises.push(store.dispatch(cleanUploadedFile()));

    files.forEach((file, index) => {
      this.setState({uploading: true});
      promises.push(store.dispatch(uploadBatchFile(file)));
    });

    Promise.all(promises)
    .then((response) => {
      this.loadResults(2000);
    });
  }

  handleNewPage (i) {
    const { router } = this.context;
    const { query } = this.props.location;
    // const newFilter = query.replace(/page=[\d]+/g, `page=${i}`);
    query.page = i;

    router.replace({
      pathname: '/batch-transactions',
      query
    });

    this.setState({page: parseInt(i)}, this.loadResults);
  }

  handlePageSizeChange (newSize) {
    const { router } = this.context;
    const { query } = this.props.location;
    // const newFilter = query.replace(/page=[\d]+/g, `page=${i}`);
    query.page = 0;
    query.size = newSize;
    pageSize('batch files', newSize);

    router.replace({
      pathname: '/batch-transactions',
      query
    });

    this.setState({page: 0, size: parseInt(newSize)}, this.loadResults);
  }

  handleReport (e) {
    e.preventDefault && e.preventDefault();

    const { store } = this.context;

    this.setState({processing: {report: true}});
    store.dispatch(downloadReport(7, this.props.timeZone))
    .then(() => {
      const fileName = `batch_files_${moment().format('YYYY-MM-DD')}.csv`;
      saveFile(fileName, this.props.report);

      this.setState({processing: {report: false}});

      store.dispatch(cleanReport());
    })
    .catch((err) => {
      this.setState({processing: {report: false}});
      handleErrorToastr(err);
    });
  }

  handleTransactionsReport (batchUploadId) {
    return (e) => {
      e.preventDefault && e.preventDefault();

      const { store } = this.context;

      this.setState({processing: {[batchUploadId]: true}});
      store.dispatch(downloadTransactionsReport(batchUploadId, this.props.timeZone))
      .then(() => {
        const fileName = `batch_return_file_${batchUploadId}_${moment().format('YYYY-MM-DD')}.txt`;
        saveFile(fileName, this.props.transactionsReport);

        this.setState({processing: {[batchUploadId]: false}});

        store.dispatch(cleanTransactionsReport());
      })
      .catch((err) => {
        this.setState({processing: {[batchUploadId]: false}});
        handleErrorToastr(err);
      });
    };
  }

  render () {
    return (
      <div className='batch-transactions batch-transactions-dashboard tab-content'>
        <div className='tab-pane active'>
          <h2 className='sub-header'><i className='fa fa-table'></i> List of Batch Files</h2>
          <div className='row'>
            <div className='col-xs-6 col-sm-6 col-md-3'>
              <div className='form-group'>
                <label className='control-label' style={{whiteSpace: 'nowrap'}}>
                  <input type="checkbox" onClick={this.toggleAutoReload} initialChecked={this.state.autoReload}
                    id='auto-refresh-input' />
                  &nbsp;
                  Auto-refresh
                </label>
              </div>
            </div>
            <div className='col-xs-6 col-sm-6 col-md-4 text-right'>
              <div className='form-group'>
                {
                  this.props.filteredBatchFiles &&
                  this.props.filteredBatchFiles.content &&
                  this.props.filteredBatchFiles.content.length > 0 &&
                    <button className='btn btn-primary'
                      disabled={this.state.processing && this.state.processing.report}
                      onClick={this.handleReport}
                      style={{marginRight: '15px'}}
                      id='download-csv-button'>
                        {(this.state.processing && this.state.processing.report)
                          ? 'Processing'
                          : <span>
                            <i className='glyphicon glyphicon-circle-arrow-down'></i>
                            &nbsp;
                            <span className='hidden-xs'>Download as CSV file</span>
                          </span>}
                    </button>
                }
              </div>
            </div>
            <div className='col-xs-12 col-sm-12 col-md-5'>
              <div className='form-group'>
                <Dropzone
                  className='form-control drop-zone'
                  activeClassName='active'
                  accept='text/plain,.csv'
                  multiple={false}
                  onDrop={this.onDrop}
                >
                  <label className='text-center hidden-xs hidden-sm'>
                    <i className='glyphicon glyphicon-circle-arrow-up'></i> Upload (click here or drop file)
                  </label>
                  <label className='text-center hidden visible-xs-block visible-sm-block'>
                    <i className='glyphicon glyphicon-circle-arrow-up'></i> Upload File
                  </label>
                </Dropzone>
                {
                  (this.state && this.state.uploading)
                  ? <div className='upload-status'>
                    <progress max='100' value={this.props.uploadedPercentage}></progress>
                    <div style={{display: (this.props.error ? 'none' : 'block')}}>
                      {
                        this.props.uploadedPercentage !== 100
                        ? <span>Uploading... {this.props.uploadedPercentage}%</span>
                        : <span className='complete'>Upload Done.</span>
                      }
                    </div>
                    {
                      this.props.error
                      ? <div className='error'>Error: {this.props.error}</div>
                      : null
                    }
                  </div>
                  : null
                }
              </div>
            </div>
          </div>
          <div className='row'>
            {
              this.props.filteredBatchFiles &&
                <Pagination elements={this.props.filteredBatchFiles}
                  onPagination={this.handleNewPage}
                  onPageSizeChange={this.handlePageSizeChange}
                  currentPage={parseInt(this.state.page)}
                  maxPagesLinks={10}
                  numbersOnly
                  elementName={'batch files'} />
            }
            <MultipleBatchFiles batchFiles={this.props.filteredBatchFiles}
              handleTransactionsReport={this.handleTransactionsReport}
              processing={this.state.processing}
              timeZone={this.props.timeZone} />
            {
              this.props.filteredBatchFiles &&
                <Pagination elements={this.props.filteredBatchFiles}
                  onPagination={this.handleNewPage}
                  onPageSizeChange={this.handlePageSizeChange}
                  currentPage={parseInt(this.state.page)}
                  maxPagesLinks={10}
                  elementName={'batch files'} />
            }
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    uploadedFile: state.batchFile.uploadedFile,
    uploadedPercentage: state.batchFile.uploadedPercentage,
    error: state.batchFile.error,
    filteredBatchFiles: state.batchFile.filteredBatchFiles,
    report: state.batchFile.report,
    transactionsReport: state.batchFile.transactionsReport,
    timeZone: state.misc.timeZone
  };
};

RecurringPayments.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(RecurringPayments);
