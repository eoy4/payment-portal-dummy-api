import React from 'react';
import { connect } from 'react-redux';
import { ProcessorRulesRow } from './ProcessorRulesRow';
import { handleErrorToastr, handleSuccessToastr, clearToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import { getProcessors } from '../redux/modules/Processor';
import { createProcessorRule, updateProcessorRule, deleteProcessorRule, getProcessorRules }
  from '../redux/modules/ProcessorRule';

type Props = {
  paymentProcessors: Array,
  processorRules: Array
}
export class ProcessorRules extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = {
      processorsMap: {},
      unsavedRules: []
    };

    this.confirmUpdate = this.confirmUpdate.bind(this);
    this.notifyChanges = this.notifyChanges.bind(this);
  }

  componentDidMount () {
    this.reloadData();
  }

  reloadData (mode = 'full') {
    clearToastr();
    const { store } = this.context;

    store.dispatch(blockUI());

    const thenFunc = (payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      };
      this.setState({unsavedRules: [], reloading: true}, () => {
        this.mapProcessorsToState();
        this.setState({reloading: false});
        store.dispatch(unblockUI());
      });
    };

    switch (mode) {
      case 'full':
        Promise.all([
          store.dispatch(getProcessorRules()),
          store.dispatch(getProcessors())
        ])
        .then(thenFunc);
        break;
      case 'rules':
        store.dispatch(getProcessorRules())
        .then(thenFunc);
        break;
      case 'state':
      default:
        this.setState({reloading: true}, () => {
          this.setState({reloading: false});
        });
        break;
    }
  }

  mapProcessorsToState () {
    const { paymentProcessors } = this.props;

    let processorsMap = new Map();
    paymentProcessors.forEach((processor, index) => {
      processorsMap.set(processor.paymentProcessorId, processor);
    });

    this.setState({processorsMap});
  }

  /**
  * Called from child components, sets a flag to show a warning of unsaved changes
  */
  notifyChanges (ruleID) {
    if (!ruleID) {
      return this.setState({unsavedRules: []});
    }
    const { unsavedRules } = this.state;
    if (!unsavedRules.includes(ruleID)) {
      const { unsavedRules } = this.state;
      this.setState({unsavedRules: [].concat(unsavedRules, ruleID)});
    }
  }

  confirmUpdate (data, mode = 'update') {
    clearToastr();
    const { store } = this.context;
    store.dispatch(blockUI(false, 'Do you want to save your changes?',
      () => {
        this.handleOnUpdate(data, mode);
      },
      () => {
        this.setState({reloading: true, unsavedRules: []}, () => {
          store.dispatch(unblockUI());
          this.setState({reloading: false});
        });
      }
    ));
  }

  /**
  * Called from child components, receives the data to update and a 'mode' flag.
  */
  handleOnUpdate (data, mode = 'update') {
    const { store } = this.context;

    store.dispatch(blockUI());

    const { paymentProcessorId } = data;

    switch (mode) {
      case 'create':
        if (!paymentProcessorId) {
          handleErrorToastr({message: 'Please select a Payment Processor.'});
          store.dispatch(unblockUI());
        } else {
          store.dispatch(createProcessorRule(data))
          .then((payload) => {
            if (payload.error) {
              this.reloadData('state');
              handleErrorToastr(payload.error);
              store.dispatch(unblockUI());
            } else {
              this.reloadData('rules');
              handleSuccessToastr('Successfully created a new Payment Processor Rule');
            }
          });
        }
        break;
      case 'update':
        const { paymentProcessorRuleId } = data;
        store.dispatch(updateProcessorRule(paymentProcessorRuleId, data))
        .then((payload) => {
          if (payload.error) {
            this.reloadData('state');
            handleErrorToastr(payload.error);
            store.dispatch(unblockUI());
          } else {
            this.reloadData('rules');
            handleSuccessToastr('Successfully updated Payment Processor Rules.');
          }
        });
        break;
      case 'delete':
        store.dispatch(deleteProcessorRule(data.paymentProcessorRuleId))
        .then((payload) => {
          if (payload.error) {
            this.reloadData('state');
            handleErrorToastr(payload.error);
            store.dispatch(unblockUI());
          } else {
            this.reloadData('rules');
            handleSuccessToastr('Successfully deleted the Payment Processor Rule');
          }
        });
        break;
      default:
        handleErrorToastr('Something went wrong.  Mode "' + mode + '" not supported.');
        store.dispatch(unblockUI());
        break;
    }
  }

  render () {
    const { processorRules } = this.props;
    const { unsavedRules, processorsMap, reloading } = this.state;

    return (
      !reloading
        ? <div className='tab-content'>
          <div className='tab-pane active'>
            <h2 className='sub-header'><i className='fa fa-table'></i> Edit Rules</h2>
            <div className='row'>
              <div className='col-xs-12'>
                <div className='table-responsive'>
                  <table className='table table-bordered editable-table'>
                    <thead>
                      <tr>
                        <th className='text-center'>Payment Processor</th>
                        <th className='text-center'>Transaction Type&nbsp;<sup>(1)</sup></th>
                        <th className='text-center'>Priority</th>
                        <th className='text-center'>Maximum Amount / Month</th>
                        <th className='text-center'>No Limit (Amount / Month)</th>
                        <th className='text-center'>Cumulative Amount&nbsp;<sup>(2,&nbsp;3)</sup></th>
                        <th className='text-center' style={{width: '90px'}}>Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {
                        processorRules &&
                        typeof processorsMap.get === 'function' &&
                        processorRules.map((rule, ruleIndex) => {
                          const processor = processorsMap.get(rule.paymentProcessorId) || {};
                          return (
                            <ProcessorRulesRow key={'rule' + ruleIndex + rule.priority}
                              mode='update'
                              processorName={processor.processorName}
                              paymentProcessorId={processor.paymentProcessorId}
                              processorRule={rule}
                              confirmUpdate={this.confirmUpdate}
                              notifyChanges={this.notifyChanges}
                              dirty={unsavedRules && unsavedRules.includes(rule.paymentProcessorRuleId)}
                            />
                          );
                        })
                      }
                    </tbody>
                  </table>
                </div>
                <div className='info-notes'>
                  <p><sup>1</sup> Transactions with ‘Unknown’ transaction type will be routed as credit</p>
                  <p><sup>2</sup> Cumulative Amount excludes void & refunds</p>
                  <p><sup>3</sup> Since beginning of month.</p>
                  <p><sup>*</sup> All tokenized SALE transactions will be routed to the Payment Processor
                  with “No Limit” flag set to true</p>
                </div>
                {
                  unsavedRules.length
                    ? <div className='unsaved-changes-notice'>
                      <p className='unsaved-changes-text'>
                        You have unsaved changes. Press Tab or click outside the text
                        input to automatically save your modifications.
                      </p>
                    </div>
                    : null
                }
              </div>
            </div>
            <h2 className='sub-header'><i className='glyphicon glyphicon-plus-sign'></i> Create a new Rule</h2>
            <div className='row'>
              <div className='col-xs-12'>
                <div className='info-notes'>
                  <p><sup>**</sup> Rules will only be in effect for active payment processors</p>
                </div>
                <div className='table-responsive'>
                  <table className='table table-bordered editable-table'>
                    <thead>
                      <tr>
                        <th className='text-center'>Payment Processor</th>
                        <th className='text-center'>Transaction Type&nbsp;<sup>(1)</sup></th>
                        <th className='text-center'>Priority</th>
                        <th className='text-center'>Maximum Amount / Month</th>
                        <th className='text-center'>No Limit (Amount / Month)</th>
                        <th className='text-center' style={{width: '90px'}}>Save</th>
                      </tr>
                    </thead>
                    <tbody>
                      <ProcessorRulesRow mode='create'
                        confirmUpdate={this.confirmUpdate}
                        paymentProcessors={this.props.paymentProcessors}
                      />
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        : null
    );
  }
}

const mapStateToProps = (state) => {
  return {
    paymentProcessors: state.processor.paymentProcessors,
    processorRules: state.processorRule.processorRules
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

ProcessorRules.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProcessorRules);
