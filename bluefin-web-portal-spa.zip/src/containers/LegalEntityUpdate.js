import React from 'react';
import { connect } from 'react-redux';
import LegalEntityForm from '../forms/LegalEntityForm';
import { getLegalEntity, createLegalEntity, updateLegalEntity, cleanLegalEntity } from '../redux/modules/LegalEntity';
import { handleErrorToastr, handleSuccessToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  params: Object,
  mode: string,
  title: string,
  currentLegalEntity: Object
}
export class LegalEntityUpdate extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);

    this.confirmSubmit = this.confirmSubmit.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    store.dispatch(blockUI());

    if (this.props.mode === 'edit') {
      const legalEntityAppId = this.props.params.legalEntityAppId || this.props.currentLegalEntity.legalEntityAppId;

      store.dispatch(getLegalEntity(legalEntityAppId))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        };
        store.dispatch(unblockUI());
      });
    } else {
      store.dispatch(cleanLegalEntity());
      store.dispatch(unblockUI());
    }
  }

  confirmSubmit (data) {
    const { store } = this.context;
    store.dispatch(blockUI(false, 'Are you sure you want to save your changes to the Legal Entity?',
      () => {
        this.handleSubmit(data);
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  handleSubmit (data) {
    const { store, router } = this.context;
    store.dispatch(blockUI());

    const { legalEntityAppId } = this.props.currentLegalEntity;
    const payload = { legalEntityAppName: data.legalEntityAppName };

    if (this.props.mode === 'edit') {
      store.dispatch(updateLegalEntity(legalEntityAppId, payload))
      .then((payload) => {
        store.dispatch(unblockUI());
        router.replace({
          pathname: '/legal-entities'
        });
        if (payload.error) {
          handleErrorToastr(payload.error);
        } else {
          handleSuccessToastr(`Legal Entity ${data.legalEntityAppName} successfuly updated.`);
        }
      });
    } else {
      store.dispatch(createLegalEntity(payload))
      .then((payload) => {
        store.dispatch(unblockUI());
        router.replace({
          pathname: '/legal-entities'
        });
        if (payload.error) {
          handleErrorToastr(payload.error);
        } else {
          handleSuccessToastr(`Legal Entity ${data.legalEntityAppName} successfuly created.`);
        }
      });
    }
  }

  render () {
    return (
      <div>
        <h2 className='sub-header'>{this.props.title}</h2>
        <LegalEntityForm onSubmit={this.confirmSubmit}
          initialValues={this.props.currentLegalEntity}
          mode={this.props.mode}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    currentLegalEntity: state.legalEntity.currentLegalEntity
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

LegalEntityUpdate.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LegalEntityUpdate);
