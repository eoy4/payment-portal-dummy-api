import React from 'react';
import { connect } from 'react-redux';
import ProcessorToMerchantsForm from '../forms/ProcessorToMerchantsForm';
import { getProcessors, assignMerchantsToProcessor } from '../redux/modules/Processor';
import { getLegalEntities } from '../redux/modules/LegalEntity';
import { handleErrorToastr, handleSuccessToastr, clearToastr } from '../utils/utils';
import { blockUI, unblockUI } from '../redux/modules/Misc';
import 'toastr/build/toastr.min.css';

type Props = {
  params: Object,
  mode: string,
  title: string,
  paymentProcessors: Array,
  legalEntities: Array
}
export class ProcessorToMerchants extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);
    this.state = {paymentProcessorId: this.props.params.paymentProcessorId || 0};

    this.confirmSubmit = this.confirmSubmit.bind(this);
    this.handleProcessorChange = this.handleProcessorChange.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    store.dispatch(blockUI());

    this.getData();
  }

  getData () {
    const { store } = this.context;
    Promise.all([
      store.dispatch(getProcessors()),
      store.dispatch(getLegalEntities())
    ])
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      };
      store.dispatch(unblockUI());
    });
  }

  parseData (data) {
    let paymentProcessorMerchants = [];

    data.selectedMerchants &&
    data.selectedMerchants.map((merchant) => {
      if (merchant.merchantId.trim() !== '') {
        const { legalEntityAppId, merchantId, testOrProd } = merchant;
        paymentProcessorMerchants.push({
          legalEntityAppId,
          merchantId: merchantId.trim(),
          testOrProd: testOrProd ? 1 : 0
        });
      }
    });
    return paymentProcessorMerchants;
  }

  handleProcessorChange (event) {
    const { router } = this.context;

    router.replace({
      pathname: '/processor-merchants/' + event.target.value
    });

    this.setState({paymentProcessorId: event.target.value});
  }

  confirmSubmit (data) {
    const { store } = this.context;
    store.dispatch(blockUI(false, 'Are you sure you want to save your changes?',
      () => {
        this.handleSubmit(data);
      },
      () => {
        store.dispatch(unblockUI());
      }
    ));
  }

  handleSubmit (data) {
    const { store } = this.context;

    store.dispatch(blockUI());

    clearToastr();

    const { paymentProcessorId } = data;
    const paymentProcessorMerchants = this.parseData(data);

    store.dispatch(assignMerchantsToProcessor(paymentProcessorId, paymentProcessorMerchants))
    .then((payload) => {
      if (payload.error) {
        store.dispatch(unblockUI());
        handleErrorToastr(payload.error);
      } else {
        handleSuccessToastr('Merchant IDs succesfully assigned to Payment Processor');
        this.getData();
      }
    });
  }

  render () {
    return (
      <div className='tab-content' key={this.state.paymentProcessorId}>
        <div className='tab-pane active'>
          {
            this.props.legalEntities.length &&
            this.props.paymentProcessors.length
            ? <ProcessorToMerchantsForm onSubmit={this.confirmSubmit}
              handleProcessorChange={this.handleProcessorChange}
              paymentProcessors={this.props.paymentProcessors}
              selectedProcessorId={this.state.paymentProcessorId}
              legalEntities={this.props.legalEntities}
              initialValues={{paymentProcessorId: this.state.paymentProcessorId}}
            />
            : null
          }
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    paymentProcessors: state.processor.paymentProcessors,
    legalEntities: state.legalEntity.legalEntities
  };
};

ProcessorToMerchants.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps
)(ProcessorToMerchants);
