import React from 'react';
import { connect } from 'react-redux';
import GlobalSearchForm from '../forms/GlobalSearchForm';
import MultipleRemittances from '../components/MultipleRemittances/MultipleRemittances';
import Pagination from '../components/Pagination/Pagination';
import {
  // getTransactions,
  cleanFilter,
  storeFilter,
  getPaymentProcessorRemittances,
  cleanPaymentProcessorRemittances,
  downloadReconciliationReport,
  cleanReconciliationReport } from '../redux/modules/Transaction';
// import { blockUI, unblockUI, getReconciliationStatus } from '../redux/modules/Misc';
import {
  getEntities,
  getReconciliationStatus,
  blockUI,
  unblockUI,
  getTimeZone } from '../redux/modules/Misc';
import { getProcessors } from '../redux/modules/Processor';
import {
  createFilter,
  filterUpdatePage,
  filterUpdateSize,
  pageSize,
  getDataFromFilter,
  handleErrorToastr,
  saveFile
} from '../utils/utils';
import { default as moment } from 'moment';
import 'toastr/build/toastr.min.css';

type Props = {
  location: Object,
  currentFilter: string,
  paymentProcessorRemittances: Array,
  currentPage: number,
  reconciliationStatus: Array,
  reconciliationStatusMap: Object,
  processorNames: Array,
  availableLegalEntities: Array,
  isAuthenticated: string,
  username: string,
  reconciliationReport: string,
  currentTimeZone: string,
  timeZone: string
}

export class RemmitanceSearch extends React.Component {
  props: Props;
  context: Context;

  constructor () {
    super();

    this.handleNewPage = this.handleNewPage.bind(this);
    this.handlePageSizeChange = this.handlePageSizeChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidMount () {
    const { store } = this.context;
    store.dispatch(blockUI());
    Promise.all([
      store.dispatch(getProcessors()),
      store.dispatch(getEntities()),
      store.dispatch(getReconciliationStatus()),
      store.dispatch(cleanPaymentProcessorRemittances()),
      store.dispatch(getTimeZone())
    ])
    .then((payload) => {
      if (payload.error) {
        handleErrorToastr(payload.error);
      }
      if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
      }
      this.searchTransactions(this.props.location.query);
      store.dispatch(unblockUI());
    })
    .catch((err) => {
      store.dispatch(unblockUI());
      handleErrorToastr(err);
    });
  }

  searchTransactions (query) {
    // const { query } = this.props.location;
    const { store } = this.context;
    let filterObject = {};
    // store.dispatch(blockUI());
    store.dispatch(cleanFilter());
    store.dispatch(cleanPaymentProcessorRemittances());
    // store.dispatch(cleanFilteredTransactions());

    if (query.filter) {
      const filter = decodeURIComponent(query.filter);
      let match = filter.match(/page=[\d]+/g);
      const page = parseInt(match[0].split('=')[1]);
      match = filter.match(/size=[\d]+/g);
      const size = parseInt(match[0].split('=')[1]);

      pageSize('remittance transactions', size);

      filterObject = getDataFromFilter(filter);
      if (filterObject.transactionId) {
        filterObject.applicationTransactionId = filterObject.transactionId;
      }
      filterObject.remittanceCreationDate = moment(filterObject.minremittanceCreationDate)
        .format('YYYY-MM-DD HH:mm:ss');
      this.dispatchSearchAction(filter, page, filterObject.timeZone);
    } else {
      let min = moment().startOf('day').format('YYYY-MM-DD HH:mm:ss');
      filterObject.timeZone = this.props.timeZone;

      filterObject.remittanceCreationDate = min;
    }

    this.setState({filterObject});
  }

  componentWillUpdate (nextProps) {
    if (this.props.location.search !== nextProps.location.search) {
      this.searchTransactions(nextProps.location.query);
    }
  }

  handleSubmit (data, report) {
    const { router } = this.context;
    const filter = createFilter(data);

    router.push({
      pathname: '/search/remittance',
      query: { filter }
    });

    if (report) {
      this.setState({processingReport: true});
      this.downloadReport(filter);
    }

    /* if (this.props.currentFilter !== filter) {
      this.dispatchSearchAction(filter, 0);
    }*/
  }

  handleNewPage (i) {
    const newFilter = filterUpdatePage(this.props.currentFilter, i);

    this.handleNewFilter(newFilter, i);
  }

  handlePageSizeChange (newSize) {
    let newFilter = filterUpdateSize(this.props.currentFilter, newSize, 'remittance transactions');
    newFilter = filterUpdatePage(newFilter, 0);

    this.handleNewFilter(newFilter, 0);
  }

  handleNewFilter (newFilter, page = this.props.currentPage) {
    const { router } = this.context;

    router.replace({
      pathname: '/search/remittance',
      query: { filter: newFilter }
    });

    const filterObject = getDataFromFilter(newFilter);
    this.dispatchSearchAction(newFilter, page, filterObject.timeZone);
  }

  dispatchSearchAction (filter, page, timeZone) {
    const { store } = this.context;
    this.setState({loading: true}, () => {
      store.dispatch(storeFilter({filter, page, timeZone}));
      store.dispatch(getPaymentProcessorRemittances({filter, page}))
      .then((payload) => {
        if (payload.error) {
          handleErrorToastr(payload.error);
        }
        if (!payload.error || (payload.error && payload.error.details && payload.error.details.status !== 401)) {
          this.setState({loading: false});
        }
        this.setState({loading: false});
      });
    });
  }

  downloadReport (filter) {
    const { store } = this.context;
    store.dispatch(downloadReconciliationReport(filter))
    .then(() => {
      saveFile('reconciliationReport.csv', this.props.reconciliationReport);

      this.setState({processingReport: false});

      store.dispatch(cleanReconciliationReport());
    })
    .catch((e) => {
      this.setState({processingReport: false});
      handleErrorToastr(e);
    });
  }

  render () {
    const enableReports = this.props.paymentProcessorRemittances.content &&
      !!Object.keys(this.props.paymentProcessorRemittances.content).length;
    const processingReport = (this.state && this.state.processingReport);

    return (
      <div className='global-search other'>
        <GlobalSearchForm type={'remittance'}
          initialValues={(this.state && this.state.filterObject) ? this.state.filterObject : {}}
          reconciliationStatus={this.props.reconciliationStatus}
          processorNames={this.props.processorNames}
          availableLegalEntities={this.props.availableLegalEntities}
          reportsEnabled={enableReports}
          processing={processingReport}
          customSubmitHandler={this.handleSubmit}
          timeZone={this.props.timeZone} />
        {
          this.props.paymentProcessorRemittances.content &&
          this.props.paymentProcessorRemittances.content.length
            ? <Pagination elements={this.props.paymentProcessorRemittances}
              onPagination={this.handleNewPage}
              onPageSizeChange={this.handlePageSizeChange}
              currentPage={this.props.currentPage}
              numbersOnly
              maxPagesLinks={10}
              elementName={'remittance transactions'}
              blocked={this.state && this.state.loading} />
            : null
        }
        {
          (this.state && !this.state.loading) &&
          this.props.paymentProcessorRemittances.content &&
          this.props.paymentProcessorRemittances.content.length
          ? <MultipleRemittances
            remittances={this.props.paymentProcessorRemittances}
            reconciliationStatusMap={this.props.reconciliationStatusMap}
            currentFilter={this.props.currentFilter}
            timeZone={this.props.currentTimeZone}
            />
          : null
        }
        {
          (this.state && this.state.loading)
          ? <div>
            <img src='/img/loader.gif' className='loader' alt='Loader' />
            <hr />
          </div>
          : null
        }
        {
          (this.state && !this.state.loading) &&
          this.props.paymentProcessorRemittances.content &&
          this.props.paymentProcessorRemittances.content.length
            ? <Pagination elements={this.props.paymentProcessorRemittances}
              onPagination={this.handleNewPage}
              onPageSizeChange={this.handlePageSizeChange}
              currentPage={this.props.currentPage}
              maxPagesLinks={10}
              elementName={'remittance transactions'}
              blocked={this.state && this.state.loading} />
            : null
        }
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    reconciliationReport: state.transaction.reconciliationReport,
    paymentProcessorRemittances: state.transaction.paymentProcessorRemittances,
    currentFilter: state.transaction.currentFilter,
    currentPage: state.transaction.currentPage,
    reconciliationStatus: state.misc.reconciliationStatus,
    reconciliationStatusMap: state.misc.reconciliationStatusMap,
    processorNames: state.processor.paymentProcessors,
    availableLegalEntities: state.misc.legalEntities,
    username: state.auth.profile.username,
    currentTimeZone: state.transaction.currentTimeZone,
    timeZone: state.misc.timeZone
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

RemmitanceSearch.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RemmitanceSearch);
