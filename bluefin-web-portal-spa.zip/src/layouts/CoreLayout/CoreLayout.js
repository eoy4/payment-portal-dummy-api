import React from 'react';
import { connect } from 'react-redux';
import '../../styles/core.scss';
import Footer from '../../components/Footer/Footer';
import Header from '../../components/Header/Header';
import Modal from '../../components/Modal/Modal';
import SideBar from '../../components/SideBar/SideBar';
import BlockingOverlay from '../../components/BlockingOverlay/BlockingOverlay';
import { logoutUser } from '../../redux/modules/Authentication';
import { blockUI, unblockUI } from '../../redux/modules/Misc';
import { handleErrorToastr } from '../../utils/utils';
import { actions as idleActions } from '../../components/ReduxIdleMonitor';

type Props = {
  children: Element,
  route: Object,
  location: Object,
  isAuthenticated: boolean,
  profile: Object,
  loading: boolean,
  prompt: string,
  callbackOk: Function,
  callbackCancel: Function,
  accessRoles: Object
}
export class CoreLayout extends React.Component {
  props: Props;
  context: Context;

  constructor (props) {
    super(props);
    this.onLogout = this.onLogout.bind(this);
  }

  onLogout (e) {
    e.preventDefault();
    const { store, router } = this.context;

    store.dispatch(blockUI());

    store.dispatch(logoutUser())
    .then(() => {
      store.dispatch(unblockUI());
      store.dispatch(idleActions.stop());
      router.push('/login');
    })
    .catch(err => {
      store.dispatch(unblockUI());
      store.dispatch(idleActions.stop());
      if (err.details && err.details.status === 401) {
        router.push('/login');
      } else {
        handleErrorToastr(err);
      }
    });
  }

  render () {
    const sidebarClassName = (this.props.isAuthenticated) ? 'main-sidebar' : '';
    return (
      <div className='main-wrapper theme-default styleguide sidebar-open' data-ref='breakpoints'>
        <BlockingOverlay loading={this.props.loading}
          prompt={this.props.prompt}
          callbackOk={this.props.callbackOk}
          callbackCancel={this.props.callbackCancel} />
        <div className={sidebarClassName} data-ref='sidebar'>
          <SideBar location={this.props.location} isAuthenticated={this.props.isAuthenticated}
            accessRoles={this.props.accessRoles} />
        </div>
        <div className='main-content container-fluid'>
          <nav className='main-header row'>
            <Header isAuthenticated={this.props.isAuthenticated} user={this.props.profile} onLogout={this.onLogout} />
          </nav>
          <div className='inner row'>
            <section className='content col-xs-12'>
              {this.props.children}
            </section>
            <footer className='footer col-xs-12'>
              <Footer />
            </footer>
          </div>
        </div>
        <div id='demo-modal' className='modal fade' tabIndex='-1' role='dialog'>
          <Modal />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  const { isAuthenticated, profile, accessRoles } = state.auth;
  const { loading, prompt, callbackOk, callbackCancel } = state.misc;
  return {
    isAuthenticated,
    accessRoles,
    profile,
    loading,
    prompt,
    callbackOk,
    callbackCancel
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
  };
};

CoreLayout.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CoreLayout);
