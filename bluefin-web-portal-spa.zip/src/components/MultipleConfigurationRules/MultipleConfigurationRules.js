import React from 'react';
import { Link } from 'react-router';

type Props = {
  rules: Object
};
export class MultipleConfigurationRules extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '15px 0'
    };
    const rules = this.props.rules.content || [];

    return (
      <div style={styles} className='table-responsive'>
        <table className='table table-bordered'>
          <thead>
            <tr>
              <th>#</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
              {
                rules.map((rule, index) => {
                  return <tr key={index}>
                    <th scope='row'>{index + 1}</th>
                    <td><Link to={`/rules/edit/${rule.id}`}>Edit</Link></td>
                  </tr>;
                })
              }
          </tbody>
        </table>
      </div>
    );
  }
}

export default MultipleConfigurationRules;

