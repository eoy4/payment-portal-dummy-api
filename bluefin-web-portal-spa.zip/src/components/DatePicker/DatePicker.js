import React from 'react';
import { DateField, DatePicker } from 'react-date-picker';
import { default as moment } from 'moment';
import 'react-date-picker/index.css';
import './DatePicker.scss';

type Props = {
  onChange: Function,
  dateFormat: String,
  value: string,
};
export class DatePickerInput extends React.Component {
  props: Props;

  static defaultProps = {
    dateFormat: 'YYYY-MM-DD HH:mm:ss'
  }

  constructor (props, defaultProps) {
    super(props, defaultProps);

    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (dateString, { dateMoment, timestamp }) {
    const date = dateMoment && dateMoment.format('YYYY-MM-DD HH:mm:ss');
    this.props.onChange(date);
  }

  render () {
    const { dateFormat } = this.props;
    let value = parseInt(moment(this.props.value).format('x'));
    return (
      <DateField
        className='form-control'
        forceValidDate
        updateOnDateClick
        dateFormat={dateFormat}
        onChange={this.updateValue}
        value={value}
      >
        <DatePicker
          navigation
          locale="en"
          forceValidDate
          highlightWeekends
          highlightToday
          weekNumbers
          weekStartDay={0}
          footer={false}
        />
      </DateField>
    );
  }
}

export default DatePickerInput;

