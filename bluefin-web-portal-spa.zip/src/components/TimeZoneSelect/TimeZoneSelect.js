import React from 'react';
import moment from 'moment';
import { default as ReactSelect } from 'react-select';

type Props = {
  className: string,
  defaultValue: string,
  disabled: boolean,
  id: string,
  name: string,
  onBlur: Function,
  onChange: Function,
  onFocus: Function,
  value: string,
};
export class TimeZoneSelect extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.tz = [];
    this.timezones = {};
    const tzNames = moment.tz.names();
    tzNames.forEach((tzName) => {
      this.timezones[tzName] = `${tzName} (${moment().tz(tzName).format('Z')})`;
    });

    tzNames.forEach((tzName) => {
      this.tz.push({value: `${tzName}`,
        label: `${tzName} (${moment().tz(tzName).format('Z')})`});
    });
  }
  render () {
    return (
      <div>
        <ReactSelect {...this.props}
          options={this.tz}
          clearable={false}
        />
      </div>
    );
  }
}

export default TimeZoneSelect;

