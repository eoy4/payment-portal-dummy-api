import React from 'react';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';
import numeral from 'numeral';

type Props = {
};

export class ConvertibleInputUSDollar extends ConvertibleInput {
  props: Props;

  getLink () {
    // Format the currency values in the following format:
    // $123,123.12 for amounts less than 1M
    // $1.23 M for amounts 1M or greater
    const fotmattedValue = numeral(this.props.value).format('$0,0,0.00');
    const styles = {display: this.state.editing ? 'none' : 'block'};
    return (
      <a href='#'
        className='convertible-input-link currency'
        id={this.props.id}
        onClick={this.setEditing}
        style={styles}
      >
        {fotmattedValue}
        &nbsp;
        <sup>
          <i className={this.props.editIconClassName}></i>
        </sup>
      </a>
    );
  }
}
