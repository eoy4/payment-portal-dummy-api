import { IDLESTATUS_AWAY, IDLESTATUS_INACTIVE, IDLESTATUS_EXPIRED } from './constants';
import { logoutUser } from '../../redux/modules/Authentication';
import { blockUI, unblockUI } from '../../redux/modules/Misc';
import { actions as idleActions } from './';
import { push } from 'react-router-redux';

export const idleStatusDelay = idleStatus => (dispatch, getState) => {
  switch (idleStatus) {
    case IDLESTATUS_AWAY:
      return 300000;
    case IDLESTATUS_INACTIVE:
      return 600000;
    case IDLESTATUS_EXPIRED:
      return 900000;
  }
};

export const activeStatusAction = (dispatch, getState) => () => {};

export const idleStatusAction = idleStatus => (dispatch, getState) => {
  switch (idleStatus) {
    case IDLESTATUS_EXPIRED:
      dispatch(blockUI());
      dispatch(logoutUser())
      .then(() => {
        dispatch(unblockUI());
        dispatch(idleActions.stop());
        dispatch(push('/login'));
      })
      .catch(err => {
        dispatch(unblockUI());
        dispatch(idleActions.stop());
        if (err.details && err.details.status === 401) {
          dispatch(push('/login'));
        }
      });
  }
};

