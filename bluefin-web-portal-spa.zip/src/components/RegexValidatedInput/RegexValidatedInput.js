import React from 'react';

type Props = {
  className: string,
  defaultValue: string,
  disabled: boolean,
  id: string,
  inputRef: String,
  maxLength: Number,
  name: string,
  onBlur: Function,
  onChange: Function,
  onFocus: Function,
  onKeyUp: Function,
  placeholder: string,
  regex: string,
  style: Object,
  value: string,
  id: string
};
export class RegexValidatedInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.validate = this.validate.bind(this);
  }

  componentDidMount () {
    const rx = (this.props.regex) ? this.props.regex : '[^]*';
    const regex = (typeof rx === 'string') ? new RegExp(rx, 'g') : rx;
    this.setState({
      regex
    });
  }

  validate (e) {
    let val = e.target.value;
    let validated = val.match(this.state.regex);
    let value = (validated || []).join('');
    this.props.onChange && this.props.onChange(value);
  }

  render () {
    const {inputRef, ...attributes} = this.props;
    attributes.ref = inputRef;
    attributes.onChange = this.validate;

    return (
      <input
        type='text'
        {...attributes}
      />
    );
  }
}

export default RegexValidatedInput;

