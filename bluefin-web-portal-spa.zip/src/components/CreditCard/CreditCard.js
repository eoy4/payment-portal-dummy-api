import React from 'react';
import Cleave from 'cleave.js/react';

type Props = {
  onChange: Function,
  onBlur: Function,
  onCopy: Function,
  onPaste: Function,
  value: string,
  name: string,
  id: string
};
export class CreditCardInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);
    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (event) {
    this.props.onChange(event.target.rawValue);
  }

  render () {
    const { value, name, onBlur, onPaste, onCopy, id } = this.props;
    return (
      <Cleave className='form-control'
        value={value}
        placeholder='Enter your card number'
        name={name}
        options={{creditCard: true}}
        onChange={this.updateValue}
        onPaste={onPaste}
        onCopy={onCopy}
        onBlur={onBlur}
        id={id} />
    );
  }
}

export default CreditCardInput;

