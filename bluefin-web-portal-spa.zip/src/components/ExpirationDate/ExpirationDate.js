import React from 'react';
import Cleave from 'cleave.js/react';

type Props = {
  onChange: Function,
  onBlur: Function,
  onCopy: Function,
  onPaste: Function,
  value: string,
  name: string,
  touched: boolean,
  id: string
};
export class ExpirationDateInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);
    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (event) {
    this.props.onChange(event.target.value);
  }

  render () {
    const { value, name, onBlur, onPaste, onCopy, id } = this.props;
    return (
      <Cleave className='form-control'
        value={value}
        name={name}
        placeholder='mm/yy'
        options={{date: true, datePattern: ['m', 'y']}}
        onChange={this.updateValue}
        onPaste={onPaste}
        onCopy={onCopy}
        onBlur={onBlur}
        id={id} />
    );
  }
}

export default ExpirationDateInput;

