import React from 'react';
import { ConvertibleInput } from '../ConvertibleInput/ConvertibleInput';

type Props = {
  legalEntities: Array,
  handleInputChange: Function,
  handleDelete: Function,
  handleCreate: Function
};
export class MultipleLegalEntities extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = { editedLegalEntities: {}, newLegalEntity: {} };

    this.getInputHandler = this.getInputHandler.bind(this);
    this.handleNewName = this.handleNewName.bind(this);
    this.handleSave = this.handleSave.bind(this);
  }

  getInputHandler (legalEntityAppId, legalEntity) {
    return (event) => {
      const value = event.target.value;

      if (value === legalEntity.legalEntityAppName) {
        return false;
      }

      const editedLegalEntities = Object.assign({}, this.state.editedLegalEntities, {[legalEntityAppId]: value});
      this.setState({editedLegalEntities}, () => {
        this.props.handleInputChange &&
        this.props.handleInputChange(legalEntityAppId, legalEntity)(value);
      });
    };
  }

  handleNewName (event) {
    let newLegalEntity = Object.assign({}, this.state.newLegalEntity);
    newLegalEntity.legalEntityAppName = event.target.value;
    this.setState({newLegalEntity});
  }

  handleSave (event) {
    event.preventDefault();

    return this.props.handleCreate &&
    this.props.handleCreate(this.state.newLegalEntity);
  }

  render () {
    const legalEntities = this.props.legalEntities || [];
    const { editedLegalEntities, newLegalEntity } = this.state;
    const styles = {
      width: '90px'
    };

    return (
      <div>
        <h2 className='sub-header'><i className='glyphicon glyphicon-edit'></i> Edit Legal Entities</h2>
        <div className='row'>
          <div className='col-md-8 col-xs-12'>
            <div className='table-responsive'>
              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th>Legal Entity</th>
                    <th style={styles} className='text-center' colSpan='2'>Delete</th>
                  </tr>
                </thead>

                <tbody>
                  {
                    legalEntities &&
                    legalEntities.map((entity, index) => {
                      return <tr key={entity.legalEntityAppId}>
                        <td>
                          <ConvertibleInput id={'legalEntityName-' + entity.legalEntityAppId}
                            onChange={this.getInputHandler(entity.legalEntityAppId, entity)}
                            value={
                              editedLegalEntities[entity.legalEntityAppId]
                              ? editedLegalEntities[entity.legalEntityAppId]
                              : entity.legalEntityAppName
                            }
                          />
                        </td>
                        <td style={styles} className='text-center'>
                          <a href='#' title='Delete' onClick={this.props.handleDelete(entity.legalEntityAppId)}>
                            <i className='glyphicon glyphicon-remove'></i>
                          </a>
                        </td>
                      </tr>;
                    })
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <h2 className='sub-header'><i className='glyphicon glyphicon-plus-sign'></i> Create a new Legal Entity</h2>
        <div className='row'>
          <div className='col-md-8 col-xs-12'>
            <div className='table-responsive'>
              <table className='table table-bordered editable-table'>
                <thead>
                  <tr>
                    <th>Legal Entity</th>
                    <th style={styles} className='text-center'>Save</th>
                  </tr>
                </thead>

                <tbody>
                  <tr>
                    <td>
                      <ConvertibleInput id={'newLegalEntityName'}
                        onChange={this.handleNewName}
                        value={newLegalEntity.legalEntityAppName}
                      />
                    </td>
                    <td style={styles} className='text-center'>
                      <a href='#' onClick={this.handleSave}>
                        <i className='glyphicon glyphicon-floppy-disk'></i>
                      </a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default MultipleLegalEntities;
