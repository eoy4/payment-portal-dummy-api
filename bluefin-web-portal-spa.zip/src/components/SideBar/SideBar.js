import React from 'react';
import { Link } from 'react-router';
import { checkAllowedPath } from '../../utils/utils';

export class SideBar extends React.Component {
  props: Props;

  collapseMenu () {
    const $ = window.$ || {};
    $('.main-wrapper.small').addClass('sidebar-close').removeClass('sidebar-open');
    return true;
  }

  getSections () {
    // get the first part of the path. So, "/foo/bar" becomes just "/foo"
    const path = '/' + this.props.location.pathname.split('/')[1];
    const { accessRoles } = this.props;
    let sections = [];

    if (checkAllowedPath(['/sales', '/void', '/refund'], accessRoles)) {
      let section = {
        id: 'section1',
        name: 'Credit/Debit Card',
        dataParent: 'sidebarnav',
        iconClassName: 'glyphicon glyphicon-credit-card',
        sectionClassName: 'nav nav-second-level collapse',
        links: {},
        leaf: true
      };

      if (checkAllowedPath('/sales', accessRoles)) {
        section.links['/sales'] = {
          name: 'Sale'
        };
      }

      if (checkAllowedPath('/void', accessRoles)) {
        section.links['/void'] = {
          name: 'Void'
        };
      }

      if (checkAllowedPath('/refund', accessRoles)) {
        section.links['/refund'] = {
          name: 'Refund'
        };
      }

      sections.push(section);
    }

    if (checkAllowedPath('/search', accessRoles)) {
      let section = {
        id: 'section2',
        name: 'Search & Reporting',
        dataParent: 'sidebarnav',
        iconClassName: 'glyphicon glyphicon-stats',
        sectionClassName: 'nav nav-second-level',
        link: '/search',
        leaf: true
      };
      sections.push(section);
    }

    if (checkAllowedPath('/batch-transactions', accessRoles)) {
      let section = {};
      section = {
        id: 'section5',
        name: 'Batch Transactions',
        dataParent: 'sidebarnav',
        iconClassName: 'glyphicon glyphicon-list-alt',
        sectionClassName: 'nav nav-second-level',
        link: '/batch-transactions',
        leaf: true
      };
      sections.push(section);
    }

    const adminRoutes = [
      '/users',
      '/legal-entities',
      '/processors',
      '/rules',
      '/processor-merchants',
      '/response-codes',
      '/status-codes'
    ];
    if (checkAllowedPath(adminRoutes, accessRoles)) {
      let adminSection = {
        id: 'section3',
        name: 'Administration',
        dataParent: 'sidebarnav',
        iconClassName: 'glyphicon glyphicon-cog',
        sectionClassName: 'nav nav-second-level collapse',
        leaf: false
      };

      let adminLinks = {};
      if (checkAllowedPath('/users', accessRoles)) {
        adminLinks['/users'] = {
          name: 'User Management'
        };
      }
      if (checkAllowedPath('/legal-entities', accessRoles)) {
        adminLinks['/legal-entities'] = {
          name: 'Manage Legal Entities'
        };
      }
      adminSection.links = adminLinks;

      let processorsSection = [];
      let processorsLinks = {};
      if (checkAllowedPath([
        '/processors',
        '/processor-merchants',
        '/rules',
        '/response-codes',
        '/status-codes'
      ], accessRoles)) {
        processorsSection = [{
          id: 'section3_1',
          name: 'Manage Payment Processors',
          dataParent: 'sidebarnav_sub',
          iconClassName: '',
          sectionClassName: 'nav nav-third-level collapse',
          leaf: true
        }];

        if (checkAllowedPath('/processors', accessRoles)) {
          processorsLinks['/processors'] = {
            name: 'Add/Edit Payment Processors'
          };
        }
        if (checkAllowedPath('/processor-merchants', accessRoles)) {
          processorsLinks['/processor-merchants'] = {
            name: 'Assign Merchant ID to Processors'
          };
        }
        if (checkAllowedPath('/rules', accessRoles)) {
          processorsLinks['/rules'] = {
            name: 'Payment Processor Rules'
          };
        }
        if (checkAllowedPath('/response-codes', accessRoles)) {
          processorsLinks['/response-codes'] = {
            name: 'Response Codes Mapping'
          };
        }
        if (checkAllowedPath('/status-codes', accessRoles)) {
          processorsLinks['/status-codes'] = {
            name: 'Status Codes Mapping'
          };
        }
      }

      if (processorsSection.length) {
        processorsSection[0].links = processorsLinks;
      }
      adminSection.children = processorsSection;

      sections.push(adminSection);
    }

    let section = {};
    section = {
      id: 'section4',
      name: 'About',
      dataParent: 'sidebarnav',
      iconClassName: 'glyphicon glyphicon-info-sign',
      sectionClassName: 'nav nav-second-level',
      link: '/about',
      leaf: true
    };
    sections.push(section);

    if (path === '/') {
      if (sections.length) {
        sections[0].expanded = true;
      }
    } else {
      sections.forEach((section) => {
        if (section.links && typeof section.links[path] !== 'undefined') {
          section.expanded = true;
          section.links[path].selected = true;
          return;
        }
        if (section.link && section.link === path) {
          section.selected = true;
        }
        if (!section.leaf) {
          section.children && section.children.forEach((subSection) => {
            if (subSection.links && (typeof subSection.links[path] !== 'undefined')) {
              section.expanded = true;
              subSection.expanded = true;
              subSection.links[path].selected = true;
              return;
            }
          });
        }
      });
    }

    return sections;
  }

  renderSectionHeading (section) {
    return section.links
    ? (
      <a href={'#' + section.id}
        className={section.expanded ? '' : 'collapsed'}
        data-toggle='collapse'
        data-parent={'#' + section.dataParent}
      >
        <i className={section.iconClassName}></i>
        <span className='title'>{section.name}</span>
      </a>
    )
    : (
      <Link to={section.link}
        className={'top-level-link' + (section.selected ? ' selected' : '')}
      >
        <i className={section.iconClassName}></i>
        <span className='title'>{section.name}</span>
      </Link>
    );
  }

  renderSectionLinks (section) {
    return (
      <ul id={section.id}
        className={section.sectionClassName + (section.expanded ? ' in' : '')}
      >
        {section.links && Object.keys(section.links).map((index) => {
          return (
            <li key={index} className={section.links[index].selected ? 'selected' : ''}>
              <Link to={index}>
                <div onClick={this.collapseMenu}>
                  {section.links[index].name}
                </div>
              </Link>
            </li>
          );
        })}
        {
          !section.leaf && section.children && section.children.map((subSection) => {
            return (
              <li className='subnav sub-section panel' key={subSection.id}>
                <ul id={subSection.dataParent} className='nav' role='tablist' aria-multiselectable='false'>
                  {this.renderSectionHeading(subSection)}
                  {this.renderSectionLinks(subSection)}
                </ul>
              </li>
            );
          })
        }
      </ul>
    );
  }

  render () {
    const sections = this.getSections();
    const styles = (!this.props.isAuthenticated) ? {display: 'none'} : {};
    return (
      <div>
        <div className='inner'>
          <header className='sidebar-header'>
            <a href='/'><img src='/img/logo.png' alt='Encore' className='logo' />
            </a>
            <button data-target='sidebar-toggle' style={styles}><span></span></button>
          </header>
          <nav className='main-navigation' style={styles}>
            <ul id='sidebarnav' className='nav' role='tablist' aria-multiselectable='false'>
              {sections.map((section) => {
                return (
                  <li className='subnav panel' key={section.id}>
                    {this.renderSectionHeading(section)}
                    {this.renderSectionLinks(section)}
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>
      </div>
    );
  }
}

export default SideBar;
