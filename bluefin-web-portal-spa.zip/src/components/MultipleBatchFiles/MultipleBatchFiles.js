import React from 'react';
import { Link } from 'react-router';
import { default as moment } from 'moment';
import numeral from 'numeral';

type Props = {
  batchFiles: Array,
  handleTransactionsReport: Function,
  processing: boolean,
  timeZone: string
};
export class MultipleBatchFiles extends React.Component {
  props: Props;

  render () {
    const batchFiles = this.props.batchFiles.content || [];

    const emptyStyles = {color: '#CCC'};

    return (
      <div>
        <div className='table-responsive'>
          <table className='table table-bordered editable-table'>
            <thead>
              <tr>
                <th className='text-center'>Batch ID</th>
                <th className='text-center'>Upload Date/Time</th>
                <th className='text-center' style={{width: '90px'}}>Number of Records</th>
                <th className='text-center'>User</th>
                <th className='text-center'>Processed Date/Time</th>
                <th className='text-center' style={{width: '90px'}} colSpan='2'>Completed</th>
                <th className='text-center' style={{width: '90px'}}>Batch Status Details</th>
                <th className='text-center' style={{width: '90px'}}>Download Return File (Comma Delimited)</th>
              </tr>
            </thead>

            <tbody>
              {batchFiles &&
                batchFiles.map((batchFile, index) => {
                  const percentage = batchFile.numberOfTransactions > 0
                    ? (batchFile.numberOfTransactionsProcessed +
                      batchFile.numberOfRejected) *
                      100 / batchFile.numberOfTransactions
                    : 100;

                  let rowClassName = batchFile.processEnd ? 'complete' : 'pending';
                  const { numberOfRejected, numberOfErrorTransactions } = batchFile;
                  const hasBadTransactions = !!(numberOfRejected + numberOfErrorTransactions);
                  rowClassName += (numberOfRejected > 0) ? ' some-rejected' : '';
                  rowClassName += (numberOfErrorTransactions > 0) ? ' some-errors' : '';

                  return <tr key={`batch-${index}`} className={rowClassName}>
                    <td className='text-center batch-upload-id'><strong>{batchFile.batchUploadId}</strong></td>
                    <td>
                      {
                        batchFile.dateUploaded
                        ? moment.utc(batchFile.dateUploaded, 'MM/DD/YYYY hh:mm:ss A')
                          .tz(this.props.timeZone).format('YYYY/MM/DD HH:mm:ss')
                        : <span style={emptyStyles}>[empty]</span>
                      }
                    </td>
                    <td className='text-center number-of-transactions'>{batchFile.numberOfTransactions}</td>
                    <td className='uploaded-by'>{batchFile.upLoadedBy}</td>
                    <td className='process-end'>
                      {
                        batchFile.processEnd
                        ? moment.utc(batchFile.processEnd, 'MM/DD/YYYY hh:mm:ss A')
                          .tz(this.props.timeZone).format('YYYY/MM/DD HH:mm:ss')
                        : <p className='text-center'>(not finished)</p>
                      }
                    </td>
                    <td className='text-center percentage'
                      colSpan={hasBadTransactions ? 1 : 2}
                    >
                      <strong>{numeral(percentage).format('0[.]0')}%</strong>
                    </td>
                    {
                      hasBadTransactions
                      ? <td className='bad-transactions'>
                        <ul>
                          {
                            numberOfRejected
                            ? <li className='note-rejected'>{numberOfRejected}&nbsp;rejected.</li>
                            : null
                          }
                          {
                            numberOfErrorTransactions
                            ? <li className='note-rejected'>{numberOfErrorTransactions}&nbsp;errors.</li>
                            : null
                          }
                        </ul>
                      </td>
                      : null
                    }
                    <td className='batch-upload-details text-center'>
                      <Link to={`/batch-transactions/details/${batchFile.batchUploadId}
                      /${encodeURIComponent(this.props.timeZone)}`}>
                        <i className='glyphicon glyphicon-list'></i>
                      </Link>
                    </td>
                    <td className={'text-center download-return-file' + (batchFile.processEnd ? ' available' : '')}>
                      {batchFile.processEnd
                        ? <div>
                          {
                            this.props.processing &&
                            this.props.processing[batchFile.batchUploadId]
                            ? <span><i className='glyphicon glyphicon-hourglass'></i></span>
                            : <a href='#'
                              onClick={this.props.handleTransactionsReport(batchFile.batchUploadId)}
                              title='Download Return File'>
                              <i className='fa fa-file-text-o'></i>
                            </a>
                          }
                        </div>
                        : <p className='text-center'>(not available)</p>
                      }
                    </td>
                  </tr>;
                })
              }
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default MultipleBatchFiles;
