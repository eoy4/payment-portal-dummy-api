import React from 'react';
import ReactDOM from 'react-dom';
type Props = {
  onChange: Function,
  notifyChanges: Function,
  id: string,
  value: string,
  linkDisplay: String,
  inputDisplay: String,
  editIconClassName: String,
  regex: string,
};

export class ConvertibleInput extends React.Component {
  props: Props;

  static defaultProps = {
    linkDisplay: 'block',
    inputDisplay: 'block',
    editIconClassName: 'glyphicon glyphicon-pencil'
  }

  constructor (props, defaultProps) {
    super(props, defaultProps);

    this.state = {
      editing: false
    };

    this.linkClassName = 'convertible-input-link';

    this.setEditing = this.setEditing.bind(this);
    this.setInactive = this.setInactive.bind(this);
    this.onFocus = this.onFocus.bind(this);
    this.onBlur = this.onBlur.bind(this);
    this.onKeyPress = this.onKeyPress.bind(this);
    this.validate = this.validate.bind(this);
  }

  componentDidMount () {
    const rx = (this.props.regex) ? this.props.regex : '[^]*';
    const regex = new RegExp(rx, 'g');
    this.setState({
      regex
    });
  }

  setEditing (event) {
    event.preventDefault();
    this.setState({editing: true}, () => {
      const input = ReactDOM.findDOMNode(this.refs['input']);
      if (input && (document.activeElement !== input)) {
        input.focus();
        if (typeof input.setSelectionRange === 'function') {
          input.setSelectionRange(0, input.value.length);
        }
      }
    });
  }

  validate (e) {
    let val = e.target.value;
    let validated = val.match(this.state.regex);
    let value = (validated || []).join('');
    if (value !== val) {
      e.target.value = value;
    }
    if (this.props.notifyChanges) {
      this.props.notifyChanges(e);
    }
  }

  setInactive () {
    this.setState({editing: false});
  }

  onFocus (event) {
    const input = event.target;
    if (typeof input.setSelectionRange === 'function') {
      input.setSelectionRange(0, input.value.length);
    }
    this.focused();
  }

  // Custom code to be implemented in child classes
  focused () {}

  onBlur (event) {
    this.setInactive();
    this.props.onChange &&
    this.props.onChange(event);
  }

  onKeyPress (event) {
    const input = ReactDOM.findDOMNode(this.refs['input']);
    if (event.key &&
        event.key.toLowerCase() === 'escape' ||
        event.key.toLowerCase() === 'enter') {
      input && input.blur();
    }
  }

  getInput () {
    const { inputDisplay } = this.props;
    const styles = {display: this.state.editing ? inputDisplay : 'none'};
    return (
      <input type='text'
        onBlur={this.onBlur}
        onChange={this.validate}
        onKeyUp={this.onKeyPress}
        defaultValue={this.props.value}
        onFocus={this.onFocus}
        id={this.props.id}
        ref='input'
        style={styles}
      />
    );
  }

  getEmptyLink () {
    const { linkDisplay } = this.props;
    const styles = {display: this.state.editing ? 'none' : linkDisplay};
    return (
      <a href='#'
        className='convertible-input-link empty-input'
        id={this.props.id}
        onClick={this.setEditing}
        style={styles}
      >
        [Add]
      </a>
    );
  }

  getLink () {
    const { value, linkDisplay } = this.props;
    const styles = {display: this.state.editing ? 'none' : linkDisplay};

    return value ? (
      <a href='#'
        className={this.linkClassName}
        id={this.props.id}
        onClick={this.setEditing}
        style={styles}
      >
        {this.props.value}
        &nbsp;
        <sup>
          <i className={this.props.editIconClassName}></i>
        </sup>
      </a>
    ) : this.getEmptyLink();
  }

  render () {
    const inputElement = this.getInput();
    const linkElement = this.getLink();

    const { linkDisplay } = this.props;

    return (<div style={{display: linkDisplay}}>
      {inputElement}
      {linkElement}
    </div>);
  }
}
