import React from 'react';

type Props = {
  value: number,
  name: string,
  className: string,
  placeholder: string,
  onChange: Function,
  onBlur: Function
};
export class UnformattedNumberInput extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (event) {
    let value = event.target.value.replace(/[^0-9]/g, '');
    this.props.onChange(value);
  }

  render () {
    return (
      <input type='text'
        placeholder={this.props.placeholder}
        className={this.props.className}
        value={this.props.value}
        name={this.props.name}
        onChange={this.updateValue}
        onBlur={this.props.onBlur} />
    );
  }
}

export default UnformattedNumberInput;

