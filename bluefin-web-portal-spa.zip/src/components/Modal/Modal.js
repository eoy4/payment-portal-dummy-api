import React from 'react';

type Props = {

};
export class Modal extends React.Component {
  props: Props;

  render () {
    return (
      <div></div>
    );
  }
}

export default Modal;

