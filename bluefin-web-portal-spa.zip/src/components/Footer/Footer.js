import React from 'react';

type Props = {

};
export class Footer extends React.Component {
  props: Props;

  render () {
    return (
      <div className='inner'>
        <div className='col-xs-12 col-sm-4'>
          <ul className='list-inline footer-browser-list'>
            <li className='chrome'>
              <span className='label label-default' title='Chrome 44+'>44+</span>
            </li>
            <li className='explorer'>
              <span className='label label-default' title='IE 10+'>10+</span>
            </li>
          </ul>
        </div>
        <div className='col-xs-12 col-sm-4 text-center'>
          <p>2016 &copy; All Rights Reserved. Powered by <a href='#'>Encore</a>.</p>
        </div>
        <div className='col-xs-12 col-sm-4 provider-logo'>
          <img className='logo'
            src='/img/encore-logo-colorized.png' alt='Encore' />
        </div>
      </div>

    );
  }
}

export default Footer;
