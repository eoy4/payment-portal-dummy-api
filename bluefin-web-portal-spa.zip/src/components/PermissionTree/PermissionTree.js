import React from 'react';
import 'rc-tree/assets/index.css';
import Tree, { TreeNode } from 'rc-tree';
import './PermissionTree.scss';

// http://react-component.github.io/tree/examples/basic-controlled.html

type Props = {
  title: string,
  leaves: Array,
  onChange: Function,
  notifySelection: Function,
  value: Array,
  mode: string,
  selectAll: boolean,
  disabled: boolean,
  selectedItems: Array,
};
export class PermissionTree extends React.Component {
  props: Props;

  constructor (props) {
    super(props);
    this.updateValue = this.updateValue.bind(this);
  }

  updateValue (value) {
    this.props.onChange(value);
    if (this.props.notifySelection) {
      this.props.notifySelection(value);
    }
  }

  render () {
    const treeProps = {};
    let value = null;
    if (this.props.selectAll && this.props.disabled) {
      value = this.props.selectedItems;
    } else {
      value = (this.props.value === '') ? [] : this.props.value;
    }
    if (this.props.mode === 'self') {
      treeProps['disabled'] = true;
    }

    return (
      <div>
        <Tree checkable selectable={false} defaultExpandAll checkedKeys={value} onCheck={this.updateValue}>
          <TreeNode title={this.props.title} disabled={this.props.disabled} key='parent' {...treeProps}>
          {
            this.props.leaves.map((leaf) => {
              let obj = {
                id: leaf.roleId || leaf.legalEntityAppId,
                title: leaf.description || leaf.legalEntityAppName
              };

              if (leaf.permissions && leaf.permissions.length) {
                const permissions = (
                  <div id={`permissions-${obj.id}`} className='role-permissions'>
                    <h4><i className='glyphicon glyphicon-info-sign'></i> Role permissions:</h4>
                    <ol>
                      {leaf.permissions.map((permission, index) => {
                        return (
                          <li
                            key={`permission-${obj.id}-${index}`}
                          >
                            {permission.description}
                          </li>
                        );
                      })}
                    </ol>
                  </div>
                );

                const handleClick = function (event) {
                  event.preventDefault && event.preventDefault();
                  const $ = window.$ || {};
                  $('.role-permissions').not(`#permissions-${obj.id}`).slideUp('fast');
                  $(`#permissions-${obj.id}`).slideToggle('fast');
                  $('.role-permissions-toggle').not($(event.target)).removeClass('expanded');
                  $(event.target).toggleClass('expanded');
                };

                obj.title = (
                  <span>
                    <span className='role-permissions-toggle' onClick={handleClick}>
                      {obj.title}
                      &nbsp;
                      <sup><i className='glyphicon glyphicon-info-sign'></i></sup>
                    </span>
                    {permissions}
                  </span>
                );
              }
              return <TreeNode key={obj.id} title={obj.title} checked
                disabled={this.props.disabled} className={'leaf'} isLeaf {...treeProps} />;
            })
          }
          </TreeNode>
        </Tree>
      </div>
    );
  }
}

export default PermissionTree;
