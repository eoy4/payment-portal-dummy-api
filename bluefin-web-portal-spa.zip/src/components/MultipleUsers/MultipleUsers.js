import React from 'react';
import { Checkbox } from '../Checkbox/Checkbox';
import { CheckboxWithID } from '../CheckboxWithID/CheckboxWithID';
import { Link } from 'react-router';

type Props = {
  users: Array,
  selectedUsers: Array,
  handleSelectUser: Function,
  handleClearSelectedUsers: Function,
  handleAction: Function
};
export class MultipleUsers extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.state = {allSelected: false, action: ''};

    this.toggleSelectUser = this.toggleSelectUser.bind(this);
    this.toggleSelectAll = this.toggleSelectAll.bind(this);
    this.removeSelectedUser = this.removeSelectedUser.bind(this);
    this.handleActionChange = this.handleActionChange.bind(this);
    this.handleClearAll = this.handleClearAll.bind(this);
    this.handleActivateUser = this.handleActivateUser.bind(this);
    this.handleDeactivateUser = this.handleDeactivateUser.bind(this);
    this.onActionSubmit = this.onActionSubmit.bind(this);
  }

  toggleSelectUser (payload) {
    this.setState({allSelected: false});
    this.props.handleSelectUser(payload);
  }

  toggleSelectAll () {
    this.setState({allSelected: !this.state.allSelected}, () => {
      this.props.users.content.forEach((user) => {
        const payload = {};
        payload.checked = this.state.allSelected;
        payload.item = {username: user.username};
        this.props.handleSelectUser(payload);
      });
    });
  }

  removeSelectedUser (username) {
    const payload = {};
    payload.checked = false;
    payload.item = {};
    payload.item.username = username;
    return (e) => {
      e.preventDefault();
      this.setState({allSelected: false});
      return this.props.handleSelectUser(payload);
    };
  }

  handleClearAll (e) {
    this.setState({allSelected: false});
    this.props.handleClearSelectedUsers();
  }

  handleActionChange (e) {
    e.preventDefault();
    this.setState({action: e.target.value});
  }

  handleActivateUser (username) {
    return (e) => {
      e.preventDefault();
      this.props.handleAction('activate', [username]);
    };
  }

  handleDeactivateUser (username) {
    return (e) => {
      e.preventDefault();
      this.props.handleAction('deactivate', [username]);
    };
  }

  onActionSubmit (e) {
    e.preventDefault();
    if (this.state.action === '') {
      return false;
    }
    return this.props.handleAction(this.state.action, this.props.selectedUsers);
  }

  render () {
    const styles = {
      padding: 0
    };
    const users = this.props.users.content || [];
    const {selectedUsers} = this.props;

    return (
      <div>
        <div style={styles} className='table-responsive'>
          <table className='users-table table table-bordered table-zebra'>
            <thead>
              <tr>
                <th className='text-center'>
                  <span style={{display: 'block', whiteSpace: 'nowrap'}}>Select All</span>
                  <Checkbox value={this.state.allSelected} onChange={this.toggleSelectAll} />
                </th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Status</th>
                <th className='text-center'>Actions</th>
              </tr>
            </thead>
            <tbody>
                {
                  users.map((user, index) => {
                    const checkboxOptions = {};
                    checkboxOptions.onChange = this.toggleSelectUser;
                    checkboxOptions.item = user;
                    checkboxOptions.value = selectedUsers && selectedUsers.includes(user.username);
                    return <tr key={user.username} className={`status-${user.status.toLowerCase()}`}>
                      <th scope='row' className='text-center'><CheckboxWithID {...checkboxOptions} /></th>
                      <td>{user.username}</td>
                      <td>{user.firstName}</td>
                      <td>{user.lastName}</td>
                      <td>{user.email}</td>
                      <td>{user.status}</td>
                      <td className='text-center' style={{whiteSpace: 'nowrap'}}>
                        {
                          user.status.toLowerCase() === 'inactive'
                          ? <a href='#' className='action-link' style={{color: '#7ac143'}} title='Activate'
                            onClick={this.handleActivateUser(user.username)}
                          >
                            <i className='glyphicon glyphicon-ok-circle'></i>
                          </a>
                          : <a href='#' className='action-link' style={{color: '#c02'}} title='Deactivate'
                            onClick={this.handleDeactivateUser(user.username)}
                          >
                            <i className='glyphicon glyphicon-ban-circle'></i>
                          </a>
                        }
                        <Link to={`/users/edit/${user.username}`} className='action-link' title='Edit'>
                          <i className='glyphicon glyphicon-edit' aria-hidden='true'></i>
                        </Link>
                      </td>
                    </tr>;
                  })
                }
            </tbody>
          </table>
        </div>
        {
          selectedUsers.length
          ? <div className='selected-users-list'>
            <h3>Selected Users ({selectedUsers.length})</h3>
            <ul>
              {
                selectedUsers.map((username, index) => {
                  return <li key={`${index}-${username}`} className='selected-user'>
                    {username}
                    &nbsp;
                    <a className='remove-selected-user' href='#' onClick={this.removeSelectedUser(username)}>
                      <i className='glyphicon glyphicon-remove'></i>
                    </a>
                  </li>;
                })
              }
            </ul>
            <div className='actions row'>
              <div className='form-group col-md-6'>
                <select className='form-control' name='action' value={this.state.action}
                  onChange={this.handleActionChange}
                >
                  <option value=''>Select an action</option>
                  <option value='activate'>Activate</option>
                  <option value='deactivate'>Deactivate</option>
                </select>
              </div>
              <div className='form-group col-md-6'>
                <button className='btn btn-default' onClick={this.handleClearAll}>
                  Clear All
                </button>
                <button className='btn btn-primary' onClick={this.onActionSubmit} disabled={this.state.action === ''}>
                  Go
                </button>
              </div>
            </div>
          </div>
          : null
        }
      </div>
    );
  }
}

export default MultipleUsers;

