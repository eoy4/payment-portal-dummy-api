import StatusCodesView from './StatusCodesView';
export default StatusCodesView;
