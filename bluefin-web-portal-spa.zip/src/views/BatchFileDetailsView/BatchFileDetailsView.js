import React from 'react';
import BatchFileDetails from '../../containers/BatchFileDetails';

type Props = {

};
export class BatchFileDetailsView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='batch-file-details'>
        <h1 className='page-header'>Latitude Batch Transactions</h1>
        <BatchFileDetails {... this.props} />
      </div>
    );
  }
}

export default BatchFileDetailsView;
