/* @flow */
import React from 'react';
import VoidTransaction from '../../containers/VoidTransaction';

export class VoidView extends React.Component {
  render () {
    return (
      <div id='void-transaction'>
        <VoidTransaction {... this.props} />
      </div>
    );
  }
}

export default VoidView;
