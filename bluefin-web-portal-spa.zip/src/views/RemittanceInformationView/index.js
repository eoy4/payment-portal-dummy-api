import RemittanceInformationView from './RemittanceInformationView';
export default RemittanceInformationView;
