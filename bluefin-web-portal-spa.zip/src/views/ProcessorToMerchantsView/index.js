import ProcessorToMerchantsView from './ProcessorToMerchantsView';
export default ProcessorToMerchantsView;
