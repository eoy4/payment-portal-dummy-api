import React from 'react';
import UserSearch from '../../containers/UserSearch';

type Props = {

};
export class UserLookup extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='users'>
        <h1 className='page-header' id='user-management-h1'>User Management</h1>
        <UserSearch {... this.props} />
      </div>
    );
  }
}

export default UserLookup;
