import { default as ProcessorsView } from './ProcessorsView';
export default ProcessorsView;
