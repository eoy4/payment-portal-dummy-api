import React from 'react';
import { Nav, NavItem, TabContainer, TabContent, TabPane } from 'react-bootstrap';

const userGuideLink =
  'http://myencore/globalit/GBS/cogent/Projects/204055 - Bluefin Phase 3.0/BF 3.0 User Manual.docx';

type Props = {

};

export class AboutView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} className='about-page' id='about'>
        <h1 className='page-header' id='about-page-h1'>About Bluefin Portal</h1>
        <div className='tab-content'>
          <div role="tabpanel" className="tab-pane active">
            <h2 className="sub-header"><i className='glyphicon glyphicon-info-sign'></i> Product Information</h2>
            <TabContainer id="about-page" defaultActiveKey="about">
              <div className="row">
                <div className="col-xs-12 col-sm-3">
                  <Nav bsStyle="pills" defaultActiveKey="about" stacked>
                    <NavItem eventKey="about">About Bluefin Portal</NavItem>
                    <NavItem eventKey="versions">API Versions</NavItem>
                    <NavItem eventKey="support">Support</NavItem>
                  </Nav>
                </div>
                <div className="col-xs-12 col-sm-9">
                  <TabContent animation>
                    <TabPane eventKey="about">
                      <h1><i className='glyphicon glyphicon-comment'></i> About Bluefin Portal</h1>
                      <p>Bluefin payment gateway is a payment gateway that authorizes credit card or
                      direct payments processing for Encore.</p>
                      <p>Bluefin payment gateway facilitates a payment transaction by the transfer of
                      information between the Bluefin payment portal and the front end processor or
                      acquiring bank via APIs or web portal. </p>
                      <p>Bluefin consists of an internal payment gateway which can intelligently route
                      transaction based on dynamic rules, and a web portal which users can leverage
                      as a virtual terminal to perform one-time transactions and to manage payment
                      processors.</p>
                      <p>With Bluefin, payment processors can be added and configured; transactions
                      from multiple servicing platforms can be aggregated, reconciled, and reported
                      together; and transaction processing can adapt and scale up to infinite number
                      of processors with ease.</p>
                    </TabPane>
                    <TabPane eventKey="versions">
                      <h1><i className='glyphicon glyphicon-cog'></i> API Versions</h1>
                      <p>This project was build using the following API versions:</p>
                      <ul className="list-group">
                        <span className="list-group-item">
                          <span className="label label-info pull-right">3.1.0</span>
                          Bluefin Web Portal SPA
                        </span>
                        <span className="list-group-item">
                          <span className="label label-info pull-right">3.1.0</span>
                          Bluefin Web Portal Services
                        </span>
                        <span className="list-group-item">
                          <span className="label label-info pull-right">2.0.1</span>
                          Encore Style Guide
                        </span>
                      </ul>
                    </TabPane>
                    <TabPane eventKey="support">
                      <h1><i className='glyphicon glyphicon-question-sign'></i> Support</h1>
                      <p>Please contact us on the following email address if
                      you are experiencing unexpected behaviors.</p>
                      <ul className="list-group">
                        <span className="list-group-item">Service.Desk@mcmcg.com</span>
                      </ul>
                      <a href={userGuideLink} target='_blank'>
                        <i className='glyphicon glyphicon-file'></i>
                        &nbsp;
                        Download the latest User Guide
                      </a>
                    </TabPane>
                  </TabContent>
                </div>
              </div>
            </TabContainer>
          </div>
        </div>
      </div>
    );
  }
}

export default AboutView;
