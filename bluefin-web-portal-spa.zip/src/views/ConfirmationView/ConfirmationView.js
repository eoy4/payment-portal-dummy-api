import React from 'react';
import ConfirmedTransaction from '../../containers/ConfirmedTransaction';

type Props = {

};
export class Confirmation extends React.Component {
  props: Props;

  render () {
    return (
      <div id='sale-confirmation'>
        <ConfirmedTransaction {... this.props} />
      </div>
    );
  }
}

export default Confirmation;
