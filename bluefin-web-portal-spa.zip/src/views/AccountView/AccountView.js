import React from 'react';
import UserUpdate from '../../containers/UserUpdate';

type Props = {

};
export class AccountView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='account'>
        <h1 className='page-header'>Account Information</h1>
        <UserUpdate title={'Update your profile'} mode={'self'} {...this.props} />
      </div>
    );
  }
}

export default AccountView;
