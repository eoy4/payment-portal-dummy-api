import React from 'react';
import { default as ProcessorDetails } from '../../containers/ProcessorDetails';
import './ProcessorDetailsView.scss';

type Props = {

};
export class ProcessorDetailsView extends React.Component {
  props: Props;

  constructor (props) {
    super(props);

    this.goBack = this.goBack.bind(this);
  }

  goBack () {
    const { router } = this.context;

    router.goBack();
  }

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div className='processor-details' style={styles} id='processor-details'>
        <h1 className='page-header'>Payment Processor Readiness Checklist</h1>
        <div className='tab-content'>
          <div className='tab-pane active'>
            <button className='btn btn-default' onClick={this.goBack} >&larr; Go Back</button>
            <br />
            <ProcessorDetails {...this.props} />
          </div>
        </div>
      </div>
    );
  }
}

ProcessorDetailsView.contextTypes = {
  router: React.PropTypes.object
};

export default ProcessorDetailsView;
