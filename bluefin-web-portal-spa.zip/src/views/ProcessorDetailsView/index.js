import ProcessorDetailsView from './ProcessorDetailsView';
export default ProcessorDetailsView;
