import NotFoundView from './NotFoundView';
export default NotFoundView;
