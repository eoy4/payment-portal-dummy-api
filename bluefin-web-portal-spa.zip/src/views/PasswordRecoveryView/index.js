import PasswordRecoveryView from './PasswordRecoveryView';
export default PasswordRecoveryView;
