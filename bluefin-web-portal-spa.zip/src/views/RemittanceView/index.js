import RemittanceView from './RemittanceView';
export default RemittanceView;
