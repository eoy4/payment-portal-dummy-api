import React from 'react';
import { connect } from 'react-redux';
import GlobalSearch from '../../containers/GlobalSearch';
import { Link } from 'react-router';

type Props = {
  accessRoles: Object
};
export class Reports extends React.Component {
  props: Props;

  componentDidMount () {
    const { accessRoles } = this.props;
    if (!accessRoles['reports']) {
      const { router } = this.context;
      router.replace({
        pathname: '/search/remittance'
      });
    }
  }

  clickStud (e) {
    e.preventDefault();
  }

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='global-search'>
        <h1 className='page-header' id='search-reporting-heading'>Search & Reporting</h1>
        {
          this.props.accessRoles &&
          this.props.accessRoles['remittance']
          ? <ul className='nav nav-tabs' role='tablist'>
            <li className='active'><a href='#' onClick={this.clickStud} id='transactions-tab-a'>Transactions</a></li>
            <li><Link to='/search/remittance' id='reconciliation-tab-a'>Reconciliation</Link></li>
          </ul>
          : null
        }
        <div className='tab-content'>
          <div className='tab-pane active'>
            <GlobalSearch {... this.props} />
          </div>
        </div>
      </div>
    );
  }
}

Reports.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.object
};

const mapStateToProps = (state) => {
  return {
    accessRoles: state.auth.accessRoles
  };
};

export default connect(
  mapStateToProps
)(Reports);
