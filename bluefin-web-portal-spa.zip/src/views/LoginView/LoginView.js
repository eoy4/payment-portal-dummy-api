import React from 'react';
import Login from '../../containers/Login';

type Props = {

};
export class LoginView extends React.Component {
  props: Props;

  render () {
    return (
      <Login {... this.props} />
    );
  }
}

export default LoginView;
