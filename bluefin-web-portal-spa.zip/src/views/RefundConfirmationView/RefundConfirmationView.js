import React from 'react';
import ConfirmedTransactions from '../../containers/ConfirmedTransactions';

type Props = {

};
export class RefundConfirmation extends React.Component {
  props: Props;

  render () {
    return (
      <div id='refund-confirmation'>
        <ConfirmedTransactions {... this.props} message={'Transactions Summary'} />
      </div>
    );
  }
}

export default RefundConfirmation;
