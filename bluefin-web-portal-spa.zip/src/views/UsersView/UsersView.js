import React from 'react';
import UserUpdate from '../../containers/UserUpdate';

type Props = {

};
export class Users extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='users-create'>
        <h1 className='page-header'>User Management</h1>
        <UserUpdate title={'Create a new user'} {...this.props} />
      </div>
    );
  }
}

export default Users;
