/* @flow */
import React from 'react';
import RefundTransaction from '../../containers/RefundTransaction';

export class RefundView extends React.Component {
  render () {
    return (
      <div id='refund-transaction'>
        <RefundTransaction {... this.props} />
      </div>
    );
  }
}

export default RefundView;
