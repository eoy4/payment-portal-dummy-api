import RecurringPaymentsView from './RecurringPaymentsView';
export default RecurringPaymentsView;
