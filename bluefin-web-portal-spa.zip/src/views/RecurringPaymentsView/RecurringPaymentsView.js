import React from 'react';
import RecurringPayments from '../../containers/RecurringPayments';

type Props = {

};
export class RecurringPaymentsView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='recurring-payments'>
        <h1 className='page-header'>Batch Transactions</h1>
        <RecurringPayments {... this.props} />
      </div>
    );
  }
}

export default RecurringPaymentsView;
