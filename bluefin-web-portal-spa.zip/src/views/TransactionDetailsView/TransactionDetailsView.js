import React from 'react';
import { default as TransactionDetails } from '../../containers/TransactionDetails';

type Props = {

};
export class TransactionDetailsView extends React.Component {
  props: Props;

  render () {
    const styles = {
      padding: '0 30px 30px'
    };
    return (
      <div style={styles} id='transaction-details'>
        <h1 className='page-header'>Transaction Details</h1>
        <TransactionDetails {...this.props} />
      </div>
    );
  }
}

export default TransactionDetailsView;
