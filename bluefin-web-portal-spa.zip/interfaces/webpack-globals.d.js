declare var __DEBUG__: boolean;
declare var __DEV__: boolean;
declare var __LOCAL__: boolean;
declare var __QA__: boolean;
declare var __TEST__: boolean;
declare var __PROD__: boolean;
declare var __BASENAME__: boolean;
