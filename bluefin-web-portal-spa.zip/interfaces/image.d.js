declare module Image {
  declare var exports: any;
}
