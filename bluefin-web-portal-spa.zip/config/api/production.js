module.exports = {
  MIDDLEWARE: {
    BASE_URL: '',
    TEST_MODE: false,
    TRANSACTIONS: {
      SALE: 'https://igw-data-rest.internal.mcmcg.com:7542/RestPaymentGateway/Requests',
      VOID: 'https://igw-data-rest.internal.mcmcg.com:7543/PaymentGateway/VoidRequest',
      REFUND: 'https://igw-data-rest.internal.mcmcg.com:7544/PaymentGateway/RefundRequest'
    }
  },
  MICROSERVICE: {
    BASE_URL: 'https://bluefin.mcmcg.com/bluefin-wp-services/api/',
    TRANSACTIONS: {
      SEARCH: 'transactions?search=',
      REPORT: 'reports/transactions?search=',
      RECON_REPORT: 'reports/payment-processor-remittances?search=',
      GET: 'transactions/'
    },
    BATCH_FILES: {
      POST: 'batch-upload/',
      SEARCH: 'batch-upload/',
      GET: 'batch-upload/',
      REPORT: 'reports/batch-uploads/',
      TRANSACTIONS_REPORT: 'reports/batch-upload-transactions/'
    },
    USERS: {
      SEARCH: 'users?search=',
      CRUD: 'users/',
      STATUS: 'users/status',
      LOGIN: 'session/',
      RECOVER_PASSWORD: 'session/recovery/password'
    },
    LEGAL_ENTITIES: {
      GET: 'legal-entities/',
      CRUD: 'legal-entities/'
    },
    ROLES: {
      GET: 'roles/'
    },
    PROCESSORS: {
      CRUD: 'payment-processors/'
    },
    PROCESSOR_RULES: {
      CRUD: 'payment-processor-rules/'
    },
    RESPONSE_CODES: {
      CRUD: 'internal-response-codes/'
    },
    STATUS_CODES: {
      CRUD: 'internal-status-codes/'
    },
    TRANSACTION_TYPES: {
      CRUD: 'transaction-types/'
    },
    RECONCILIATION_STATUS: {
      GET: 'reconciliation-status/'
    },
    REMITTANCES: {
      SEARCH: 'payment-processor-remittances?search=',
      GET: 'payment-processor-remittances/'
    },
    APPLICATION: {
      GET: 'applications/'
    },
    PAYMENT_FREQUENCIES: {
      GET: 'origin-payment-frequencies'
    }
  }
};
