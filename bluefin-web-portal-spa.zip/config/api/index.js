var required = require('apiPath');

module.exports = {
  MIDDLEWARE: required.MIDDLEWARE,
  MICROSERVICE: required.MICROSERVICE
};
